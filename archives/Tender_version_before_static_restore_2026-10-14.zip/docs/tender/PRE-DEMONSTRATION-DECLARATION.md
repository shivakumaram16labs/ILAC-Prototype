# Pre-demonstration declaration — fill-in template

Preparation template based on Section 9 of the issued pack. Put the reviewed declaration on the bidder’s letterhead and send it through the Board’s prescribed process at least one working day before the slot. This file has not been sent or signed.

To: The Secretary & CEO, APBOCWWB, Vijayawada

Sub: Tender ID 985903 — T-4 Scripted Solution Demonstration — declaration

We, M/s **[bidder name]**, confirm that for our demonstration on **[date]** at **[time]**:

1. We have received the demonstration pack, dataset v1.0 and the Annexure-B scoring sheet, and accept the rules in Section 2. **[Confirm actual receipt of Annexure-B; it was not in the supplied project folder.]**
2. Dataset v1.0 is loaded unaltered in our demonstration environment, with offset-driven dates rebased to the demonstration day.
3. Our mocks implement ILAC_Demo_Mock_API_v1.0.yaml with the behaviours on S_Mock_API_Behaviour. No live Government system will be called.
4. No real personal data, Aadhaar number or Government credential is held on any demonstration machine or device, and no real SMS or WhatsApp message will be sent.
5. What we demonstrate is the solution proposed in our technical bid; any component shown that is not in that bid will be identified as such. **[Review the PWA/local-server approach against the submitted bid before signing.]**
6. Our representatives, maximum four, include the Solution Architect or Technical Lead named in the technical bid:

| Name | Designation | Role in technical bid | Mobile |
| --- | --- | --- | --- |
| [fill] | [fill] | [fill] | [fill] |
| [fill] | [fill] | [fill] | [fill] |
| [fill] | [fill] | [fill] | [fill] |
| [fill] | [fill] | [fill] | [fill] |

Authorised signatory: __________________

Name and designation: __________________

Date and seal: __________________

Check the actual Android installation, camera, location, offline operation, concurrent sessions, display, primary connection, source hashes and Board-provided slot before making these declarations. The Committee’s live assessment and official scoring sheet control the demonstration result.

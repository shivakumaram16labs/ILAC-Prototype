# T-4 coverage and live evidence map

Source: the issued **Digital ILAC Part 1 – T-4 Scripted Solution Demonstration Pack (1).docx**, Section 4, and dataset v1.0. This is a bidder preparation map, not the official Annexure-B scoring workbook. The Committee observes the live actions and determines the score.

The current build covers all 45 numbered steps and five configuration tasks. All five scenarios and C1–C5 were exercised through the desktop browser UI. Actual Android camera, GPS, installation, airplane-mode witnessing and venue mirroring remain physical-device preflight tasks. See [VERIFICATION.md](VERIFICATION.md) and the [full department walkthrough](../../README.md).

C1–C5 are performed by **demo.admin.state** through the UI. Publication increments the configuration version and records publisher, timestamp and before/after values; no source edit, database script or redeployment is needed during the task.

| Step | Issued requirement | Live application location / action |
| --- | --- | --- |
| **1.1** | Log in as demo.op.ntr; show the role-based menu (only enabled modules) and switch the interface Telugu ↔ English. | demo.op.ntr → Workspace / sidebar; Telugu ↔ English button. Login password + mock OTP. |
| **1.2** | Issue and call a walk-in token for P-01 from the queue (SM-18). | S1 → Issue token → Call token; SM-18 queue. |
| **1.3** | Search the registry before creating a record: BOCW mock returns no match; e-Shram mock verifies P-01 and returns the UAN token. | Register worker → Search registry → Verify e-Shram; Activity request/response log. |
| **1.4** | Register P-01 with the S_Personas values. Attempt to save once without date of birth to show mandatory-field validation. | Register worker, P-01. Clear DOB, attempt Save, restore issued DOB and Save. |
| **1.5** | Capture consent: purpose, notice version CONSENT-DEMO-v1, channel and timestamp. | Registration consent purpose/channel; saved notice, timestamp and actor in acknowledgement. |
| **1.6** | Capture the household baseline and the four members with relationships and education stage; each member is linked to the household. | Registration household baseline and four dependant rows; worker View → linked household members. |
| **1.7** | Upload and classify specimen_photo_P-01.png and specimen_work_certificate_P-01.png under controlled access. | Documents → P-01 worker → Photo / Work certificate; upload the exact two issued PNGs. |
| **1.8** | Issue the acknowledgement on screen and show the Telugu SMS/WhatsApp acknowledgement in the mock gateway log. | S1 → View acknowledgement after both document uploads; Activity → Messaging log. |
| **1.9** | Key P-02 as 'Gorle Laxmi'. The system flags a potential duplicate against SYN-W-000607 before creating a record; the operator links to the existing record; the action is audit-logged. | S1 → type Gorle Laxmi → Search → Link existing; Audit trail; original worker unchanged. |
| **1.10** | Register P-03. The e-Shram mock times out; registration completes with status 'verification pending – external system unavailable', a retry is queued and a documented next step is issued. The worker is not turned away. | P-03 registration → Verify (real 10-second wait) → Save → pending status, retry and next step. |
| **C1** | Configuration task: As demo.admin.state, add a mandatory dropdown field 'Primary language of worker' (Telugu / Urdu / Odia / Hindi / Other) to the household baseline form and publish it. Show it on the next registration screen without a code change or redeployment, with the configuration version and change log. | demo.admin.state → Configuration → C1 mandatory dropdown → Publish; next registration screen. |
| **2.1** | On the Android field device, log in as demo.ff.krs and download visit SYN-VIS-001 with its 12-worker roster while online. | demo.ff.krs → S2 → Download assigned visit; site and all 12 roster workers. |
| **2.2** | Switch the device to airplane mode. A Committee member verifies that the device is offline. | Actual Android airplane mode; Committee verifies offline. Browser automation separately verifies offline operation. |
| **2.3** | Record attendance for all 12 workers; mark SYN-W-000182 and SYN-W-000225 absent. | Field S2 → attendance selectors for all 12; absent SYN-W-000182 and SYN-W-000225. |
| **2.4** | Record a safety-session observation with a photograph taken on the device and its location. | Field S2 → safety observation → device camera → Capture location → Save visit. Physical camera/GPS preflight required. |
| **2.5** | Record skilling needs for the three workers marked in T09. | Field S2 → three T09 skilling-need controls; queued with visit. |
| **2.6** | Register P-04 on site. The record receives a provisional ID and is stored encrypted on the device (show the evidence). | Field Register worker → P-04 → provisional ID; Encrypted device evidence shows AES-GCM ciphertext and non-extractable key. |
| **2.7** | Edit the mobile number of SYN-W-000120 on the device to 9000099101. In parallel, demo.op.krs edits the same field at the centre (online) to 9000099102. | Field mobile form → worker 120 / 9000099101; separate demo.op.krs session → 9000099102. |
| **2.8** | Reconnect the device. Synchronisation runs automatically; show the sync queue and status. P-04 receives a permanent worker ID and the server-side duplicate check runs. | Reconnect device → automatic sync → receipts/permanent ID; Activity → BOCW duplicate-search log. |
| **2.9** | The conflict on SYN-W-000120 is surfaced to demo.sup.krs with both versions preserved; the supervisor resolves it with a reason; the audit trail shows both edits and the resolution. | demo.sup.krs → S2 / SM-19 limited conflict view → choose preserved version + reason; audit history. |
| **2.10** | Show the visit in each worker's history and the three skilling needs available for grouping or referral to a batch (SM-11 / SM-20). | Field roster → Worker history; SM-20 → marked needs → issued batch grouping. |
| **C2** | Configuration task: Add a checklist item 'PPE – safety helmets available on site (Yes/No)' to the site-visit form. Show that it reaches the field device at the next synchronisation, without a new app build. | Authority Configuration → C2 PPE checklist → Publish; field next sync → Yes/No selector. |
| **3.1** | Open P-05 (SYN-W-000608). The household timeline shows earlier services, including the completed LB-01 renewal. | demo.op.krs → S3 → P-05 household timeline; SYN-R-00152 completed LB-01. |
| **3.2** | Add the new-born daughter (Bandaru Likhitha) to the household and attach specimen_birth_certificate_P-05.png. | S3 → new-born form; Documents → Birth certificate → exact issued P-05 PNG. |
| **3.3** | Referral A – SK-01 skill training (APSSDC) via the mock API: external acknowledgement returned; 7-day service clock and due date displayed. | S3 → SK-01 referral; API acknowledgement, 7-day due date and case record. |
| **3.4** | Referral B – CS-01 rice-card member addition (Civil Supplies): the mock returns 503; the case is routed automatically to the manual/assisted fallback with the same case lifecycle, a 21-day clock, a printable or shareable referral slip, a departmental worklist entry and the reason 'API unavailable' logged. | S3 → CS-01 referral; 503 automatically selects manual fallback, same case ID, 21-day clock and referral slip. |
| **3.5** | Give the worker one acknowledgement listing both referral IDs, due dates, responsible offices and next steps. | S3 → Combined acknowledgement; two IDs, offices, clocks and next steps. |
| **3.6** | Log in as demo.nodal.cs: the case appears in the departmental worklist; record 'Received – documents verified' with evidence (manual update). | demo.nodal.cs → SM-22 worklist → View referral → Receive / verify documents with evidence. |
| **3.7** | Show the APSSDC referral move to 'Seat confirmed' by mock callback or status poll. | demo.nodal.sk or demo.op.krs → APSSDC referral → Trigger seat confirmation → Poll status. |
| **3.8** | Open pre-existing referral SYN-R-00151 (CS-01, created D−25): overdue, with escalation history to demo.dlo.krs (L1, day 14) and the State PMU (L2, day 21); it appears on the DLO's pendency view. | demo.dlo.krs → S3 → SYN-R-00151; overdue flag, original 21-day clock, L1/L2 derived history. |
| **3.9** | Show integration monitoring (SM-12): Civil Supplies mock down, error and retry log, open dependency. | S3 → Inspect integration dependency; Activity mock log, 503, retry 3600 seconds and open dependency. |
| **C3** | Configuration task: Change the CS-01 service clock from 21 to 15 days and the L1 escalation from 14 to 10 days, effective for new referrals only. Show the version history and that the existing case keeps its original clock. | Authority Configuration → C3 → clock 15, L1 10 → Publish; old case still 21, next CS-01 case 15. |
| **4.1** | Show JM-2026-01 configured from T07: employers SYN-E-001 to SYN-E-006, the 12 vacancies, venue and capacity, visible on the shared calendar (SM-06). | demo.dlo.gnt / demo.op.gnt → S4; event source, six employers, 12 vacancies, capacity and Shared calendar. |
| **4.2** | Open the list of 20 pre-registered candidates and check in P-07 (JMR-004) by token, QR code or mobile number. | S4 candidate list → JMR-004 / P-07 → Check in. |
| **4.3** | P-06 walks in: quick worker registration (BOCW mock – no match), event registration and check-in with eligibility and document check. | demo.op.gnt → Register P-06 with issued photo → S4 → eligibility / documents checked → Event registration + check-in. |
| **4.4** | Allocate interview slots: P-06 with SYN-E-001 for mason vacancy SYN-V-0001, and P-07 for preferred vacancy SYN-V-0006 (bar bender, SYN-E-006). | S4 → Interview allocation; P-06 SYN-V-0001 / SYN-E-001 and JMR-004 SYN-V-0006 / SYN-E-006. |
| **4.5** | As employer user demo.emp.001, review the candidate and record a spot offer for P-06 (wage, engagement type, joining date D+3). | demo.emp.001 → own candidate / interview → Spot offer → source wage/engagement and joining D+3. |
| **4.6** | Record P-07's outcome as 'Employer decision pending' with a follow-up on D+2. | Mela desk → P-07 → Employer decision pending; D+2 follow-up shown. |
| **4.7** | Show the placement record linked to SM-05 with a joining follow-up task, and the worker notification in the mock gateway log. | SM-05 placement record / joining follow-up; Activity → mock worker notification. |
| **4.8** | Show the live event dashboard or closure report: registrations, check-ins, interviews and offers by employer. | S4 live employer dashboard and closure report; registrations, check-ins, interviews and offers. |
| **C4** | Configuration task: Add a trade category 'Solar panel installer' and publish a vacancy under it for SYN-E-002 at JM-2026-01. Show that it is immediately available for matching and on the event. | Authority Configuration → C4 Solar panel installer + SYN-E-002 / JM-2026-01 vacancy → Publish; desk matching options refresh. |
| **5.1** | As demo.cns.edu1, open P-08 (SYN-M-001909): linked to the household and to father SYN-W-000609; education stage shown. | demo.cns.edu1 → S5 → P-08 member, SYN-M-001909, father SYN-W-000609 and household. |
| **5.2** | Book an appointment with SYN-C-01 through the shared calendar (SM-06); show the reminder in the mock gateway log. | S5 → Book SYN-C-01 appointment in issued availability; Shared calendar and mock reminder. |
| **5.3** | Record the session: assessment, interests, advice (Polytechnic – Diploma in Civil Engineering), agreed actions; counselling notes are access-restricted. | S5 → assessment/interests/advice/actions → Record session; notes returned only to assigned counsellor. |
| **5.4** | Raise referrals ED-02 (admission – manual) and ED-01 (scholarship – mock API), each with its service clock. | Upload P-08 marks memo; S5 → ED-02 manual (15 days) and ED-01 API (30 days). |
| **5.5** | Set a follow-up for D+14; show the case on the dependant's record and on the household timeline. | Saved session shows D+14 follow-up, member link and father/household timeline. |
| **5.6** | Log in as demo.pmu.state: role-based dashboard with drill-down State → district → centre. | demo.pmu.state → SM-13 → district and centre drill-down; State view default. |
| **5.7** | Answer MIS queries Q1–Q5 live using the platform's reports or query tools. The Committee compares results with its answer key. | SM-13 → choose issued Q1 through Q5 → Run query live; baseline snapshots where specified. |
| **5.8** | Export one report (Excel/CSV) with a reporting timestamp; personal identifiers are masked or minimised in the export. | SM-13 → Export CSV; reporting timestamp + aggregate fields without worker/mobile/UID identifiers. |
| **C5** | Configuration task: Using the report builder, create and save a report 'Women workers by trade and district' and add it to the PMU dashboard without code. | Authority Configuration → Report builder → Women workers by trade and district → Save; PMU dashboard → Run / Export. |

## Environment and evidence

| Pack requirement | Implementation / preparation |
| --- | --- |
| Configured working solution in bidder environment | Dependency-free local Node.js HTTP/HTTPS server; HTML/CSS/JS desk, role and Authority interfaces. |
| Dataset loaded unchanged | 22 CSV tables / 3,684 initial records; 31 original source file SHA-256 checks; importer preserves cell strings. |
| Date rebasing | Authority Environment → actual D. Only offset-driven dates are derived; fixed source dates/ages stay unchanged. |
| Hosted Government mocks | Same-origin `/mock`, all 13 supplied OpenAPI paths, bearer token and request/response logs. |
| Required failure behaviours | Real >10-second P-03 timeout; Civil Supplies 503 and Retry-After 3600 throughout S3. Restore requires a recorded Committee instruction. |
| Mock messaging | 202 log-only SMS/WhatsApp/IVR/Email endpoint; no external provider or dispatch. |
| Installed Android field app | Installable PWA, trusted local HTTPS, camera inputs, geolocation, offline service worker and AES-256-GCM IndexedDB. Actual device check required. |
| Concurrent sessions | Independent account sessions share server state; S2 parallel field and centre edit with supervisor resolution. |
| Audit / sync / configuration / API evidence | Activity pages, field encrypted queue/receipts, Authority configuration history and mock contract console. |
| Language | Telugu/English menu and scripted form controls; editable Telugu persona name; source record/service names kept as issued. |
| Role permissions | Exact issued M05 account/module defaults; server-enforced action and jurisdiction checks; supervisor configuration restriction; employer own candidates; private counselling notes restricted. |
| Accessibility probe | Semantic labels, native controls/dialogs, skip-to-content link, keyboard focus and labelled mobile navigation. No formal screen-reader certification asserted. |
| Slot management | Authority starts elapsed 90-minute clock only on Committee instruction; S1–S5 preparation tabs and checklist. |

## Data-specific decisions

- M05 supplies 13 staff/department/employer/analyst/Authority users. There is no worker self-login account in this pack; none was invented.
- Household and ILAC referral / case terminology is retained because it is explicitly required by the new script and data contract.
- The assigned 12-worker S2 roster includes four ILAC-KRS-02 workers. Centre/operator/supervisor access includes that assignment without changing their source jurisdiction.
- P-02 links to SYN-W-000607. Its differing input-card fields do not overwrite the registry record. Six seeded near-duplicate pairs remain intact.
- P-05 opens the existing registry anchor; differing persona/registry experience values are not silently rewritten.
- P-06 is a new walk-in registration as required by step 4.3. Its source card is not changed.
- Q1, Q3 and Q5 use immutable loaded snapshots; Q2/Q4 apply the pack's as-on-D open-status and offset rules. The application's query results are computed, not loaded from an invented answer file.
- The L1/L2 history for SYN-R-00151 is derived from issued offsets and service rules. It is labelled as derived evidence; no escalation-history source table was provided.
- M04 integration labels without a supplied YAML operation are shown with a documented manual/dependency route; no Government endpoint contract is fabricated.
- No AI model, live Government API, real message, invented seed account, public deployment or production readiness claim is included.

## Documents to obtain before the slot

The supplied folder does not contain **Annexure-B_T4_Demonstration_Scoring_Sheet_v1.0.xlsx**. Obtain the identical official sheet from the Board; this file does not replace it. The controlling RFP/corrigenda and Annexures D/14/14A also need to be checked against the submitted technical bid, especially any native-app or hosting commitment. The Board's actual demonstration date/time was not supplied, so set D and complete the declaration before attendance.

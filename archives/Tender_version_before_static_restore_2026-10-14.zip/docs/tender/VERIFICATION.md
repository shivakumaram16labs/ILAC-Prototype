# T-4 verification record

Verification performed on **14 October 2026** using the local project and the issued v1.0 folder. These are bidder preparation checks; they do not represent a Committee demonstration, awarded marks or production certification.

## Checks completed

| Check | Result / scope |
| --- | --- |
| `npm run check` | Passed. 22 data tables, 3,684 loaded records, 31 original file SHA-256 hashes, 13 issued accounts, 23 services, 13 mock paths, active JavaScript syntax and local assets. |
| `npm test` | Passed. S1–S5/C1–C5 engine actions; missing DOB; consent; four dependants; document-before-ack; duplicate preservation; real P-03 timeout; sync idempotency/conflict; frozen service clocks; placement; counselling privacy; immutable source snapshots. |
| `npm run test:browser` with an existing Puppeteer-compatible driver | Passed in headless desktop Google Chrome. Actual UI actions for all five scenarios and five configuration tasks; two concurrent browser contexts; offline capture and page reload; encrypted records; reconnection and automatic sync; both mobile edits and supervisor reason; report export; role denial; 390px mobile layout. No runtime JavaScript errors or external page requests. |
| Encrypted field vault | AES-256-GCM with a 12-byte IV; persisted packets contain ciphertext, not payloads. CryptoKey `extractable` was false. Offline registration survived a page reload and received a permanent ID on sync. |
| `npm run test:http` | Passed. All 13 hosted mock path families, issued P-02 match, UIDAI token authentication/12-digit rejection, seven DigiLocker metadata records, acknowledgements, status operations, Civil Supplies 503 with Retry-After 3600, message 202 with `dispatched:false`, invalid bearer rejection and private seed-file routing. |
| Trusted local HTTPS | Health endpoint succeeded using the generated local CA with certificate verification enabled. This verifies server TLS; it does not mean the CA is already installed on the Android device. |
| PWA readiness | Chrome reported no installability errors on localhost; secure context and service-worker control were confirmed. Actual Android installation still needs the physical-device check. |
| Source integrity after rehearsal | Original workbook, YAML, CSVs and specimen files still matched their import-time hashes; no issued file was changed. |

The full browser rehearsal used the issued specimen images and test geolocation. It did not impersonate a Committee-witnessed device camera or physical location capture.

## Independently computed query baselines

| Query | Expected local result |
| --- | --- |
| Q1 | 176 active registered women; top districts Kakinada 15, Srikakulam 14, Kurnool 11, Palnadu 11, Krishna 10. |
| Q2 | 54 open overdue referrals across 16 departments. |
| Q3 | 20 pre-registered candidates across 9 trades, before demo registration. |
| Q4 | 26 open grievances older than 30 days. |
| Q5 | 4 baseline Krishna active workers with skilling need and no batch, across 4 trades. |

These values were computed from the supplied rows and query definitions. The Committee's answer key was not supplied. Q1/Q3/Q5 remain stable after scripted registrations/field updates because they refer to the loaded snapshot.

## Repeat the checks

With the local server running:

```sh
npm run check
npm test
npm run test:http
ILAC_PUPPETEER_PATH="/absolute/path/to/puppeteer-compatible-module.js" npm run test:browser
```

The application has no npm runtime dependencies. The optional browser runner expects a module exporting `puppeteer` and an installed Google Chrome at the path configured in the test. The browser test resets the rehearsal before running and leaves completed scenario state afterwards. Reset through the Authority Environment screen before the department slot; clear the field device rehearsal cache and download the roster again.

Screenshots in `docs/screenshots/t4-*.png` are visual inspection artifacts. They are not valid scored evidence under the pack's live-system-only rule.

## Physical and venue preflight still required

1. Trust the public local CA on the actual Android device; open the LAN HTTPS URL without a certificate error and install the PWA.
2. Grant camera/location permissions, take a synthetic device photograph and capture GPS.
3. Download the assigned visit, turn on airplane mode and perform the field steps. Have the Committee witness actual offline status during the slot.
4. Reconnect while the online operator session remains available; show the queue, permanent ID, conflict and audit history.
5. Verify camera image display, screen mirroring/HDMI, power, bidder connectivity and standby device at the venue.
6. Set the Board's actual D/slot; reset the rehearsal; obtain the missing official Annexure-B; verify the submitted technical bid and complete the declaration.

The local environment persists rehearsal state and encrypted offline records. It is not a hardened production authentication, application distribution, disaster recovery or Government integration deployment. The requested tender demonstration is the scope verified here.

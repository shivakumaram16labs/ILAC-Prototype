# Digital ILAC Prototype
## Knowledge Transfer and Live Demo Guide

**Tender 985903 · Digital ILAC Part 1 · T-4**  
**Reference date:** 14 October 2026  
**Purpose:** Explain the prototype clearly, prepare the team, and present the supplied 90-minute demonstration in the required order.

This is the short presenter and handover guide. The detailed step-by-step requirement mapping remains in [T4-COVERAGE.md](tender/T4-COVERAGE.md), and the longer rehearsal handbook remains in [Digital ILAC Client Demo Playbook](presentation/Digital_ILAC_Client_Demo_Playbook.html). The Board's issued pack and scoring sheet are authoritative if wording differs.

## The one-minute explanation

Digital ILAC is a role-based service workspace for an ILAC centre and its partner teams. A worker can be registered once, connected to a household, supported during a field visit, referred to a department, considered for employment and supported through education counselling. Staff see the work relevant to their role; managers can follow service requests and reports.

The prototype starts from the 22 issued CSV tables: **3,684 synthetic records**. It uses local mock Government integrations and a local mock messaging gateway. No live Government service is called and no real SMS or WhatsApp message is sent. The Android field flow can capture a downloaded visit offline and synchronise it later.

> **Short opening:** “We are showing one connected service journey, from assisted registration through field work and departmental follow-up to employment and education support. The examples use the issued synthetic data, and every external response shown today comes from a local mock.”

## Based on the technical proposal

The proposal describes ILAC as a **one-stop facilitation service** for registered construction workers and their dependants, organized around the 4E journey: **Enrollment, Entitlement, Empowerment and Employment**. It presents six locations for that service: **ILAC centre and labour adda; worksite; household; job mela and camps; remote and assisted channels; and partner/Board back office**.

The core service commitment is **no worker turned away**: a request should reach a completed service or a documented next step with an owner, action, target date, documents and follow-up route. If a partner's system is unavailable, the same case should continue through an assisted route.

The proposal's larger product architecture includes ten shared platform services and 22 functional modules. This prototype uses the issued Part 1 T-4 data and requirements to demonstrate selected end-to-end examples of that model. Its local mock integrations and limited T-4 workflows are **not** evidence that all 22 proposal modules, all 38 schemes, live Government connections or production operations are implemented. Describe the broader commitments as the proposed platform direction; describe only the tested flows as working prototype behavior.


## The service journey

1. **Welcome and register:** Check the existing worker record, capture consent and household needs, and issue a service acknowledgement.
2. **Reach the worksite:** Download the assigned roster, record attendance and support needs, and work offline when needed.
3. **Follow a request:** Send a referral to a department, track its due date, and continue through an assisted route if an integration is unavailable.
4. **Connect to employment:** Check in candidates, arrange interviews and record offers and follow-up.
5. **Support education:** Book counselling, record private case notes and refer a dependant to education services.
6. **Learn and improve:** Review reports and publish form or service changes through the Authority interface.

Use your own natural narration. The live actions below are fixed by the issued T-4 pack; the wording you use to explain them is not.

## Presenter and role handover

| Team member | Issued login | What they show |
| --- | --- | --- |
| Assisted-centre operator | `demo.op.ntr` | Walk-in token, worker search, P-01 registration, household and acknowledgement |
| Field functionary | `demo.ff.krs` | Assigned visit, offline capture, encrypted queue and later synchronisation |
| Krishna centre operator | `demo.op.krs` | Household services, referral creation and the concurrent centre edit |
| Centre supervisor | `demo.sup.krs` | Resolve the field/centre update conflict with a reason |
| District / mela officers | `demo.dlo.krs`, `demo.dlo.gnt` | District follow-up and job-mela coordination |
| Department officers | `demo.nodal.cs`, `demo.nodal.sk` | Civil Supplies and APSSDC case worklists |
| Employer | `demo.emp.001` | Review the employer's own candidate and record an offer |
| Education counsellor | `demo.cns.edu1` | Appointment, restricted notes and education referrals |
| State PMU analyst | `demo.pmu.state` | District/centre drill-down, Q1–Q5 and report export |
| Authority administrator | `demo.admin.state` | Readiness checks and C1–C5 configuration tasks |

All 13 issued accounts use the demo password **`admin@123`**. The local mock OTP is **`123456`**. It is not sent as a real message. Prepare separate browser profiles or devices for concurrent roles; signing out does not reset rehearsal data.

## Prepare the room

Do this before the 90-minute slot. The pack allows a separate 45-minute setup period.

### Laptop and dataset

1. Start the server from the project directory with `npm start`; open `http://localhost:8080`.
2. Sign in as `demo.admin.state`. Open **Environment**, reset the rehearsal, set the actual demonstration date **D**, rebase offset-driven dates, and verify source hashes.
3. Confirm the original baseline: **22 sheets and 3,684 records**. Keep the issued CSVs and specimen images unchanged.
4. Leave the Civil Supplies mock unavailable for S3. Do not publish C1–C5 before their live configuration tasks.
5. Keep a separate browser session for the Authority and each role needed at the same time.

### Android field device

1. Put the laptop and Android device on the bidder-controlled network. For the phone, use the trusted HTTPS address printed by `npm run cert`; restart the server after certificate setup.
2. Install the PWA in Android Chrome and allow camera and location access. Confirm screen mirroring, power and a standby device.
3. Sign in as `demo.ff.krs`, download **SYN-VIS-001** while online and confirm the 12-worker roster.
4. Practise actual airplane mode, a camera capture, device location, an offline app reload and a later sync. Restore connectivity to the same server.
5. After resetting the server, clear old device rehearsal data and download the visit again. The Android camera, GPS, trusted certificate and witnessed airplane-mode check cannot be proven by a desktop-only rehearsal.

Use only the supplied synthetic specimen files. Do not add real worker data or photographs. Keep the private TLS key on the laptop; only the local CA certificate is needed on the phone.

## Live run of show

The Committee starts the clock. Follow **S1 to S5 in order**. Each 15-minute scenario includes its final three-minute Authority configuration task. The last ten minutes are for Committee probes. A preparation guide or screenshot is not evidence of a live step.

| Clock | Flow | People / record | Outcome to make visible |
| --- | --- | --- | --- |
| 00:00–00:05 | Opening | Authority, `demo.admin.state` | Issued-data verification, actual D, local mocks and field-device readiness |
| 00:05–00:20 | S1 · Registration | `demo.op.ntr`, P-01 / P-02 / P-03; then Authority | Saved household and consent, duplicate link, unavailable-verification path; publish C1 |
| 00:20–00:35 | S2 · Field visit | `demo.ff.krs`, `demo.op.krs`, `demo.sup.krs`; then Authority | Offline encrypted visit and P-04, later sync and conflict resolution; publish C2 |
| 00:35–00:50 | S3 · Department service | `demo.op.krs`, nodal officers, `demo.dlo.krs`; then Authority | APSSDC acknowledgement, Civil Supplies assisted fallback, existing overdue case; publish C3 |
| 00:50–01:05 | S4 · Employment | Mela desk, `demo.emp.001`; then Authority | Candidate check-in, interviews, employer offer, placement follow-up; publish C4 |
| 01:05–01:20 | S5 · Education and insight | `demo.cns.edu1`, `demo.pmu.state`; then Authority | Counselling, restricted notes, referrals, live MIS queries and report; publish C5 |
| 01:20–01:30 | Committee probes | Relevant role | Repeat a flow and inspect its audit, sync, configuration or mock API evidence |

### Opening · 00:00–00:05

Show Environment readiness. Confirm the 22 issued sheets, 3,684 starting records, source verification, demonstration date D and local mock status. Confirm that the field device is installed and ready. Start the timer only when asked.

**Say:** “The source data is the issued synthetic dataset. The Government and messaging integrations shown in this environment are local mocks. We will follow the five service flows in order and show the saved result and its evidence.”

### S1 · Assisted registration · 00:05–00:20

**Operator:** `demo.op.ntr` at ILAC-NTR-01. **People:** P-01, P-02 and P-03.

1. Show the role's available services and switch English/Telugu. Issue and call P-01's walk-in token.
2. In worker registration, search BOCW before creating a record, then verify P-01 through the local e-Shram mock.
3. Try saving once without date of birth. Show that validation stops the save. Restore the issued value.
4. Capture the consent purpose, `CONSENT-DEMO-v1`, channel, timestamp and the P-01 household baseline with its four linked members.
5. Upload and classify `specimen_photo_P-01.png` and `specimen_work_certificate_P-01.png`. Issue and open the acknowledgement; show the SMS/WhatsApp records in the mock messaging log.
6. Search for P-02 as **Gorle Laxmi**, show the match to **SYN-W-000607**, and link it rather than creating another worker. Show the audit entry.
7. For P-03, allow the e-Shram timeout to complete. Finish registration and show pending verification, retry and documented next step.
8. **C1, final 3 minutes:** Authority publishes the mandatory **Primary language of worker** dropdown with Telugu / Urdu / Odia / Hindi / Other. Return to a later registration form and show the new field and version.

**Make the result visible:** One saved worker and household, consent, classified documents, acknowledgement, a linked duplicate and a completed-but-pending P-03 path.

### S2 · Offline field visit · 00:20–00:35

**Field:** Android `demo.ff.krs`. Keep `demo.op.krs` and `demo.sup.krs` in separate online sessions.

1. While online, download **SYN-VIS-001**, site **SYN-S-0006**, with all 12 T09 workers. Then enable actual airplane mode for the Committee to verify.
2. Record attendance for all 12. Mark **SYN-W-000182** and **SYN-W-000225** absent. Record the three issued skilling needs.
3. Capture a synthetic safety observation photo and device location. Save the visit on the phone.
4. Register P-04 on the device. Show its provisional ID and the encrypted-device evidence; the queue should not expose plaintext records.
5. Still offline, edit worker **SYN-W-000120** to **9000099101**. In the separate online centre session, edit the same worker to **9000099102**.
6. Restore connectivity. Show sync receipts, P-04's permanent ID, and the preserved conflict. As `demo.sup.krs`, choose a version, give a reason and inspect the audit trail.
7. Show the visit in worker history and the three needs available for a training-batch referral.
8. **C2, final 3 minutes:** Authority publishes **PPE – safety helmets available on site (Yes/No)**. Sync again and show the new checklist item on the field device.

**Make the result visible:** A real device worked offline, captured encrypted records and reconciled an independently changed centre value after reconnection.

### S3 · Department service and fallback · 00:35–00:50

**Operator:** `demo.op.krs`; prepare `demo.nodal.cs`, `demo.nodal.sk` and `demo.dlo.krs`. **Person:** P-05 / SYN-W-000608.

1. Open the household timeline and show the existing completed **LB-01** renewal. Add newborn **Bandaru Likhitha** and attach `specimen_birth_certificate_P-05.png`.
2. Create the **SK-01** APSSDC referral. Show its acknowledgement and 7-day service clock.
3. Create the **CS-01** Civil Supplies referral. Show the local **503**, automatic manual/assisted fallback, the same case ID, 21-day clock, reason and printable referral slip.
4. Show one acknowledgement containing both requests. As `demo.nodal.cs`, record receipt and document verification. As the APSSDC role, trigger and poll for **Seat confirmed**.
5. As `demo.dlo.krs`, show **SYN-R-00151** overdue and its escalation history. Open integration monitoring and the Civil Supplies error/retry evidence.
6. **C3, final 3 minutes:** Authority changes CS-01 to a **15-day** clock and L1 to **10 days**, effective for new referrals. Show that the already-open case keeps its original clock.

**Make the result visible:** The worker's request continues even when the counterpart is unavailable; a named department can continue the same case through an assisted route.

### S4 · Job mela and placement · 00:50–01:05

**Desk:** `demo.op.gnt` / `demo.dlo.gnt`. **Employer:** `demo.emp.001`. **Event:** JM-2026-01.

1. Show the event, six participating employers, 12 vacancies, 20 pre-registered candidates and shared calendar. Check in **P-07 / JMR-004**.
2. Register walk-in P-06 **Kandula Rajesh** after the no-match registry search. Check eligibility and documents, then register and check in.
3. Allocate P-06 to employer **SYN-E-001**, vacancy **SYN-V-0001**; allocate P-07 to **SYN-E-006**, vacancy **SYN-V-0006**.
4. As `demo.emp.001`, record P-06's offer using the supplied wage and engagement type, with joining D+3. Record P-07's pending employer decision and D+2 follow-up.
5. Show the linked placement, follow-up and mock notification, then the live event closure report.
6. **C4, final 3 minutes:** Authority adds **Solar panel installer** and publishes the event vacancy for **SYN-E-002**. Show the new option in event matching.

**Make the result visible:** A candidate check-in becomes a tracked interview, employer decision and, where offered, a placement with follow-up.

### S5 · Counselling and insight · 01:05–01:20

**Counsellor:** `demo.cns.edu1`. **Analyst:** `demo.pmu.state`. **Person:** P-08 / SYN-M-001909.

1. Show P-08's education stage, household and link to father **SYN-W-000609**.
2. Book a slot with **SYN-C-01** and show the appointment on the shared calendar and the reminder in the mock log.
3. Record assessment, interests, advice, agreed actions and the D+14 follow-up. Explain that counselling notes are access-restricted; do not show private notes from another role.
4. Attach `specimen_class10_memo_P-08.png`. Create **ED-02** (manual) and **ED-01** (mock API) referrals and show their clocks.
5. As the PMU, demonstrate State → district → centre drill-down; run issued MIS queries **Q1–Q5** and export one report. Point out the reporting timestamp and the minimised identifiers.
6. **C5, final 3 minutes:** Authority creates **Women workers by trade and district**, publishes it to the PMU dashboard and returns to show it there.

**Make the result visible:** A dependant's appointment and referrals connect to a household record, while the PMU sees aggregate service delivery without counsellor-only notes.

## How to make the demo clear

- **Start with the person's need.** “A worker needs help adding a family member to a service.” Then show the actual case.
- **Use the same three beats:** action, saved result, evidence. Do not narrate every button while the audience is still reading the screen.
- **Name the outcome.** For example, “The case ID stays the same while the manual team continues the request.”
- **Keep the next role ready.** Announce a handover, switch to that role's prepared session, show its worklist and complete one action.
- **Use logs to prove a point, then return to the worker's workflow.** The audit and API logs support the service story; they are not the service story.
- **Treat the clock as a hard stop.** If a step is unfinished at the slot boundary, move on; the issued pack says unfinished steps are not shown.
- **For probes, repeat live.** Open the saved record, explain its status, then show the relevant audit, queue, configuration history or mock request/response.

## What is real in this prototype

| Capability | What the demo actually does |
| --- | --- |
| Issued data | Loads the supplied synthetic CSV records and preserves the issued source files and deliberate duplicate pairs. Reset restores the rehearsal tables. |
| Staff access | Provides the 13 issued demo accounts, module access and role-specific UI. Password and OTP are demo-only. |
| Government integrations | Uses local mock endpoints based on the supplied contract. P-03 times out; Civil Supplies returns 503 during S3. No live Government system is called. |
| Messaging | Writes to the local log only. SMS / WhatsApp are not dispatched. |
| Field work | The PWA stores offline field packets encrypted on a secure origin and syncs them through the local server. Actual camera/GPS/airplane-mode behavior needs an Android rehearsal. |
| Service changes | C1–C5 are published through the Authority UI and recorded with configuration history. They are demonstration changes, not a production deployment. |
| Production status | This is a demonstration environment, not a production system. Do not claim live integrations, live messaging or production readiness. |

## Quick recovery

- **The site says the server is unavailable:** check that the local server is running and open `http://localhost:8080` on the same laptop.
- **A phone cannot install the field app:** use the trusted HTTPS address and CA created by `npm run cert`; check that the certificate has not expired and the phone trusts it.
- **A field change is not syncing:** reconnect to the same network/server, keep the field session open and inspect the encrypted sync queue before retrying.
- **The wrong rehearsal data is showing:** reset through Authority → Environment. Clear the phone's cached rehearsal data and download the assigned visit again.
- **A role cannot open a page:** check which issued account is signed in; do not broaden its permissions to make a demo step work.
- **A mock behaves unexpectedly:** open the mock API log and verify the request, status and supplied behavior. Do not work around a required failure path.

## Handover checklist

- [ ] Application starts; issued hashes and 22-sheet / 3,684-record baseline verify.
- [ ] D is set for the actual slot; offset-driven dates are rebased.
- [ ] Role sessions are separated; field phone is trusted, installed and ready.
- [ ] Camera, location, airplane mode, encrypted capture and sync have been checked on Android.
- [ ] C1–C5 are not pre-published; Civil Supplies remains unavailable for S3.
- [ ] Demo-only credentials are shared securely with the Committee; no real personal data or messages are used.
- [ ] The presenter knows the S1–S5 handovers and can return to the worker outcome after showing evidence.

**Related material:** [T-4 coverage map](tender/T4-COVERAGE.md) · [Pre-demonstration declaration template](tender/PRE-DEMONSTRATION-DECLARATION.md) · [Full client playbook](presentation/Digital_ILAC_Client_Demo_Playbook.html) · [Project setup and requirements](../README.md)

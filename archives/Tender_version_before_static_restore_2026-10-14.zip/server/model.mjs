import {randomUUID} from 'node:crypto';
import {mockCall} from './mocks.mjs';
export const PASSWORD='admin@123',OTP='123456';
export const clone=value=>JSON.parse(JSON.stringify(value));
export const day=()=>new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Kolkata',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
export const offset=(date,days)=>new Date(Date.parse(date+'T12:00:00Z')+Number(days)*86400000).toISOString().slice(0,10);
export const fail=(message,status=400)=>{const error=new Error(message);error.status=status;throw error;};
export const modules=user=>[...user.modules_enabled.matchAll(/SM-(\d+)/g)].map(m=>m[1]);
export const admin=user=>user?.login_id==='demo.admin.state';
export const id=(rows,key,prefix,width=6)=>prefix+String(Math.max(0,...rows.map(r=>Number(String(r[key]).replace(prefix,''))||0))+1).padStart(width,'0');
const OPEN_REF=['Submitted','Acknowledged by department','Query raised - awaiting worker'];
const OPEN_GR=['Open - under action','Open - escalated','Reopened'];
export function initialStore(issued){
 const tables=clone(issued.tables),config={version:1,householdFields:[],siteChecklist:[],services:clone(tables.M04_Services),civilSuppliesRestored:false,demoDay:day(),roleOverrides:{}};
 const snapshots=Object.fromEntries(tables.T10_Referrals.map(r=>[r.referral_id,clone(config.services.find(s=>s.service_code===r.service_code))]));
 return {datasetVersion:'1.0',resetId:randomUUID(),tables,config,serviceSnapshots:snapshots,documents:[],audit:[],mockLogs:[],messages:[],tokens:[],retries:[],histories:[],registrations:[],visits:[],conflicts:[],interviews:[],offers:[],placements:[],appointments:[],sessions:[],reports:[],configHistory:[],processedSync:{},workerVersions:{},evidence:{},mockStatuses:{},skillingGroups:[],timer:null};
}
export function mark(store,step,user,detail){store.evidence[step]={shown_at:new Date().toISOString(),by:user.login_id,detail};}
export function audit(store,user,action,subject,details={}){store.audit.unshift({id:'SYN-AUD-'+randomUUID(),timestamp:new Date().toISOString(),actor:user.login_id,action,subject,details});}
export const persona=(store,pid)=>store.tables.S_Personas.find(p=>p.persona_id===pid)||fail('Unknown issued persona.');
export function personaWorker(store,pid){
 const fixed={'P-02':'SYN-W-000607','P-05':'SYN-W-000608','P-07':'SYN-W-000302','P-08':'SYN-W-000609'};
 return store.tables.T01_Workers.find(w=>w.worker_id===fixed[pid]||w.persona_id===pid);
}
export function visibleWorkers(store,user){
 const all=store.tables.T01_Workers,login=user.login_id;
 if(admin(user)||login==='demo.pmu.state')return all;
 if(login==='demo.cns.edu1')return all.filter(w=>w.home_centre_id==='ILAC-NTR-01'||store.tables.T14_Counselling_Cases.some(c=>c.counsellor_id==='SYN-C-01'&&c.household_id===w.household_id));
 if(login==='demo.emp.001'){
  const set=new Set(store.interviews.filter(i=>i.employer_id==='SYN-E-001').map(i=>i.worker_id));return all.filter(w=>set.has(w.worker_id));
 }
 if(login.startsWith('demo.nodal.')){
  const department=login.endsWith('.cs')?'Civil Supplies, GoAP':'APSSDC, GoAP';
  const set=new Set(store.tables.T10_Referrals.filter(r=>r.department===department&&(login.endsWith('.sk')||r.district_code==='KRS')).map(r=>r.worker_id));return all.filter(w=>set.has(w.worker_id));
 }
 if(['demo.op.gnt','demo.dlo.gnt'].includes(login)){
  const set=new Set(store.tables.T08_JobMela_Candidates.map(c=>c.worker_id));return all.filter(w=>set.has(w.worker_id)||w.home_centre_id==='ILAC-GNT-01');
 }
 if(login==='demo.op.krs'||login==='demo.sup.krs'){
  const set=new Set(store.tables.T09_Worksite_Visit_S2.map(r=>r.worker_id));return all.filter(w=>w.home_centre_id==='ILAC-KRS-01'||set.has(w.worker_id));
 }
 if(user.jurisdiction.startsWith('District: '))return all.filter(w=>w.district_code===user.jurisdiction.slice(10));
 return all.filter(w=>w.home_centre_id===user.jurisdiction);
}
export function canAct(user,action){
 const login=user?.login_id;
 if(action.startsWith('config.')||['environment.day','environment.reset','timer.start','timer.reset','mock.restore'].includes(action))return admin(user);
 const allow={
  'token.issue':['demo.op.ntr','demo.op.krs','demo.op.gnt'],'token.call':['demo.op.ntr','demo.op.krs','demo.op.gnt'],
  'worker.register':['demo.op.ntr','demo.op.gnt','demo.ff.krs'],'worker.acknowledge':['demo.op.ntr','demo.op.gnt','demo.ff.krs'],'worker.duplicate-link':['demo.op.ntr'],
  'worker.mobile':['demo.op.krs'],'field.download':['demo.ff.krs'],'field.sync':['demo.ff.krs'],'field.offline-observed':['demo.ff.krs'],'field.group':['demo.ff.krs'],
  'conflict.resolve':['demo.sup.krs'],'household.child':['demo.op.krs'],
  'referral.create':['demo.op.krs','demo.cns.edu1'],'referral.receive':['demo.nodal.cs'],'referral.poll':['demo.op.krs','demo.nodal.sk'],
  'mock.confirm-seat':['demo.op.krs','demo.nodal.sk'],'referral.reconcile':['demo.op.krs','demo.nodal.cs'],
  'mela.checkin':['demo.op.gnt','demo.dlo.gnt'],'mela.register':['demo.op.gnt'],'mela.interview':['demo.op.gnt','demo.dlo.gnt'],
  'mela.offer':['demo.emp.001'],'mela.pending':['demo.op.gnt','demo.dlo.gnt'],
  'counselling.book':['demo.cns.edu1'],'counselling.session':['demo.cns.edu1'],'counselling.followup':['demo.cns.edu1'],
  'document.upload':['demo.op.ntr','demo.op.krs','demo.op.gnt','demo.ff.krs','demo.cns.edu1'],
  'evidence.language':['demo.op.ntr'],'evidence.validation':['demo.op.ntr'],'evidence.mis':['demo.pmu.state'],
  'evidence.integration':['demo.op.krs','demo.dlo.krs'],'evidence.mela':['demo.op.gnt','demo.dlo.gnt'],'evidence.drilldown':['demo.pmu.state','demo.dlo.krs','demo.dlo.gnt'],
  'report.save':['demo.pmu.state'],'permissions.save':[]
 };
 return (allow[action]||[]).includes(login);
}
const requireFields=(object,fields)=>{for(const name of fields)if(object[name]===undefined||object[name]===null||String(object[name]).trim()==='')fail(`${name.replaceAll('_',' ')} is required.`);};
const workerAccess=(store,user,wid)=>visibleWorkers(store,user).find(w=>w.worker_id===wid)||fail('Worker is outside your jurisdiction.',403);
const history=(store,wid,title,details)=>store.histories.unshift({worker_id:wid,title,details,timestamp:new Date().toISOString()});
async function message(store,user,to,template,params={},language='te'){
 const body={channel:'SMS',to,template_id:template,language,params};
 await mockCall(store,'/messaging/v1/messages',body,'POST',user.login_id);
 if(template==='ACK_REGISTRATION_TE')await mockCall(store,'/messaging/v1/messages',{...body,channel:'WHATSAPP'},'POST',user.login_id);
}
function householdMembers(p){
 if(p.persona_id!=='P-01')return [];
 return p.household.split('; ').map(text=>{
  const m=text.match(/^(Spouse|Son|Daughter|Mother): (.*?) \(([MF]), (\d{4}-\d{2}-\d{2}), (.*)\)$/);
  if(!m)fail('Issued household card could not be parsed.');
  const split=m[5].lastIndexOf(', ');
  return {relationship_to_head:m[1],full_name:m[2],gender:m[3]==='F'?'Female':'Male',date_of_birth:m[4],education_stage:split>=0?m[5].slice(0,split):m[5],occupation:split>=0?m[5].slice(split+2):''};
 });
}
async function register(store,user,payload){
 const p=persona(store,payload.persona_id);
 const permitted={'demo.op.ntr':['P-01','P-03'],'demo.ff.krs':['P-04'],'demo.op.gnt':['P-06']};
 if(!permitted[user.login_id]?.includes(p.persona_id))fail('This persona is not assigned to this registration desk.',403);
 const input={...p,...payload};requireFields(input,['full_name_en','date_of_birth','mobile','consent','consent_purpose']);
 if(['P-03','P-06'].includes(p.persona_id)&&(!input.photo?.base64||input.photo.name!==`specimen_photo_${p.persona_id}.png`))fail('Upload the issued '+p.persona_id+' photograph.');
 if(input.consent!==true&&input.consent!=='yes')fail('Record consent before saving.');
 if(input.date_of_birth!==p.date_of_birth||input.mobile!==p.mobile||input.full_name_en!==p.full_name_en)fail('Use the exact issued persona values for scripted registration.');
 for(const field of store.config.householdFields){if(field.required&&!input[field.key])fail(field.label+' is required.');if(input[field.key]&&field.options&&!field.options.includes(input[field.key]))fail('Choose a configured option for '+field.label+'.');}
 if(personaWorker(store,p.persona_id))fail('This persona is already registered; open the existing acknowledgement.',409);
 const search=await mockCall(store,'/bocw/v1/workers/search',{full_name:input.full_name_en,date_of_birth:input.date_of_birth,mobile:input.mobile,uid_token:p.uid_token_mock},'POST',user.login_id);
 if(search.body.matches.length)fail('Potential duplicate: link an existing worker instead of creating another record.',409);
 const auth=await mockCall(store,'/uidai/v1/auth',{uid_token:p.uid_token_mock,otp:input.otp||OTP,consent_id:'CONSENT-DEMO-v1'},'POST',user.login_id);
 if(auth.body.auth_status!=='SUCCESS')fail('Mock OTP is incorrect.');
 const latest=store.mockLogs.find(l=>l.path==='/mock/eshram/v1/verify'&&l.request.uid_token===p.uid_token_mock&&(l.status!=='Pending'||l.expected_behaviour&&Date.now()-Date.parse(l.timestamp)>=10000));
 const verified=latest?{status:latest.status==='Pending'?504:latest.status,body:latest.response||{error:'External system unavailable'}}:await mockCall(store,'/eshram/v1/verify',{uid_token:p.uid_token_mock,mobile:p.mobile,occupation:p.trade},'POST',user.login_id);
 if(personaWorker(store,p.persona_id))fail('This persona was registered in another session; no second master was created.',409);
 const wid=id(store.tables.T01_Workers,'worker_id','SYN-W-'),hid=id(store.tables.T02_Households,'household_id','SYN-H-');
 const code=p.persona_id==='P-04'?'KRS':p.persona_id==='P-06'?'GNT':'NTR',district=store.tables.M01_Districts.find(d=>d.district_code===code);
 const trade=store.tables.M03_Trades.find(t=>t.trade_name===p.trade);
 const worker={worker_id:wid,bocw_registration_no:`SYN/BOCW/${code}/${store.config.demoDay.slice(0,4)}/${wid.slice(-6)}`,surname:p.full_name_en.split(' ')[0],given_name:p.full_name_en.split(' ').slice(1).join(' '),full_name:p.full_name_en,full_name_te:p.full_name_te,gender:p.gender,date_of_birth:p.date_of_birth,mobile:p.mobile,aadhaar_masked:p.aadhaar_masked,uid_token_mock:p.uid_token_mock,eshram_uan_token_mock:verified.status===200?verified.body.uan_token:'',district_code:code,district_name:district.district_name,home_centre_id:`ILAC-${code}-01`,household_id:hid,primary_trade:p.trade,trade_code:trade?.trade_code||'',years_experience:p.years_experience,registration_date:store.config.demoDay,registration_status:'Active',bank_account_held:p.bank_account_held,smartphone:p.smartphone,consent_version:'CONSENT-DEMO-v1',consent_captured_on:new Date().toISOString(),skilling_need_flag:'No',enrolled_batch_id:'',record_origin:p.scenario,persona_id:p.persona_id,verification_status:verified.status===200?'Verified':'Pending - external system unavailable'};
 const members=householdMembers(p);
 if(input.members&&p.persona_id==='P-01')for(let i=0;i<members.length;i++)for(const key of Object.keys(members[i]))if(input.members[i]?.[key]!==members[i][key])fail('Capture the four members exactly as issued on P-01.');
 const household={household_id:hid,district_code:code,district_name:district.district_name,household_head_name:p.full_name_en,member_count:String(1+members.length),baseline_survey_date:store.config.demoDay,baseline_source_card:p.household_baseline,...(payload.baseline||{})};
 for(const field of store.config.householdFields)household[field.key]=input[field.key];
 store.tables.T01_Workers.push(worker);store.tables.T02_Households.push(household);
 if(input.photo&&p.persona_id!=='P-04')store.documents.push({id:'SYN-DOC-'+(store.documents.length+1),name:input.photo.name,classification:'Photo',worker_id:wid,uploaded_by:user.login_id,uploaded_at:new Date().toISOString(),base64:input.photo.base64,mime_type:'image/png',access:'Assigned jurisdiction'});
 store.tables.T03_Members.push({member_id:id(store.tables.T03_Members,'member_id','SYN-M-'),household_id:hid,full_name:p.full_name_en,relationship_to_head:'Self (head)',gender:p.gender,date_of_birth:p.date_of_birth,education_stage:'',occupation:'Registered construction worker',linked_worker_id:wid});
 for(const m of members)store.tables.T03_Members.push({member_id:id(store.tables.T03_Members,'member_id','SYN-M-'),household_id:hid,...m,linked_worker_id:''});
 const consent={purpose:input.consent_purpose,notice_version:'CONSENT-DEMO-v1',channel:input.consent_channel||'Assisted desk',timestamp:worker.consent_captured_on,actor:user.login_id};
 const nextStep=verified.status===200?{owner:user.login_id,action:'Keep the acknowledgement and contact the ILAC centre for the next service.',target_date:store.config.demoDay,documents:p.documents_to_upload,route:worker.home_centre_id}:{owner:user.login_id,action:'Retry e-Shram verification when the external system is available.',target_date:offset(store.config.demoDay,1),documents:p.documents_to_upload,route:worker.home_centre_id};
 store.registrations.push({worker_id:wid,household_id:hid,persona_id:p.persona_id,consent,nextStep,form_version:store.config.version,ack_issued:p.persona_id!=='P-01'});
 if(verified.status!==200)store.retries.push({id:'SYN-RETRY-'+wid,worker_id:wid,interface:'e-Shram',status:'Queued',reason:'External system unavailable',nextStep});
 history(store,wid,'Registration and household baseline captured',{household_id:hid,consent,verification_status:worker.verification_status});
 audit(store,user,'Worker registered',wid,{persona_id:p.persona_id,household_id:hid,verification_status:worker.verification_status});
 if(p.persona_id!=='P-01')await message(store,user,p.mobile,'ACK_REGISTRATION_TE',{worker_id:wid,household_id:hid,text:`నమోదు పూర్తయింది. కార్మిక సంఖ్య ${wid}. ILAC కేంద్రంలో తదుపరి సహాయం పొందండి.`});
 if(p.persona_id==='P-01'){for(const step of ['1.3','1.4','1.5','1.6'])mark(store,step,user,{worker_id:wid});}
 if(p.persona_id==='P-03')mark(store,'1.10',user,{worker_id:wid,verification_status:worker.verification_status,nextStep});
 return {worker,household,consent,nextStep};
}
export function enrichedReferral(store,row){
 const rule=store.serviceSnapshots[row.referral_id]||store.config.services.find(s=>s.service_code===row.service_code);
 const created=offset(store.config.demoDay,row.created_offset_days),due=offset(store.config.demoDay,row.due_offset_days);
 const open=OPEN_REF.includes(row.status),age=-Number(row.created_offset_days),escalations=[];
 if(open&&age>=Number(rule?.escalation_L1_after_days))escalations.push({level:'L1',date:offset(created,rule.escalation_L1_after_days),to:rule.escalation_L1_to.replace('demo.dlo.<district>','demo.dlo.'+row.district_code.toLowerCase()),basis:'Derived from issued offset and frozen service clock'});
 if(open&&age>=Number(rule?.escalation_L2_after_days))escalations.push({level:'L2',date:offset(created,rule.escalation_L2_after_days),to:rule.escalation_L2_to,basis:'Derived from issued offset and frozen service clock'});
 return {...row,created_on:created,due_on:due,overdue:open&&Number(row.due_offset_days)<0,service_rule_version:row.service_rule_version||1,escalations};
}
async function createReferral(store,user,payload){
 requireFields(payload,['worker_id','service_code']);const worker=workerAccess(store,user,payload.worker_id);
 if(user.login_id==='demo.cns.edu1'&&!['ED-01','ED-02'].includes(payload.service_code))fail('Counsellor can issue education referrals only.',403);
 if(user.login_id==='demo.op.krs'&&worker.district_code!=='KRS')fail('Krishna referral jurisdiction required.',403);
 const service=store.config.services.find(s=>s.service_code===payload.service_code)||fail('Unknown issued service.');
 const rid=id(store.tables.T10_Referrals,'referral_id','SYN-R-',5),days=Number(service.service_clock_days);
 const endpoints={'LB-01':`/bocw/v1/registrations/${encodeURIComponent(worker.bocw_registration_no)}/renewal`,'SK-01':'/apssdc/v1/enrolments','SK-02':'/apssdc/v1/enrolments','CS-01':'/civilsupplies/v1/ricecard/member-additions','ED-01':'/education/v1/scholarship-referrals','GS-01':'/gsws/v1/service-requests','NC-01':'/ncs/v1/jobseekers'};
 const request={ilac_case_id:rid,worker_id:worker.worker_id,service_code:service.service_code,centre_id:worker.home_centre_id,consent_id:'CONSENT-DEMO-v1',documents:payload.documents||[],...payload};
 let response=null;
 if(endpoints[service.service_code])response=await mockCall(store,endpoints[service.service_code],request,'POST',user.login_id);
 const fallback=response&&response.status>=400;
 const row={referral_id:rid,worker_id:worker.worker_id,member_id:payload.member_id||'',service_code:service.service_code,department:service.department,district_code:worker.district_code,centre_id:worker.home_centre_id,created_offset_days:'0',created_on_nominal:store.config.demoDay,service_clock_days:String(days),due_offset_days:String(days),due_on_nominal:offset(store.config.demoDay,days),channel:fallback?'Manual / assisted fallback':response?'API (mock)':'Manual',external_ack_no:response?.body.external_ack_no||'',status:response&&!fallback?'Acknowledged by department':'Submitted',closed_offset_days:'',responsible_officer:service.service_code.startsWith('CS-')?'demo.nodal.cs':service.service_code.startsWith('SK-')?'demo.nodal.sk':'demo.cns.edu1',fallback_reason:fallback?'API unavailable':'',service_rule_version:store.config.version,next_step:fallback?'Print the referral slip; submit the documents at the Civil Supplies desk.':'Follow the assigned office and retain the acknowledgement.',documents:payload.documents||[]};
 store.tables.T10_Referrals.push(row);store.serviceSnapshots[rid]=clone(service);
 history(store,worker.worker_id,service.service_name,{referral_id:rid,channel:row.channel,due_on:row.due_on_nominal,next_step:row.next_step,member_id:payload.member_id});
 audit(store,user,'Convergence referral created',rid,{channel:row.channel,request,response:response?.body,clock_snapshot:service});
 mark(store,user.login_id==='demo.cns.edu1'?'5.4':service.service_code==='SK-01'?'3.3':'3.4',user,{referral_id:rid});
 if(user.login_id==='demo.op.krs'&&store.tables.T10_Referrals.filter(r=>r.worker_id===worker.worker_id&&r.created_offset_days==='0').length>=2)mark(store,'3.5',user,{worker_id:worker.worker_id});
 return enrichedReferral(store,row);
}
function group(rows,keys){const grouped=new Map();for(const row of rows){const values=keys.map(key=>row[key]),key=JSON.stringify(values);grouped.set(key,{...Object.fromEntries(keys.map((k,i)=>[k,values[i]])),count:(grouped.get(key)?.count||0)+1});}return [...grouped.values()].sort((a,b)=>b.count-a.count||String(a[keys[0]]).localeCompare(String(b[keys[0]])));}
export function mis(store,issued,qid){
 const b=issued.tables;let rows,results,source;
 if(qid==='Q1'){rows=b.T01_Workers.filter(w=>w.gender==='Female'&&w.registration_status==='Active');results=group(rows,['district_name']);source='As loaded; raw records; seeded duplicates retained';}
 else if(qid==='Q2'){rows=store.tables.T10_Referrals.filter(r=>OPEN_REF.includes(r.status)&&Number(r.due_offset_days)<0);results=group(rows,['department']);source='As on D; open status set; due_offset_days < 0';}
 else if(qid==='Q3'){rows=b.T08_JobMela_Candidates.filter(r=>r.event_id==='JM-2026-01');results=group(rows,['primary_trade']);source='As loaded; excludes walk-ins recorded during demonstration';}
 else if(qid==='Q4'){rows=store.tables.T11_Grievances.filter(r=>OPEN_GR.includes(r.status)&&Number(r.created_offset_days)<-30);results=group(rows,['category']);source='As on D; strictly older than 30 days';}
 else if(qid==='Q5'){rows=b.T01_Workers.filter(w=>w.district_code==='KRS'&&w.registration_status==='Active'&&w.skilling_need_flag==='Yes'&&!w.enrolled_batch_id);results=group(rows,['primary_trade']);source='As loaded; before S2 updates';}
 else fail('Unknown issued MIS query.');
 return {query_id:qid,total:rows.length,results,top5:qid==='Q1'?results.slice(0,5):undefined,source,reporting_timestamp:new Date().toISOString(),demo_day:store.config.demoDay};
}
export async function act(store,issued,user,action,payload={}){
 if(!canAct(user,action))fail('Action is outside the issued role permissions.',403);
 if(action==='evidence.language'){mark(store,'1.1',user,{language:payload.language});return {saved:true};}
 if(action==='evidence.validation'){mark(store,'1.4.validation',user,{message:'Date of birth is required.'});return {saved:true};}
 if(action==='evidence.mis'){mark(store,'5.7',user,{query_id:payload.query_id});return mis(store,issued,payload.query_id);}
 if(action==='evidence.integration'){mark(store,'3.9',user,{counterpart:'D15',status:store.config.civilSuppliesRestored?'Restored':'HTTP 503',retry_after:3600});return {recorded:true};}
 if(action==='evidence.mela'){mark(store,'4.8',user,eventDashboard(store));return eventDashboard(store);}
 if(action==='evidence.drilldown'){mark(store,'5.6',user,{district:payload.district||'State',centre:payload.centre||'All centres'});return {recorded:true};}
 if(action==='environment.day'){
  requireFields(payload,['demoDay']);if(!/^\d{4}-\d{2}-\d{2}$/.test(payload.demoDay)||!Number.isFinite(Date.parse(payload.demoDay)))fail('Use a valid demonstration date.');
  if(store.audit.some(a=>!a.action.startsWith('Configuration')&&!a.action.startsWith('Demo date')))fail('Set D before starting; reset rehearsal first to change the date.');
  store.config.demoDay=payload.demoDay;audit(store,user,'Demo date set',payload.demoDay,{nominal_day:issued.nominalDemoDay});return store.config;
 }
 if(action==='timer.start'){store.timer={started_at:Date.now()};return store.timer;}
 if(action==='timer.reset'){store.timer=null;return {reset:true};}
 if(action==='config.household'){
  if(payload.label!=='Primary language of worker'||payload.type!=='dropdown'||payload.required!==true||JSON.stringify(payload.options)!==JSON.stringify(['Telugu','Urdu','Odia','Hindi','Other']))fail('C1 requires the specified mandatory dropdown and five language options.');
  const field={key:'primary_language_of_worker',label:'Primary language of worker',type:'dropdown',options:['Telugu','Urdu','Odia','Hindi','Other'],required:true};
  store.config.householdFields=[field];return publish(store,user,'C1','Household baseline form',field);
 }
 if(action==='config.checklist'){
  if(payload.label!=='PPE – safety helmets available on site'||payload.type!=='Yes/No')fail('Use the scripted PPE checklist label and Yes/No response type.');
  const field={key:'ppe_helmets',label:'PPE – safety helmets available on site',type:'Yes/No'};
  store.config.siteChecklist=[field];return publish(store,user,'C2','Site-visit form',field);
 }
 if(action==='config.clock'){
  const service=store.config.services.find(s=>s.service_code==='CS-01'),before=clone(service);
  const clock=Number(payload.service_clock_days),l1=Number(payload.escalation_L1_after_days);
  if(!Number.isInteger(clock)||clock<1||!Number.isInteger(l1)||l1<1||l1>clock)fail('Enter valid service and L1 clock values.');
  Object.assign(service,{service_clock_days:String(clock),escalation_L1_after_days:String(l1)});
  Object.assign(store.tables.M04_Services.find(s=>s.service_code==='CS-01'),{service_clock_days:String(clock),escalation_L1_after_days:String(l1)});
  return publish(store,user,'C3','CS-01 service clock',{before,after:service,effective:'New referrals only'});
 }
 if(action==='config.trade'){
  if(payload.trade_name!=='Solar panel installer'||payload.employer_id!=='SYN-E-002'||payload.event_id!=='JM-2026-01'||Number(payload.positions)<1||Number(payload.daily_wage_offered_inr)<1)fail('Use the scripted trade, employer and event with valid vacancy values.');
  const existing=store.tables.M03_Trades.find(t=>t.trade_name==='Solar panel installer');
  if(!existing)store.tables.M03_Trades.push({trade_code:id(store.tables.M03_Trades,'trade_code','TR-',2),trade_name:'Solar panel installer',nsqf_reference:'[Authority/APSSDC mapping - not used in demo]'});
  const source=store.tables.T06_Vacancies.find(v=>v.employer_id==='SYN-E-002');
  const vacancy={...clone(source),vacancy_id:id(store.tables.T06_Vacancies,'vacancy_id','SYN-V-',4),trade_required:'Solar panel installer',employer_id:'SYN-E-002',linked_job_mela:'JM-2026-01',published_on:store.config.demoDay,positions:String(payload.positions||source.positions),daily_wage_offered_inr:String(payload.daily_wage_offered_inr||source.daily_wage_offered_inr),status:'Open'};
  store.tables.T06_Vacancies.push(vacancy);store.tables.T07_JobMela_Event[0].vacancies_offered+=', '+vacancy.vacancy_id;
  return publish(store,user,'C4','Trade and job-mela vacancy',{trade:'Solar panel installer',vacancy});
 }
 if(action==='config.report'||action==='report.save'){
  const dimensions=payload.dimensions||['district_name','primary_trade'];if(!dimensions.every(d=>['district_name','district_code','primary_trade','registration_status'].includes(d)))fail('Choose supported dataset grouping fields.');
  const report={id:'SYN-REPORT-'+(store.reports.length+1),name:payload.name||'Women workers by trade and district',gender:payload.gender||'Female',registration_status:payload.registration_status||'',dimensions,on_pmu_dashboard:true,created_by:user.login_id,created_at:new Date().toISOString()};
  if(report.name!=='Women workers by trade and district')fail('Use the scripted report name.');
  store.reports.push(report);if(admin(user))return publish(store,user,'C5','MIS report builder',report);audit(store,user,'Report saved',report.id);return report;
 }
 if(action==='config.permissions'){
  const account=store.tables.M05_Users_Roles.find(u=>u.login_id===payload.login_id)||fail('Unknown issued account.');
  if(account.login_id==='demo.admin.state')fail('Authority configuration access is retained.');
  if(!Array.isArray(payload.modules)||payload.modules.some(m=>!/^\d{2}$/.test(m)||Number(m)<1||Number(m)>22))fail('Invalid module selection.');
  store.config.roleOverrides[account.login_id]=payload.modules;return publish(store,user,'Permissions','Issued user module access',{login_id:account.login_id,modules:payload.modules});
 }
 if(action==='token.issue'){
  const p=persona(store,payload.persona_id||'P-01');const token={id:'SYN-TOKEN-'+String(store.tokens.length+1).padStart(3,'0'),persona_id:p.persona_id,full_name:p.full_name_en,centre_id:user.jurisdiction,status:'Waiting',issued_at:new Date().toISOString()};store.tokens.push(token);audit(store,user,'Walk-in token issued',token.id);return token;
 }
 if(action==='token.call'){const token=store.tokens.find(t=>t.id===payload.id&&t.centre_id===user.jurisdiction)||fail('Token is outside this desk.',403);token.status='Called';audit(store,user,'Walk-in token called',token.id);mark(store,'1.2',user,{token_id:token.id});return token;}
 if(action==='worker.duplicate-link'){
  const worker=workerAccess(store,user,payload.worker_id||'SYN-W-000607');audit(store,user,'Potential duplicate linked; existing record preserved',worker.worker_id,{typed_name:payload.typed_name||'Gorle Laxmi',match_score:0.91,source:'P-02',created:false});mark(store,'1.9',user,{worker_id:worker.worker_id});return worker;
 }
 if(action==='worker.register')return register(store,user,payload);
 if(action==='worker.acknowledge'){
  const worker=workerAccess(store,user,payload.worker_id),registration=store.registrations.find(r=>r.worker_id===worker.worker_id)||fail('Registration acknowledgement not found.');
  if(!registration.ack_issued){
   const docs=store.documents.filter(d=>d.worker_id===worker.worker_id);
   if(worker.persona_id==='P-01'&&(!docs.some(d=>d.name==='specimen_photo_P-01.png'&&d.classification==='Photo')||!docs.some(d=>d.name==='specimen_work_certificate_P-01.png'&&d.classification==='Work certificate')))fail('Upload and classify both P-01 specimens before issuing the acknowledgement.');
   await message(store,user,worker.mobile,'ACK_REGISTRATION_TE',{worker_id:worker.worker_id,household_id:worker.household_id,text:`నమోదు పూర్తయింది. కార్మిక సంఖ్య ${worker.worker_id}. ILAC కేంద్రంలో తదుపరి సహాయం పొందండి.`});registration.ack_issued=true;audit(store,user,'Registration acknowledgement issued after document capture',worker.worker_id);mark(store,'1.8',user,{worker_id:worker.worker_id});
  }return registration;
 }
 if(action==='worker.mobile'){
  const worker=workerAccess(store,user,payload.worker_id);if(!/^90000\d{5}$/.test(payload.mobile))fail('Use an issued synthetic mobile format.');
  const before=worker.mobile;worker.mobile=payload.mobile;store.workerVersions[worker.worker_id]=(store.workerVersions[worker.worker_id]||0)+1;
  audit(store,user,'Online mobile edit',worker.worker_id,{before,after:worker.mobile,version:store.workerVersions[worker.worker_id]});mark(store,'2.7.online',user,{worker_id:worker.worker_id});return worker;
 }
 if(action==='field.offline-observed'){mark(store,'2.2',user,{device_offline_at:payload.timestamp});return {observed:true};}
 if(action==='field.group'){
  const selected=payload.worker_ids||[];if(selected.length!==3||JSON.stringify([...selected].sort())!==JSON.stringify(['SYN-W-000030','SYN-W-000097','SYN-W-000183']))fail('Group the three marked workers from T09.');
  const batch=store.tables.T12_Training_Batches.find(b=>b.batch_id===payload.batch_id&&b.district_code==='KRS')||fail('Choose an issued Krishna batch.');
  for(const wid of selected)if(workerAccess(store,user,wid).skilling_need_flag!=='Yes')fail('Synchronise the skilling needs before grouping.');
  store.skillingGroups||=[];const group={id:'SYN-GROUP-'+(store.skillingGroups.length+1),worker_ids:selected,batch_id:batch.batch_id,status:'Grouped for batch referral',created_by:user.login_id};store.skillingGroups.push(group);audit(store,user,'Field skilling needs grouped for batch referral',group.id,group);return group;
 }
 if(action==='field.download'){
  mark(store,'2.1',user,{visit_id:'SYN-VIS-001',roster_count:12});
  return {visit_id:'SYN-VIS-001',site:store.tables.T05_Sites.find(s=>s.site_id==='SYN-S-0006'),roster:clone(store.tables.T09_Worksite_Visit_S2),workers:store.tables.T09_Worksite_Visit_S2.map(r=>({...clone(workerAccess(store,user,r.worker_id)),base_version:store.workerVersions[r.worker_id]||0})),personas:store.tables.S_Personas.filter(p=>p.persona_id==='P-04'),config:clone(store.config),downloaded_at:new Date().toISOString(),reset_id:store.resetId};
 }
 if(action==='field.sync'){
  const results=[];for(const item of payload.items||[]){
   if(store.processedSync[item.id]){results.push(store.processedSync[item.id]);continue;}
   if(item.reset_id!==store.resetId)fail('Device queue belongs to an earlier rehearsal; clear and download this visit again.',409);
   let result;
   if(item.type==='offline-evidence'){
    mark(store,'2.2',user,{device_offline_at:item.payload.timestamp});result={id:item.id,status:'Synced'};
   }else if(item.type==='registration'){
    const registered=await register(store,user,item.payload);
    if(item.payload.photo)store.documents.push({id:'SYN-DOC-'+(store.documents.length+1),name:'specimen_photo_P-04.png',source_filename:item.payload.photo.name,classification:'Photo',worker_id:registered.worker.worker_id,uploaded_by:user.login_id,uploaded_at:new Date().toISOString(),source:'Device capture',base64:item.payload.photo.base64,mime_type:['image/png','image/jpeg','image/webp'].includes(item.payload.photo.type)?item.payload.photo.type:'image/png'});
    result={id:item.id,status:'Synced',provisional_id:item.provisional_id,worker_id:registered.worker.worker_id};mark(store,'2.6',user,{provisional_id:item.provisional_id,encrypted_on_device:true});mark(store,'2.8',user,result);
   }else if(item.type==='mobile'){
    const worker=workerAccess(store,user,item.payload.worker_id),currentVersion=store.workerVersions[worker.worker_id]||0;
    if(currentVersion!==item.payload.base_version&&worker.mobile!==item.payload.mobile){
     const conflict={id:'SYN-CONFLICT-'+(store.conflicts.length+1),worker_id:worker.worker_id,field:'mobile',base_value:item.payload.base_mobile,field_value:item.payload.mobile,centre_value:worker.mobile,field_actor:user.login_id,centre_actor:'demo.op.krs',status:'Needs supervisor review',created_at:new Date().toISOString()};store.conflicts.push(conflict);audit(store,user,'Synchronisation conflict preserved',worker.worker_id,conflict);result={id:item.id,status:'Conflict',conflict_id:conflict.id};
    }else{const before=worker.mobile;worker.mobile=item.payload.mobile;store.workerVersions[worker.worker_id]=currentVersion+1;audit(store,user,'Field mobile edit synchronised',worker.worker_id,{before,after:worker.mobile});result={id:item.id,status:'Synced'};}
    mark(store,'2.7.field',user,{worker_id:worker.worker_id});
    if(store.evidence['2.7.online'])mark(store,'2.7',user,{worker_id:worker.worker_id,field_value:item.payload.mobile,centre_edit:store.evidence['2.7.online']});
   }else if(item.type==='visit'){
    const p=item.payload;requireFields(p,['observation','location','photo']);if(p.attendance?.length!==12)fail('Record attendance for all 12 assigned roster workers.');
    const absent=p.attendance.filter(a=>a.status==='Absent').map(a=>a.worker_id).sort();if(JSON.stringify(absent)!==JSON.stringify(['SYN-W-000182','SYN-W-000225'])||p.attendance.some(a=>!['Present','Absent'].includes(a.status)))fail('Follow the issued attendance outcomes.');
    const needIds=(p.skilling_needs||[]).map(n=>n.worker_id).sort();if(JSON.stringify(needIds)!==JSON.stringify(['SYN-W-000030','SYN-W-000097','SYN-W-000183']))fail('Capture the three marked skilling needs from T09.');
    const ids=new Set(store.tables.T09_Worksite_Visit_S2.map(r=>r.worker_id));if(new Set(p.attendance.map(a=>a.worker_id)).size!==12||p.attendance.some(a=>!ids.has(a.worker_id)))fail('Attendance must match the issued roster exactly.');
    const visit={...p,visit_id:'SYN-VIS-001',site_id:'SYN-S-0006',actor:user.login_id,recorded_at:item.created_at,synced_at:new Date().toISOString(),form_version:item.config_version};store.visits.push(visit);
    for(const record of p.attendance){const worker=workerAccess(store,user,record.worker_id);history(store,worker.worker_id,'SYN-VIS-001 worksite visit',{attendance:record.status,observation:p.observation,location:p.location});}
    for(const need of p.skilling_needs||[]){const worker=workerAccess(store,user,need.worker_id);worker.skilling_need_flag='Yes';worker.skilling_need_note=need.need;history(store,worker.worker_id,'Skilling need captured',need);}
    for(const step of ['2.3','2.4','2.5','2.10'])mark(store,step,user,{visit_id:visit.visit_id});audit(store,user,'Offline visit synchronised',visit.visit_id,{roster_count:12,skilling_needs:p.skilling_needs,photo:p.photo.name,location:p.location});result={id:item.id,status:'Synced',visit_id:visit.visit_id};
   }else fail('Unsupported field queue type.');
   store.processedSync[item.id]=result;results.push(result);
  }
  if(store.config.siteChecklist.length)mark(store,'C2.device',user,{received_version:store.config.version});
  return {results,config:clone(store.config),synced_at:new Date().toISOString()};
 }
 if(action==='conflict.resolve'){
  requireFields(payload,['id','choice','reason']);const conflict=store.conflicts.find(c=>c.id===payload.id)||fail('Unknown sync conflict.');
  const worker=workerAccess(store,user,conflict.worker_id),chosen=payload.choice==='field'?conflict.field_value:payload.choice==='centre'?conflict.centre_value:fail('Choose one preserved version.');
  if(conflict.status!=='Needs supervisor review')fail('Conflict was already resolved.',409);
  worker.mobile=chosen;store.workerVersions[worker.worker_id]=(store.workerVersions[worker.worker_id]||0)+1;Object.assign(conflict,{status:'Resolved',chosen,reason:payload.reason,resolved_by:user.login_id,resolved_at:new Date().toISOString()});audit(store,user,'Conflict resolved with reason',worker.worker_id,clone(conflict));mark(store,'2.9',user,{conflict_id:conflict.id});return conflict;
 }
 if(action==='household.child'){
  const worker=workerAccess(store,user,'SYN-W-000608');requireFields(payload,['full_name','date_of_birth']);
  if(payload.full_name!=='Bandaru Likhitha'||payload.date_of_birth!==offset(store.config.demoDay,-60))fail('Use the scripted daughter name and D−60 date of birth.');
  if(store.tables.T03_Members.some(m=>m.household_id===worker.household_id&&m.full_name===payload.full_name))fail('Bandaru Likhitha is already linked.',409);
  const member={member_id:id(store.tables.T03_Members,'member_id','SYN-M-'),household_id:worker.household_id,full_name:payload.full_name,relationship_to_head:'Daughter',gender:'Female',date_of_birth:payload.date_of_birth,education_stage:'',occupation:'',linked_worker_id:''};store.tables.T03_Members.push(member);
  const house=store.tables.T02_Households.find(h=>h.household_id===worker.household_id);house.member_count=String(Number(house.member_count)+1);history(store,worker.worker_id,'New-born daughter added',member);audit(store,user,'Household member linked',member.member_id,member);mark(store,'3.2',user,{member_id:member.member_id});return member;
 }
 if(action==='referral.create')return createReferral(store,user,payload);
 if(['referral.receive','referral.poll','referral.reconcile','mock.confirm-seat'].includes(action)){
  const row=store.tables.T10_Referrals.find(r=>r.referral_id===payload.referral_id)||fail('Unknown referral.');workerAccess(store,user,row.worker_id);
  if(action==='referral.receive'){
   if(row.department!=='Civil Supplies, GoAP'||row.district_code!=='KRS')fail('Outside Civil Supplies worklist.',403);
   requireFields(payload,['evidence']);row.status='Acknowledged by department';row.manual_update='Received – documents verified';row.evidence=payload.evidence;audit(store,user,row.manual_update,row.referral_id,{evidence:payload.evidence});mark(store,'3.6',user,{referral_id:row.referral_id});
  }else if(action==='mock.confirm-seat'){
   if(row.department!=='APSSDC, GoAP')fail('APSSDC referral required.');store.mockStatuses[row.external_ack_no]='SEAT_CONFIRMED';audit(store,user,'APSSDC mock status trigger',row.referral_id,{external_ack_no:row.external_ack_no});
  }else if(action==='referral.poll'){
   if(!row.external_ack_no||row.department!=='APSSDC, GoAP')fail('API acknowledgement required.');const response=await mockCall(store,`/apssdc/v1/enrolments/${encodeURIComponent(row.external_ack_no)}/status`,{},'GET',user.login_id);row.external_status=response.body.status;if(response.body.status==='SEAT_CONFIRMED'){row.display_status='Seat confirmed';mark(store,'3.7',user,{referral_id:row.referral_id});}audit(store,user,'APSSDC status polled',row.referral_id,response.body);
  }else{
   if(!store.config.civilSuppliesRestored)fail('Restore the Civil Supplies mock only after the Committee requests it.');
   const response=await mockCall(store,'/civilsupplies/v1/ricecard/member-additions',{ilac_case_id:row.referral_id,worker_id:row.worker_id,service_code:row.service_code},'POST',user.login_id);
   row.external_ack_no=response.body.external_ack_no;row.reconciled_at=new Date().toISOString();audit(store,user,'Manual case reconciled with same ILAC case ID',row.referral_id,response.body);
  }return enrichedReferral(store,row);
 }
 if(action==='mock.restore'){if(payload.restored&&(payload.committee_requested!==true||!payload.reason?.trim()))fail('Record the Committee restore instruction before changing S3 outage behaviour.');store.config.civilSuppliesRestored=Boolean(payload.restored);audit(store,user,'Committee-triggered Civil Supplies restore','D15',{restored:store.config.civilSuppliesRestored,reason:payload.reason||'Restore required S3 outage'});return {restored:store.config.civilSuppliesRestored};}
 if(action==='mela.register'){
  const worker=personaWorker(store,'P-06')||fail('Register P-06 at the walk-in desk first.');
  if(store.tables.T08_JobMela_Candidates.some(c=>c.worker_id===worker.worker_id))fail('Candidate is already registered.',409);
  if(payload.documents_checked!==true)fail('Complete the eligibility and document check.');
  if(!store.documents.some(d=>d.worker_id===worker.worker_id&&d.name==='specimen_photo_P-06.png'&&d.classification==='Photo'))fail('Complete the issued P-06 photograph check before event registration.');
  const candidate={registration_id:id(store.tables.T08_JobMela_Candidates,'registration_id','JMR-',3),event_id:'JM-2026-01',worker_id:worker.worker_id,full_name:worker.full_name,primary_trade:worker.primary_trade,district_code:worker.district_code,registered_on:store.config.demoDay,registration_channel:'Walk-in assisted desk',preferred_vacancy_id:'SYN-V-0001',check_in_status:'Checked in',eligibility_documents_checked:true};store.tables.T08_JobMela_Candidates.push(candidate);
  await mockCall(store,'/ncs/v1/jobseekers',{worker_id:worker.worker_id,uid_token:worker.uid_token_mock,full_name:worker.full_name,mobile:worker.mobile},'POST',user.login_id);audit(store,user,'Walk-in mela registration and check-in',candidate.registration_id,{worker_id:worker.worker_id});mark(store,'4.3',user,{registration_id:candidate.registration_id});return candidate;
 }
 if(action==='mela.checkin'){
  const candidate=store.tables.T08_JobMela_Candidates.find(c=>c.registration_id===payload.registration_id||c.worker_id===payload.worker_id)||fail('Candidate not found.');candidate.check_in_status='Checked in';candidate.checked_in_at=new Date().toISOString();audit(store,user,'Job-mela candidate checked in',candidate.registration_id);mark(store,'4.2',user,{registration_id:candidate.registration_id});return candidate;
 }
 if(action==='mela.interview'){
  requireFields(payload,['registration_id','vacancy_id','time']);const c=store.tables.T08_JobMela_Candidates.find(c=>c.registration_id===payload.registration_id)||fail('Unknown candidate.');
  const vacancy=store.tables.T06_Vacancies.find(v=>v.vacancy_id===payload.vacancy_id&&v.linked_job_mela==='JM-2026-01')||fail('Choose a vacancy on this event.');
  if(c.check_in_status!=='Checked in')fail('Check the candidate in first.');
  const interview={id:'SYN-INT-'+(store.interviews.length+1),event_id:c.event_id,registration_id:c.registration_id,worker_id:c.worker_id,full_name:c.full_name,vacancy_id:vacancy.vacancy_id,employer_id:vacancy.employer_id,time:payload.time,status:'Interview scheduled'};store.interviews.push(interview);audit(store,user,'Interview slot allocated',interview.id,interview);mark(store,'4.4',user,{interview_id:interview.id});return interview;
 }
 if(action==='mela.offer'){
  requireFields(payload,['interview_id','daily_wage_offered_inr','engagement_type','joining_date']);const interview=store.interviews.find(i=>i.id===payload.interview_id&&i.employer_id==='SYN-E-001')||fail('Candidate is outside this employer worklist.',403);
  if(payload.joining_date!==offset(store.config.demoDay,3))fail('Use joining date D+3.');
  const vacancy=store.tables.T06_Vacancies.find(v=>v.vacancy_id===interview.vacancy_id);if(Number(payload.daily_wage_offered_inr)<1)fail('Enter a positive wage.');
  if(store.offers.some(o=>o.interview_id===interview.id))fail('Spot offer already recorded.',409);
  const offer={id:'SYN-OFFER-'+(store.offers.length+1),...payload,worker_id:interview.worker_id,employer_id:interview.employer_id,vacancy_id:vacancy.vacancy_id,event_id:'JM-2026-01',status:'Spot offer recorded',recorded_by:user.login_id};store.offers.push(offer);interview.status='Spot offer recorded';
  const placement={id:'SYN-PLACEMENT-'+(store.placements.length+1),offer_id:offer.id,worker_id:interview.worker_id,employer_id:interview.employer_id,expected_joining_date:payload.joining_date,followup_date:payload.joining_date,followup_owner:'demo.op.gnt',status:'Joining follow-up due',linked_module:'SM-05'};store.placements.push(placement);
  const worker=store.tables.T01_Workers.find(w=>w.worker_id===interview.worker_id);history(store,worker.worker_id,'Spot offer and placement follow-up',{offer,placement});await message(store,user,worker.mobile,'OFFER_RECORDED_TE',{offer_id:offer.id,joining_date:payload.joining_date,text:`ఉద్యోగ ఆఫర్ నమోదైంది. చేరే తేదీ ${payload.joining_date}.`});
  audit(store,user,'Spot offer recorded',offer.id,{offer,placement});mark(store,'4.5',user,{offer_id:offer.id});mark(store,'4.7',user,{placement_id:placement.id});return {offer,placement};
 }
 if(action==='mela.pending'){
  const interview=store.interviews.find(i=>i.registration_id==='JMR-004')||fail('Allocate P-07 interview first.');interview.status='Employer decision pending';interview.followup_date=offset(store.config.demoDay,2);audit(store,user,'Interview pending with follow-up',interview.id,interview);mark(store,'4.6',user,{interview_id:interview.id});return interview;
 }
 if(action==='counselling.book'){
  requireFields(payload,['appointment_date','time']);const member=store.tables.T03_Members.find(m=>m.member_id===(payload.member_id||'SYN-M-001909'))||fail('Unknown issued household member.');const parent=visibleWorkers(store,user).find(w=>w.household_id===member.household_id)||fail('Dependant is outside the assigned counsellor view.',403);
  const weekday=new Date(payload.appointment_date+'T12:00Z').getUTCDay();if(![1,3,5].includes(weekday)||payload.time<'10:00'||payload.time>='16:00')fail('SYN-C-01 is available Mon, Wed, Fri from 10:00 to before 16:00.');
  const a={id:'SYN-APPT-'+(store.appointments.length+1),member_id:member.member_id,household_id:member.household_id,beneficiary_name:member.full_name,counsellor_id:'SYN-C-01',appointment_date:payload.appointment_date,time:payload.time,status:'Booked',created_by:user.login_id};store.appointments.push(a);
  await message(store,user,'9000099081','COUNSELLING_REMINDER_TE',{appointment_id:a.id,date:a.appointment_date,text:`విద్యా కౌన్సెలింగ్ అపాయింట్‌మెంట్ ${a.appointment_date} ${a.time}.`});audit(store,user,'Counselling appointment booked',a.id,{member_id:a.member_id,counsellor_id:a.counsellor_id});mark(store,'5.2',user,{appointment_id:a.id});return a;
 }
 if(action==='counselling.session'){
  requireFields(payload,['assessment','interests','advice','agreed_actions']);const member=store.tables.T03_Members.find(m=>m.member_id===(payload.member_id||'SYN-M-001909'))||fail('Unknown issued household member.');const parent=visibleWorkers(store,user).find(w=>w.household_id===member.household_id)||fail('Dependant is outside the assigned counsellor view.',403);
  const session={id:'SYN-SESSION-'+(store.sessions.length+1),member_id:member.member_id,household_id:member.household_id,counsellor_id:'SYN-C-01',...payload,created_by:user.login_id,recorded_at:new Date().toISOString(),followup_date:offset(store.config.demoDay,14)};store.sessions.push(session);
  const row={case_id:id(store.tables.T14_Counselling_Cases,'case_id','SYN-CC-',4),member_id:member.member_id,household_id:member.household_id,beneficiary_name:member.full_name,education_stage:member.education_stage,counsellor_id:'SYN-C-01',session_type:'Individual',session_offset_days:'0',session_on_nominal:store.config.demoDay,interest_area:payload.interests,agreed_action:payload.agreed_actions,referral_service_code:'ED-02; ED-01',case_status:'Open - action pending',followup_date:session.followup_date};store.tables.T14_Counselling_Cases.push(row);
  history(store,parent.worker_id,'Education counselling for household dependant',{member_id:member.member_id,case_id:row.case_id,followup_date:session.followup_date});audit(store,user,'Access-restricted counselling session recorded',row.case_id,{member_id:member.member_id,notes_access:'Assigned counsellor only'});mark(store,'5.3',user,{case_id:row.case_id});mark(store,'5.5',user,{followup_date:session.followup_date});return {session,case:row};
 }
 if(action==='counselling.followup'){const session=store.sessions.at(-1)||fail('Record the counselling session first.');session.followup_date=offset(store.config.demoDay,14);return session;}
 if(action==='document.upload'){
  requireFields(payload,['name','classification','worker_id']);const worker=workerAccess(store,user,payload.worker_id);
  if(!store.specimens.includes(payload.name))fail('Use one of the seven issued specimen documents.');
  const anchor=payload.name.match(/P-(\d\d)/)?.[1],expectedWorker=anchor?personaWorker(store,'P-'+anchor):null;
  if(expectedWorker&&expectedWorker.worker_id!==worker.worker_id)fail('Attach this specimen to its issued persona/household, not another worker.');
  if(payload.name==='specimen_class10_memo_P-08.png'&&user.login_id!=='demo.cns.edu1')fail('The education specimen is restricted to the assigned counsellor.',403);
  const linkedChild=payload.name==='specimen_birth_certificate_P-05.png'?store.tables.T03_Members.find(m=>m.household_id===worker.household_id&&m.full_name==='Bandaru Likhitha'):null;
  const record={id:'SYN-DOC-'+(store.documents.length+1),name:payload.name,classification:payload.classification,worker_id:worker.worker_id,member_id:payload.member_id||linkedChild?.member_id||'',uploaded_by:user.login_id,uploaded_at:new Date().toISOString(),access:'Assigned jurisdiction / counsellor'};
  if(payload.base64)record.base64=payload.base64;
  store.documents.push(record);audit(store,user,'Specimen document uploaded and classified',record.id,{name:record.name,classification:record.classification,worker_id:record.worker_id});
  if(worker.persona_id==='P-01'&&store.documents.filter(d=>d.worker_id===worker.worker_id).length>=2)mark(store,'1.7',user,{documents:store.documents.filter(d=>d.worker_id===worker.worker_id).map(d=>d.id)});
  return {...record,base64:undefined};
 }
 fail('Unsupported demonstration action.');
}
function publish(store,user,step,subject,change){
 const before=store.config.version;store.config.version++;
 const entry={id:'SYN-CFG-'+store.config.version,version:store.config.version,previous_version:before,task:step,subject,change:clone(change),published_by:user.login_id,published_at:new Date().toISOString()};store.configHistory.unshift(entry);audit(store,user,'Configuration published',subject,entry);mark(store,step,user,entry);return entry;
}
export function customReport(store,report){const rows=store.tables.T01_Workers.filter(w=>(!report.gender||w.gender===report.gender)&&(!report.registration_status||w.registration_status===report.registration_status));return {name:report.name,total:rows.length,results:group(rows,report.dimensions),reporting_timestamp:new Date().toISOString(),source:'Current issued registry plus scripted changes'};}
export function eventDashboard(store){
 const candidates=store.tables.T08_JobMela_Candidates;
 return {event_id:'JM-2026-01',registrations:candidates.length,checkins:candidates.filter(c=>c.check_in_status==='Checked in').length,interviews:store.interviews.length,offers:store.offers.length,by_employer:store.tables.T04_Employers.slice(0,6).map(e=>({employer_id:e.employer_id,employer_name:e.employer_name,interviews:store.interviews.filter(i=>i.employer_id===e.employer_id).length,offers:store.offers.filter(o=>o.employer_id===e.employer_id).length}))};
}
export function stateFor(store,issued,user){
 const workers=visibleWorkers(store,user),ids=new Set(workers.map(w=>w.worker_id)),houses=new Set(workers.map(w=>w.household_id)),login=user.login_id,isAdmin=admin(user),isPMU=login==='demo.pmu.state',isCounsellor=login==='demo.cns.edu1',isEmployer=login==='demo.emp.001';
 const referrals=store.tables.T10_Referrals.filter(r=>isAdmin||isPMU||(ids.has(r.worker_id)&&(!login.startsWith('demo.nodal.')||r.department===(login.endsWith('.cs')?'Civil Supplies, GoAP':'APSSDC, GoAP'))));
 const tables={...store.tables,T01_Workers:workers,T02_Households:store.tables.T02_Households.filter(h=>isAdmin||isPMU||houses.has(h.household_id)),T03_Members:store.tables.T03_Members.filter(m=>isAdmin||isPMU||houses.has(m.household_id)),T10_Referrals:referrals.map(r=>enrichedReferral(store,r)),T11_Grievances:store.tables.T11_Grievances.filter(g=>isAdmin||isPMU||ids.has(g.worker_id)).map(g=>({...g,created_on:offset(store.config.demoDay,g.created_offset_days),resolved_on:g.resolved_offset_days!==''?offset(store.config.demoDay,g.resolved_offset_days):''})),T12_Training_Batches:store.tables.T12_Training_Batches.map(b=>({...b,start_on:offset(store.config.demoDay,b.start_offset_days)})),T14_Counselling_Cases:isCounsellor?store.tables.T14_Counselling_Cases.filter(c=>c.counsellor_id==='SYN-C-01').map(c=>({...c,session_on:offset(store.config.demoDay,c.session_offset_days)})):[],M05_Users_Roles:isAdmin?store.tables.M05_Users_Roles:[]};
 if(isEmployer){tables.T04_Employers=store.tables.T04_Employers.filter(e=>e.employer_id==='SYN-E-001');tables.T06_Vacancies=store.tables.T06_Vacancies.filter(v=>v.employer_id==='SYN-E-001');tables.T08_JobMela_Candidates=store.tables.T08_JobMela_Candidates.filter(c=>ids.has(c.worker_id));}
 const allowed=store.config.roleOverrides[login]||modules(user);
 const eventAccess=isAdmin||['demo.op.gnt','demo.dlo.gnt','demo.emp.001'].includes(login);
 if(!eventAccess)tables.T08_JobMela_Candidates=[];
 if(!isAdmin&&!eventAccess&&!allowed.some(m=>['05','11','20'].includes(m)))tables.T04_Employers=[];
 if(!isAdmin&&!eventAccess)tables.T06_Vacancies=[];
 if(!isAdmin&&eventAccess&&!isEmployer){tables.T04_Employers=store.tables.T04_Employers.slice(0,6);tables.T06_Vacancies=store.tables.T06_Vacancies.filter(v=>v.linked_job_mela==='JM-2026-01');}
 if(!isAdmin){
  const district=user.jurisdiction.startsWith('District: ')?user.jurisdiction.slice(10):user.jurisdiction.startsWith('ILAC-')?user.jurisdiction.split('-')[1]:null;
  tables.T05_Sites=allowed.some(m=>['05','11','15','20'].includes(m))?store.tables.T05_Sites.filter(s=>isEmployer?s.employer_id==='SYN-E-001':!district||s.district_code===district):[];
  if(login==='demo.ff.krs')tables.T12_Training_Batches=tables.T12_Training_Batches.filter(b=>b.district_code==='KRS');
 }
 return {user,modules:allowed,tables,config:store.config,baselineCounts:issued.counts,currentCounts:isAdmin?Object.fromEntries(Object.entries(store.tables).map(([k,v])=>[k,v.length])):undefined,baselineTotal:3684,datasetVersion:issued.version,sourceManifest:isAdmin?issued.sourceManifest:[],resetId:store.resetId,documents:store.documents.filter(d=>isAdmin||ids.has(d.worker_id)).map(d=>({...d,base64:undefined})),audit:store.audit.filter(a=>isAdmin||a.actor===login||ids.has(a.subject)||(login==='demo.sup.krs'&&a.action.includes('mobile'))),mockLogs:store.mockLogs.filter(l=>isAdmin||l.actor===login),messages:store.messages.filter(m=>isAdmin||workers.some(w=>w.mobile===m.to)||m.to===login),tokens:store.tokens.filter(t=>isAdmin||t.centre_id===user.jurisdiction),retries:store.retries.filter(r=>isAdmin||ids.has(r.worker_id)),registrations:store.registrations.filter(r=>isAdmin||ids.has(r.worker_id)),histories:store.histories.filter(h=>ids.has(h.worker_id)),visits:store.visits.filter(v=>isAdmin||['demo.ff.krs','demo.sup.krs','demo.op.krs'].includes(login)),conflicts:store.conflicts.filter(c=>isAdmin||['demo.ff.krs','demo.sup.krs'].includes(login)),interviews:eventAccess?store.interviews.filter(i=>!isEmployer||i.employer_id==='SYN-E-001'):[],offers:eventAccess?store.offers.filter(o=>!isEmployer||o.employer_id==='SYN-E-001'):[],placements:eventAccess?store.placements.filter(p=>!isEmployer||p.employer_id==='SYN-E-001'):[],appointments:isCounsellor?store.appointments:[],sessions:isCounsellor?store.sessions.filter(s=>s.created_by===login):[],reports:store.reports,configHistory:store.configHistory,skillingGroups:isAdmin||['demo.ff.krs','demo.op.krs','demo.sup.krs'].includes(login)?store.skillingGroups||[]:[],evidence:store.evidence,eventDashboard:eventAccess?eventDashboard(store):null,timer:store.timer,serverTime:new Date().toISOString()};
}

import http from 'node:http';
import https from 'node:https';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {randomUUID,createHash} from 'node:crypto';
import {initialStore,act,stateFor,mis,customReport,modules,admin,visibleWorkers,audit,mark,fail,clone,PASSWORD,OTP} from './model.mjs';
import {mockCall,MOCK_TOKEN,mockPaths} from './mocks.mjs';
const root=fileURLToPath(new URL('../',import.meta.url)),source=path.join(root,'ILAC_Demo_Datasets_v1.0 2');
const issued=JSON.parse(fs.readFileSync(path.join(root,'data/issued-data.json'),'utf8'));
const runtime=process.env.ILAC_RUNTIME_DIR||path.join(root,'.runtime');fs.mkdirSync(runtime,{recursive:true});
const stateFile=path.join(runtime,'state.json');
const specimens=fs.readdirSync(path.join(source,'specimen_documents')).filter(name=>name.endsWith('.png'));
let store=fs.existsSync(stateFile)&&!process.env.ILAC_FRESH?JSON.parse(fs.readFileSync(stateFile,'utf8')):initialStore(issued);store.specimens=specimens;
const sessions=new Map(),challenges=new Map();
const persist=()=>{const tmp=stateFile+'.tmp';fs.writeFileSync(tmp,JSON.stringify(store));fs.renameSync(tmp,stateFile);};
const send=(res,status,body,extra={})=>{res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store',...extra});res.end(JSON.stringify(body));};
async function body(req){let data='';for await(const chunk of req){data+=chunk;if(data.length>12*1024*1024)fail('File exceeds the demonstration upload limit.',413);}try{return data?JSON.parse(data):{};}catch{fail('Invalid JSON request.');}}
function getUser(req){const token=String(req.headers.authorization||'').replace(/^Bearer /,'');const login=sessions.get(token);return store.tables.M05_Users_Roles.find(u=>u.login_id===login)||fail('Sign in to continue.',401);}
const effectiveModules=u=>store.config.roleOverrides[u.login_id]||modules(u);
const actionModule={worker:'01',token:'18',field:'11',conflict:'19',household:'07',referral:'07',mela:'15',counselling:'08',document:'01',config:'19',environment:'19',timer:'19',mock:'19',report:'13',evidence:null};
function authorizeAction(user,action){
 let mod=actionModule[action.split('.')[0]];
 if(user.login_id==='demo.op.gnt'&&['worker.register','document.upload'].includes(action))mod='15';
 if(user.login_id==='demo.cns.edu1'&&['referral.create','document.upload'].includes(action))mod='08';
 if(user.login_id==='demo.emp.001'&&action==='mela.offer')mod='05';
 if(['demo.op.krs','demo.nodal.sk'].includes(user.login_id)&&['mock.confirm-seat','referral.poll'].includes(action))mod=user.login_id==='demo.nodal.sk'?'11':'07';
 if(mod&&!effectiveModules(user).includes(mod))fail('Module access is disabled for this issued account.',403);
}
function integrity(){return issued.sourceManifest.map(f=>({...f,verified:fs.existsSync(path.join(source,f.file))&&createHash('sha256').update(fs.readFileSync(path.join(source,f.file))).digest('hex')===f.sha256}));}
const types={'.html':'text/html; charset=utf-8','.md':'text/markdown; charset=utf-8','.js':'text/javascript; charset=utf-8','.mjs':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.png':'image/png','.jpg':'image/jpeg','.svg':'image/svg+xml','.webmanifest':'application/manifest+json','.crt':'application/x-x509-ca-cert'};
async function handler(req,res){
 try{
  const url=new URL(req.url,'http://localhost'),route=url.pathname;
  if(route==='/api/health')return send(res,200,{status:'Ready',dataset:'1.0',sheets:22,records:3684,mock_paths:13,demo_day:store.config.demoDay,https:Boolean(req.socket.encrypted)});
  if(route==='/api/accounts')return send(res,200,issued.tables.M05_Users_Roles.map(u=>({login_id:u.login_id,role:u.role,jurisdiction:u.jurisdiction,used_in:u.used_in})));
  if(route==='/api/catalogue')return send(res,200,{services:store.config.services,centres:issued.tables.M02_ILAC_Centres,districts:issued.tables.M01_Districts});
  if(route==='/api/auth/challenge'&&req.method==='POST'){
   const data=await body(req),user=store.tables.M05_Users_Roles.find(u=>u.login_id===data.login_id);
   if(!user||data.password!==PASSWORD)fail('The login ID or password is incorrect.',401);
   const challenge=randomUUID();challenges.set(challenge,user.login_id);
   await mockCall(store,'/messaging/v1/messages',{channel:'SMS',to:user.login_id,template_id:'LOGIN_OTP_MOCK',language:'en',params:{otp:OTP}},'POST','Mock MFA console');persist();return send(res,200,{challenge,otp:OTP,gateway:'Mock console only'});
  }
  if(route==='/api/auth/login'&&req.method==='POST'){
   const data=await body(req),login=challenges.get(data.challenge);if(!login||data.otp!==OTP)fail('Mock OTP is incorrect.',401);
   challenges.delete(data.challenge);const token=randomUUID();sessions.set(token,login);const user=store.tables.M05_Users_Roles.find(u=>u.login_id===login);return send(res,200,{token,user,modules:effectiveModules(user)});
  }
  if(route.startsWith('/mock/')){
   const token=String(req.headers.authorization||'').replace(/^Bearer /,'');
   let actor='Static mock contract probe';if(token!==MOCK_TOKEN)actor=getUser(req).login_id;
   const data=req.method==='GET'?Object.fromEntries(url.searchParams):await body(req);
   const result=await mockCall(store,route.slice(5),data,req.method,actor);persist();
   return send(res,result.status,result.body,result.status===503?{'Retry-After':'3600'}:{});
  }
  if(route.startsWith('/api/')){
   const user=getUser(req);
   if(route==='/api/auth/logout'){sessions.delete(String(req.headers.authorization).replace(/^Bearer /,''));return send(res,200,{signed_out:true});}
   if(route==='/api/state'){
    const snapshot=stateFor(store,issued,user);if(user.login_id==='demo.op.krs')mark(store,'3.1',user,{worker_id:'SYN-W-000608'});
    if(user.login_id==='demo.dlo.krs')mark(store,'3.8',user,{referral_id:'SYN-R-00151'});
    if(['demo.op.gnt','demo.dlo.gnt'].includes(user.login_id))mark(store,'4.1',user,{event_id:'JM-2026-01'});
    if(user.login_id==='demo.cns.edu1')mark(store,'5.1',user,{member_id:'SYN-M-001909'});
    return send(res,200,snapshot);
   }
   if(route==='/api/integrity'){
    if(!admin(user))fail('Authority access required.',403);return send(res,200,{manifest:integrity(),counts:issued.counts,total:3684,loaded_snapshot_unchanged:JSON.stringify(issued.tables)===JSON.stringify(JSON.parse(fs.readFileSync(path.join(root,'data/issued-data.json'),'utf8')).tables)});
   }
   if(route==='/api/mock-contract'){if(!admin(user))fail('Authority mock console access required.',403);return send(res,200,{paths:mockPaths,token:MOCK_TOKEN});}
   if(route==='/api/actions'&&req.method==='POST'){
    const data=await body(req);authorizeAction(user,data.action);
    if(data.action==='document.upload'&&data.payload?.base64&&specimens.includes(data.payload.name)){
     const original=fs.readFileSync(path.join(source,'specimen_documents',data.payload.name)),uploaded=Buffer.from(data.payload.base64,'base64');
     if(!original.equals(uploaded))fail('Upload the unaltered issued specimen image. Device-camera captures belong to the S2 field workflow.');
    }
    if(data.action==='worker.register'&&user.login_id!=='demo.ff.krs'&&data.payload?.photo){
     const p=data.payload.photo;if(!specimens.includes(p.name)||!fs.readFileSync(path.join(source,'specimen_documents',p.name)).equals(Buffer.from(p.base64||'','base64')))fail('Use the unaltered issued registration photograph.');
    }
    if(data.action==='environment.reset'){
     if(!admin(user))fail('Authority access required.',403);const D=store.config.demoDay;store=initialStore(issued);store.config.demoDay=D;store.specimens=specimens;persist();return send(res,200,{reset:true,resetId:store.resetId});
    }
    const result=await act(store,issued,user,data.action,data.payload);persist();return send(res,200,result);
   }
   if(route==='/api/mis'){
    if(!effectiveModules(user).includes('13')&&!admin(user))fail('MIS access required.',403);
    const qid=url.searchParams.get('query')||'Q1',result=mis(store,issued,qid);mark(store,'5.7',user,{query_id:qid});persist();return send(res,200,result);
   }
   if(route==='/api/report'){
    if(user.login_id!=='demo.pmu.state'&&!admin(user))fail('PMU reporting access required.',403);
    const report=store.reports.find(r=>r.id===url.searchParams.get('id'))||fail('Saved report not found.');return send(res,200,customReport(store,report));
   }
   if(route==='/api/export'){
    if(!effectiveModules(user).includes('13')&&!admin(user))fail('Reporting access required.',403);
    const qid=url.searchParams.get('query'),rid=url.searchParams.get('report');const result=qid?mis(store,issued,qid):customReport(store,store.reports.find(r=>r.id===rid)||fail('Unknown saved report.'));
    const rows=result.results,keys=Object.keys(rows[0]||{count:0}),cell=v=>'"'+String(v??'').replace(/^[=+@-]/,"'$&").replaceAll('"','""')+'"';
    const csv='\uFEFF'+`"Reporting timestamp","${result.reporting_timestamp}"\r\n"Dataset version","1.0"\r\n`+keys.map(cell).join(',')+'\r\n'+rows.map(r=>keys.map(k=>cell(r[k])).join(',')).join('\r\n');
    mark(store,'5.8',user,{report:qid||rid,masked:true,timestamp:result.reporting_timestamp});persist();res.writeHead(200,{'Content-Type':'text/csv; charset=utf-8','Content-Disposition':`attachment; filename="ILAC-${qid||rid}-${store.config.demoDay}.csv"`});return res.end(csv);
   }
   if(route.startsWith('/api/documents/')){
    const document=store.documents.find(d=>d.id===route.split('/').at(-1))||fail('Document not found.',404);
    if(!admin(user)&&!visibleWorkers(store,user).some(w=>w.worker_id===document.worker_id))fail('Document access denied.',403);
    if(document.member_id==='SYN-M-001909'&&user.login_id!=='demo.cns.edu1')fail('Education specimen is restricted to the assigned counsellor.',403);
    audit(store,user,'Controlled document viewed',document.id);persist();
    const bytes=document.base64?Buffer.from(document.base64,'base64'):fs.readFileSync(path.join(source,'specimen_documents',document.name));res.writeHead(200,{'Content-Type':document.mime_type||'image/png','Cache-Control':'no-store'});return res.end(bytes);
   }
   return send(res,404,{error:'Unknown application endpoint.'});
  }
  if(route==='/dev-ca.crt'){
   const cert=path.join(root,'.runtime/tls/ca.crt');if(!fs.existsSync(cert))return send(res,404,{error:'Run npm run cert first.'});res.writeHead(200,{'Content-Type':types['.crt']});return res.end(fs.readFileSync(cert));
  }
  const relative=route==='/'?'index.html':decodeURIComponent(route).slice(1),file=path.resolve(root,relative);
    const allowed=relative==='index.html'||relative==='sw.js'||relative==='manifest.webmanifest'||relative.startsWith('css/')||relative.startsWith('js/tender/')||relative==='js/icons.js'||relative.startsWith('assets/')||['docs/Digital_ILAC_KT_and_Demo_Guide.html','docs/Digital_ILAC_KT_and_Demo_Guide.md','docs/Digital_ILAC_Quick_Start_and_KT.html'].includes(relative);
  if(!allowed||!file.startsWith(root)||!fs.existsSync(file)||fs.statSync(file).isDirectory())return send(res,404,{error:'File not found.'});
  res.writeHead(200,{'Content-Type':types[path.extname(file)]||'application/octet-stream','Cache-Control':relative==='sw.js'?'no-cache':'no-store','Content-Security-Policy':"default-src 'self'; img-src 'self' data: blob:; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'; object-src 'none'; frame-ancestors 'self'; base-uri 'self'"});fs.createReadStream(file).pipe(res);
 }catch(error){if(!res.writableEnded)send(res,error.status||500,{error:error.message});}
}
const port=Number(process.env.PORT||8080),host=process.env.HOST||'0.0.0.0';
http.createServer(handler).listen(port,host,()=>console.log(`Digital ILAC T-4: http://localhost:${port} — 22 sheets / 3,684 issued records; all 13 mocks are local.`));
const certDir=path.join(root,'.runtime/tls');
if(fs.existsSync(path.join(certDir,'server.crt')))https.createServer({key:fs.readFileSync(path.join(certDir,'server.key')),cert:fs.readFileSync(path.join(certDir,'server.crt'))},handler).listen(Number(process.env.HTTPS_PORT||8443),host,()=>console.log('Android secure origin: https://localhost:'+ (process.env.HTTPS_PORT||8443)+' — trust the generated demonstration CA on the device.'));
process.on('SIGTERM',()=>{persist();process.exit(0);});process.on('SIGINT',()=>{persist();process.exit(0);});

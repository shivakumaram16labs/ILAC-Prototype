import {randomUUID} from 'node:crypto';
const sleep=ms=>new Promise(resolve=>setTimeout(resolve,ms));
const normalize=name=>String(name).toLowerCase().replace(/laxmi/g,'lakshmi').replace(/[^a-z\s]/g,'').replace(/\s+/g,' ').trim();
function similarity(a,b){a=normalize(a);b=normalize(b);let previous=Array.from({length:b.length+1},(_,i)=>i);for(let i=1;i<=a.length;i++){const current=[i];for(let j=1;j<=b.length;j++)current[j]=Math.min(current[j-1]+1,previous[j]+1,previous[j-1]+(a[i-1]===b[j-1]?0:1));previous=current;}return 1-previous[b.length]/Math.max(1,a.length,b.length);}
export const MOCK_TOKEN='ILAC-MOCK-v1';
export const mockPaths=[
 '/bocw/v1/workers/search','/bocw/v1/registrations/{bocw_registration_no}/renewal','/eshram/v1/verify','/uidai/v1/auth','/digilocker/v1/documents','/ncs/v1/jobseekers','/gsws/v1/service-requests','/apssdc/v1/enrolments','/apssdc/v1/enrolments/{ack_no}/status','/meeseva/v1/applications/{ack_no}','/civilsupplies/v1/ricecard/member-additions','/education/v1/scholarship-referrals','/messaging/v1/messages'
];
export async function mockCall(store,path,payload={},method='POST',actor='Local mock client'){
 const log={id:'SYN-LOG-'+randomUUID(),timestamp:new Date().toISOString(),actor,method,path:'/mock'+path,request:payload,status:'Pending',response:null};
 store.mockLogs.unshift(log);
 const finish=(status,body)=>{Object.assign(log,{status,response:body,finished_at:new Date().toISOString()});return {status,body,log};};
 const bad=message=>finish(400,{error:message});
 if(/\b\d{12}\b/.test(JSON.stringify(payload)))return bad('12-digit Aadhaar-like values are prohibited. Use issued uid_token_mock values.');
 const ref=prefix=>`${prefix}${String(store.mockLogs.length).padStart(6,'0')}`;
 const ack=prefix=>finish(201,{external_ack_no:ref(prefix),status:'ACKNOWLEDGED',received_at:new Date().toISOString()});
 const req=fields=>fields.every(field=>typeof payload[field]==='string'&&payload[field].trim());
 const expectedMethod=path==='/digilocker/v1/documents'||path.startsWith('/meeseva/v1/applications/')||/\/apssdc\/v1\/enrolments\/[^/]+\/status$/.test(path)?'GET':'POST';
 if(method!==expectedMethod)return finish(405,{error:'Use '+expectedMethod+' for this issued operation.'});
 if(path==='/bocw/v1/workers/search'){
  if(!req(['full_name','date_of_birth']))return bad('full_name and date_of_birth are required.');
  const name=normalize(payload.full_name);
  const matches=store.tables.T01_Workers.filter(w=>w.date_of_birth===payload.date_of_birth&&(similarity(w.full_name,name)>=.82||w.mobile===payload.mobile||payload.uid_token&&w.uid_token_mock===payload.uid_token));
  if(name.includes('gorle lakshmi')&&!matches.some(w=>w.worker_id==='SYN-W-000607'))matches.push(store.tables.T01_Workers.find(w=>w.worker_id==='SYN-W-000607'));
  return finish(200,{matches:matches.filter(Boolean).map(w=>({worker_id:w.worker_id,bocw_registration_no:w.bocw_registration_no,full_name:w.full_name,match_score:normalize(w.full_name)===name?0.98:Number(Math.max(.85,similarity(w.full_name,name)).toFixed(2)),matched_on:['date_of_birth',...(w.mobile===payload.mobile?['mobile']:[]),'name_phonetic']}))});
 }
 if(path==='/eshram/v1/verify'){
  if(!req(['uid_token','mobile'])||!payload.uid_token.startsWith('SYN-UIDTOK-'))return bad('Synthetic uid_token and mobile are required.');
  if(payload.uid_token==='SYN-UIDTOK-41100031'){
   log.expected_behaviour='No response within 10 seconds';
   await sleep(10500);return finish(504,{error:'Pending - external system unavailable',timeout_ms:10000});
  }
  const known=store.tables.T01_Workers.find(w=>w.uid_token_mock===payload.uid_token);
  const suffix=payload.uid_token.slice(-2);
  return finish(200,{status:'VERIFIED',uan_token:known?.eshram_uan_token_mock||'SYN-UAN-778100'+suffix});
 }
 if(path==='/uidai/v1/auth'){
  if(!req(['uid_token','otp'])||!payload.uid_token.startsWith('SYN-UIDTOK-'))return bad('Only SYN-UIDTOK tokens are accepted.');
  return finish(200,{auth_status:payload.otp==='123456'?'SUCCESS':'FAILED',txn_id:ref('SYN-AUTH-')});
 }
 if(path==='/digilocker/v1/documents'){
  if(!req(['uid_token','consent_id']))return bad('uid_token and consent_id are required.');
  return finish(200,{documents:store.specimens.map((name,index)=>({doc_type:name.includes('class10')?'CLASS_X_MEMO':name.includes('birth')?'BIRTH_CERTIFICATE':name.includes('work')?'WORK_CERTIFICATE':'PHOTO',issuer:'Synthetic specimen (issued dataset)',uri:`syn://digilocker/SYN-DOC-${index+1}`,file_name:name}))});
 }
 if(path.startsWith('/bocw/v1/registrations/')&&path.endsWith('/renewal'))return ack('SYN-BOCW-ACK-');
 if(path==='/messaging/v1/messages'){
  if(!req(['channel','to','template_id'])||!['SMS','WHATSAPP','IVR','EMAIL'].includes(payload.channel))return bad('Valid channel, to and template_id are required.');
  const allowed=store.tables.T01_Workers.some(w=>w.mobile===payload.to)||store.tables.S_Personas.some(p=>p.mobile.match(/^\d{10}/)?.[0]===payload.to)||store.tables.M05_Users_Roles.some(u=>u.login_id===payload.to);
  if(!allowed)return bad('Recipient must be an issued synthetic number or demonstration login.');
  const message={...payload,id:ref('SYN-MSG-'),timestamp:new Date().toISOString(),delivery:'Mock log only — never dispatched'};
  store.messages.unshift(message);return finish(202,{message_id:message.id,status:'ACCEPTED',dispatched:false});
 }
 if(path.match(/^\/apssdc\/v1\/enrolments\/[^/]+\/status$/)){
  const id=decodeURIComponent(path.split('/')[4]);
  return finish(200,{external_ack_no:id,status:store.mockStatuses[id]||'RECEIVED',remarks:'Operator-triggered mock status',updated_at:new Date().toISOString()});
 }
 if(path.startsWith('/meeseva/v1/applications/'))return finish(200,{external_ack_no:decodeURIComponent(path.split('/').at(-1)),status:'UNDER_PROCESS',remarks:'Fixed-list demonstration status',updated_at:new Date().toISOString()});
 if(path==='/ncs/v1/jobseekers')return req(['worker_id'])?ack('SYN-NCS-'):bad('worker_id is required.');
 if(['/gsws/v1/service-requests','/apssdc/v1/enrolments','/civilsupplies/v1/ricecard/member-additions','/education/v1/scholarship-referrals'].includes(path)){
  if(!req(['ilac_case_id','worker_id','service_code']))return bad('ilac_case_id, worker_id and service_code are required.');
  if(path.includes('civilsupplies')&&!store.config.civilSuppliesRestored)return finish(503,{error:'API unavailable',retry_after:3600,ilac_case_id:payload.ilac_case_id});
  return ack(path.includes('apssdc')?'SYN-APSSDC-ACK-':path.includes('education')?'SYN-EDU-ACK-':path.includes('civilsupplies')?'SYN-CS-ACK-':'SYN-GSWS-ACK-');
 }
 return finish(404,{error:'Not an issued mock API path'});
}

# Digital ILAC Part 1 — T-4 department demonstration

Configured working demonstration for **Tender ID 985903**, based on **Digital ILAC Part 1 – T-4 Scripted Solution Demonstration Pack (1).docx** and the supplied **ILAC_Demo_Datasets_v1.0 2** folder.

For a short platform overview, staff login guide and application walkthrough, start with the [Quick Start and Knowledge Transfer Guide (HTML)](docs/Digital_ILAC_Quick_Start_and_KT.html). For the detailed presenter handover and live T-4 run of show, see the [Client Demo Guide](docs/Digital_ILAC_KT_and_Demo_Guide.html) or its [Markdown version](docs/Digital_ILAC_KT_and_Demo_Guide.md).

An unmodified copy of the [issued Word pack](docs/tender/issued-demonstration-pack.docx) is included for reference. The [T-4 coverage map](docs/tender/T4-COVERAGE.md) links all 45 numbered steps and C1–C5 to their live screens.

For presentation preparation, use the [Client Demonstration Playbook (PDF)](docs/presentation/Digital_ILAC_Client_Demo_Playbook.pdf). It includes a 33-page starting guide, speaking cues and click sequences, seven flow diagrams, exact persona/role/data references, report figures, client questions and a final cue card. Its printable [HTML source](docs/presentation/Digital_ILAC_Client_Demo_Playbook.html) is also included. Follow the official live timetable during the tender slot; the PDF is a rehearsal aid.

The application uses HTML, CSS and JavaScript with a dependency-free local Node.js server. It implements **S1–S5 and C1–C5**, the issued role accounts, local Government mocks, audit/configuration histories, a mock messaging gateway, service clocks, departmental worklists, a job-mela workflow, restricted counselling notes and live MIS queries. The Android field interface is an installable PWA with an offline shell and **AES-256-GCM encrypted IndexedDB records**.

All operational seed data comes from the **22 issued CSVs: 3,684 records**. No earlier invented workers, accounts, schemes, jobs or service catalogue is loaded. The original workbook, CSVs, YAML and seven specimen images are unchanged. Runtime additions come from the scripted personas, configuration tasks and permitted demonstration actions. Public AP branding images are retained from the earlier project; they are not operational records.

**This is a demonstration environment, not a production deployment.** No live Government API, real SMS/WhatsApp gateway, AI model or production credential is connected. The requirements for actual offline operation and concurrent sessions supersede the earlier browser-memory-only overview: the local server now retains shared rehearsal state, and the field device retains encrypted offline records until synchronisation or reset.

## 1. Start the application

Requirements: Node.js 20 or later, Python 3 for optional re-import, a modern Chrome browser, and OpenSSL for the Android HTTPS certificate. There are no npm packages to install.

```sh
cd "/Users/shivakumarat/Desktop/ILAC Prototype"
npm start
```

Open **http://localhost:8080** on the laptop. Keep the terminal running. Double-clicking `index.html` shows startup instructions because the working demonstration requires the local server and mocks.

The application loads `data/issued-data.json`, imported from the supplied CSVs. Re-import is optional when restoring or replacing an issued dataset:

```sh
npm run data:import
npm run check
```

The importer preserves CSV cell strings; it does not clean duplicates or rewrite the issued folder. `npm run check` verifies all original SHA-256 hashes, the 22 counts, the 3,684 total, 13 accounts, 13 mock paths, active syntax and local assets.

Shared rehearsal state is in `.runtime/state.json`. Restarting the server retains the rehearsal. Signing out only ends that account’s session. Use **demo.admin.state → Environment → Reset rehearsal to issued dataset** before the official demonstration. Reset clears scripted changes, configuration publications, logs and the clock, and restores the original table values. It retains the chosen demonstration date.

## 2. Prepare the Android field device

The phone must use a secure origin for service workers, device encryption and geolocation. Laptop `http://localhost` is suitable for rehearsal; an Android phone accessing the laptop’s LAN address must use trusted HTTPS.

1. Put the laptop and Android device on the same bidder-controlled Wi-Fi or hotspot. Prefer a separate hotspot/router so putting the field phone in airplane mode does not remove the operator’s connection.
2. In this project folder, run:

   ```sh
   npm run cert
   ```

3. The command creates a 30-day **local demonstration CA** and server certificate in `.runtime/tls`. It includes localhost and the laptop’s current LAN IPv4 addresses. It prints the phone URL, such as `https://<laptop-LAN-IP>:8443`.
4. Stop and restart `npm start`. The server now provides HTTP on 8080 and HTTPS on 8443.
5. Transfer **only `.runtime/tls/ca.crt`** to the Android device and trust it through the device’s certificate settings. Do not transfer the private `.key` files. This CA is for this local demonstration environment only. Use the browser’s normal trust process; a certificate-error page is not a reliable offline/PWA setup.
6. Open the printed HTTPS URL in Android Chrome. Install **Digital ILAC** using the browser’s installation/Add to Home screen option. Launch the installed app and confirm there is no certificate error. Enable camera and location permissions.
7. Log in as **demo.ff.krs**, open **S2**, and select **Download assigned visit**. Wait for the success message and confirm 12 roster workers and a field form version.
8. Keep a second phone/tablet as standby if available. Arrange screen mirroring and the HDMI adapter before the slot.

If the laptop’s LAN address changes, run `npm run cert` again and restart the server. The existing local CA is reused; check that the device still trusts it and the new URL works.

For the live camera steps, photograph the issued P-04 specimen or a staged synthetic safety setup; do not introduce a real worker’s personal photograph. Capture the device location through **Capture location**. The app does not replace a camera capture, location reading or airplane-mode demonstration with a label or toggle.

**Actual Android installation, camera permission, GPS and screen mirroring must be checked on your own device before attending.** Desktop browser verification tests the same offline/encryption/sync code with test geolocation and issued images; it is not evidence that the Committee has witnessed a real phone.

## 3. Issued accounts and MFA

All **13** login IDs are from `M05_Users_Roles`. The bidder-set demonstration password is **admin@123**. After the password step, the local mock console displays OTP **123456**; enter it to finish signing in. No real OTP message is sent.

Credentials are documented here and under the small **Configure demo** button at the bottom-left of the public home footer. The Authority Environment screen also lists them for the Committee. There are no invented worker, district or counsellor accounts.

| Login ID | Issued role / scope | Enabled modules |
| --- | --- | --- |
| `demo.op.ntr` | ILAC Centre Operator, ILAC-NTR-01 | SM-01, SM-18, SM-04 |
| `demo.op.krs` | ILAC Centre Operator, ILAC-KRS-01 | SM-01, SM-18, SM-07 |
| `demo.op.gnt` | Job-mela desk, ILAC-GNT-01 | SM-15, SM-05, SM-18 |
| `demo.ff.krs` | Field Functionary, District KRS | SM-11, SM-20, SM-01 (field) |
| `demo.sup.krs` | Centre Supervisor, ILAC-KRS-01 | SM-01, SM-19 limited to conflict resolution |
| `demo.dlo.krs` | District Labour Officer, KRS | SM-07, SM-13 |
| `demo.dlo.gnt` | District Labour Officer / mela organiser, GNT | SM-15, SM-13 |
| `demo.nodal.cs` | Civil Supplies departmental officer, KRS | SM-22 departmental, SM-07 |
| `demo.nodal.sk` | APSSDC departmental officer, State | SM-22 departmental, SM-11 |
| `demo.emp.001` | Employer SYN-E-001 | SM-22 employer, SM-05 |
| `demo.cns.edu1` | Education Counsellor, ILAC-NTR-01 | SM-08, SM-06 |
| `demo.pmu.state` | State PMU analyst | SM-13 |
| `demo.admin.state` | State configuration administrator / Authority publisher | SM-19 |

Use separate browser profiles, incognito windows or devices for concurrent accounts. Do not repeatedly change one tab’s account during the S2 conflict demonstration. All sessions use the same server state; role scope and actions are checked on the server as well as in the UI.

The field role can access all 12 assigned roster workers, including the four from ILAC-KRS-02. Mela roles use the event’s candidate scope, including candidates from other districts. The employer sees its own candidates and offers. Private counselling sessions are returned only to the assigned counsellor. The supervisor’s SM-19 does not grant configuration publishing. The PMU is an SM-13 analyst, not an administrator.

## 4. Set D and check the issued data

Before running any scenario:

1. Sign in as **demo.admin.state** and open **Environment**.
2. Reset the rehearsal to the issued dataset.
3. Set **Actual demonstration date** to the Board’s slot date. The default is the current date in Asia/Kolkata; the slot date itself was not supplied.
4. Select **Rebase offset-driven dates**.
5. Select **Verify issued source hashes**. Every source file should match; the loaded total should remain **3,684**.
6. Show the per-sheet counts if requested.

The workbook’s nominal date is **2026-11-02**. Only offset-driven dates are rebased. For example, `created_offset_days = -25` becomes D−25; `due_offset_days = -4` becomes D−4. Fixed supplied DOBs, registration dates and `age_on_2026_10_01` stay unchanged. Derived dates are presented alongside original source offsets; source CSVs are not edited.

Q1, Q3 and Q5 use immutable loaded snapshots because their wording explicitly excludes demonstration registrations/updates. Q2 and Q4 use the specified as-on-D open-status and offset filters. New referrals created on D are not overdue.

| Sheet | As-loaded records |
| --- | ---: |
| M01_Districts | 28 |
| M02_ILAC_Centres | 32 |
| M03_Trades | 18 |
| M04_Services | 23 |
| M05_Users_Roles | 13 |
| T01_Workers | 609 |
| T02_Households | 533 |
| T03_Members | 1,910 |
| T04_Employers | 40 |
| T05_Sites | 60 |
| T06_Vacancies | 80 |
| T07_JobMela_Event | 1 |
| T08_JobMela_Candidates | 20 |
| T09_Worksite_Visit_S2 | 12 |
| T10_Referrals | 152 |
| T11_Grievances | 70 |
| T12_Training_Batches | 10 |
| T13_Counsellors | 6 |
| T14_Counselling_Cases | 40 |
| S_Personas | 8 |
| S_MIS_Queries | 5 |
| S_Mock_API_Behaviour | 14 |
| **Total** | **3,684** |

Do not merge the six seeded duplicate pairs or overwrite P-02/P-05 registry values with their differing persona-card values. P-02 must link to SYN-W-000607. The raw query results include the duplicates as issued.

## 5. Forty-five-minute setup before the slot

- Start the local solution and HTTPS mocks; verify laptop and phone access.
- Reset rehearsal state, set D and verify source hashes/counts.
- Prepare operator, field and supervisor sessions independently. Prepare the departmental, employer, counsellor, PMU and Authority accounts.
- Download the field visit online. Check the service worker, installed app, ciphertext evidence and permissions.
- Test camera, device location, airplane-mode capture and reconnection on the actual Android device. Reset and download again afterwards.
- Confirm Civil Supplies is in its required **503 unavailable** state.
- Confirm JM-2026-01 has six employers, 12 vacancies and 20 pre-registered candidates.
- Test display/mirroring and power; have the standby device and bidder connectivity ready.
- Keep this README and the input cards as operator preparation aids. Perform and show every scored step live in the application.
- Bring at most four bidder representatives, including the Solution Architect/Technical Lead named in the bid. Only bidder staff operate the solution.

The pack also requires a pre-demonstration declaration at least one working day before the slot. A fill-in template is in [docs/tender/PRE-DEMONSTRATION-DECLARATION.md](docs/tender/PRE-DEMONSTRATION-DECLARATION.md). Review it against your actual environment and technical bid; the application does not send it to the Board.

## 6. Ninety-minute department walkthrough

Start the clock only when the Committee says so: **demo.admin.state → Environment → Start on Committee instruction**. Each scenario has 15 minutes, including its three-minute C-task. Stop at the slot boundary; do not carry unfinished steps into another scenario. The final ten minutes are for probes.

| Clock | Segment | Marks |
| --- | --- | ---: |
| 00:00–00:05 | Opening | — |
| 00:05–00:20 | S1 and C1 | 4 |
| 00:20–00:35 | S2 and C2 | 4 |
| 00:35–00:50 | S3 and C3 | 4 |
| 00:50–01:05 | S4 and C4 | 4 |
| 01:05–01:20 | S5 and C5 | 4 |
| 01:20–01:30 | Committee probes | — |

### Opening — 00:00–00:05

Confirm the unaltered v1.0 import, original counts, rebased D, running local mocks and ready field device. Show **Environment** and source verification. The Committee starts recording. A short architecture explanation is allowed here; slides, videos or screenshots are not accepted as evidence of a scripted step.

Architecture: browser/PWA → local authenticated application server → issued-data working tables and the local mock adapter. The same mock implementation is exposed through `/mock` HTTP paths. Offline field packets are encrypted on the device; after reconnection they are processed by the shared server with idempotency and version-conflict checks.

### S1 — assisted registration and household baseline — 00:05–00:20

Use **demo.op.ntr**, ILAC-NTR-01. Keep an Authority session ready for C1.

1. **1.1:** Show the three enabled module menu items. Switch **Telugu ↔ English**. Show Telugu name input and translated registration labels.
2. **1.2:** Open **S1** or **SM-18 Walk-in queue**. Select **Issue token**, then **Call token** for P-01.
3. **1.3:** Open **Register worker**, P-01. Select **Search registry**: BOCW returns no match. Select **Verify e-Shram**: show `SYN-UAN-77810011` in the result and API log.
4. **1.4:** Clear **Date of birth** and select **Save registration** once. Show the mandatory-field error and that no record was created. Restore **1984-06-12**. Review/enter the exact P-01 card values; the form has editable English/Telugu name, mobile, DOB and household controls.
5. **1.5:** Enter the consent purpose, choose the channel and tick consent. The saved record stores `CONSENT-DEMO-v1`, channel, timestamp and operator.
6. **1.6:** Capture the baseline and the four named members: Kona Padma, Kona Sai Kiran, Kona Harika and Kona Sathyavathi, with their issued relationships, DOBs and education stages. Save; show the new worker and household IDs. The worker is represented as household head separately from these four dependant members.
7. **1.7:** Open **Documents**. Choose the new P-01 worker. Upload `specimen_photo_P-01.png` as **Photo** and `specimen_work_certificate_P-01.png` as **Work certificate**. View the controlled document links.
8. **1.8:** Return to **S1 → P-01 acknowledgement → View acknowledgement**. This issues the acknowledgement after both required uploads, then writes Telugu **SMS and WhatsApp** acknowledgement records to **Messaging log**. Show the on-screen acknowledgement and both mock messages; there is no real dispatch.
9. **1.9:** In S1, key **Gorle Laxmi** in the name field and select **Search P-02**. Show typed **Gorle Laxmi**, existing **Gorle Lakshmi / SYN-W-000607** and score at least 0.85. Select **Link existing record**. Show the audit entry and no second worker master. Existing values remain unchanged.
10. **1.10:** In Register worker, choose **P-03**. Select **Verify e-Shram** and allow the actual ten-second timeout. Attach `specimen_photo_P-03.png`, record consent and save. Show **Pending - external system unavailable**, the queued retry, acknowledgement and a documented next step with owner, action, date, documents and follow-up route. Pydi Simhachalam is not turned away.
11. **C1, final three minutes:** As **demo.admin.state → Configuration → C1**, add/publish the mandatory dropdown **Primary language of worker**, with **Telugu / Urdu / Odia / Hindi / Other**. Show the version/change log. Return to the operator’s next registration screen to show the required field. It will also be required when P-04/P-06 register later. Do not re-save an already registered persona merely to manufacture another worker.

### S2 — genuine offline worksite capture and sync — 00:20–00:35

Use the actual Android device as **demo.ff.krs**. Keep independent **demo.op.krs** and **demo.sup.krs** sessions online.

1. **2.1:** Open **S2 → Download assigned visit** while online. Show **SYN-VIS-001**, site **SYN-S-0006**, and the 12 rows from T09.
2. **2.2:** Enable actual **airplane mode** on the phone and disable remaining Wi-Fi/mobile connectivity. Let the Committee verify the device. Show the app’s offline indicator.
3. **2.3:** Set attendance for all 12. Mark **SYN-W-000182** and **SYN-W-000225** absent; the other ten present.
4. **2.4:** Enter the safety observation, capture a staged/synthetic safety photograph using the device camera, and select **Capture location**. Save the visit on device.
5. **2.5:** Preserve/capture the marked needs for **SYN-W-000030**, **SYN-W-000097** and **SYN-W-000183** in the visit form.
6. **2.6:** Open **Register P-04 on device**. Enter the issued values for Gudla Eswar, select the C1 language, capture the photograph and consent, then save. Show the **SYN-PROV-…** ID and **Encrypted device evidence**: AES-256-GCM, a non-extractable key, IV and ciphertext bytes. A provisional record survives an offline app reload.
7. **2.7:** Back in S2, save the field mobile edit for **SYN-W-000120** as **9000099101**. In the parallel **demo.op.krs → S2** session, save **9000099102** for the same worker while the phone is still offline. The online audit version changes independently.
8. **2.8:** Restore phone connectivity to the same server. Synchronisation starts automatically; **Synchronise now** is also available for inspection/retry. Show queue receipts, P-04’s permanent worker ID, the server-side duplicate search and e-Shram mock verification. Retrying the same packet does not create another registration or visit.
9. **2.9:** As **demo.sup.krs → S2**, show the base value, field value and centre value for worker 120. Choose a version, enter a reason and resolve. Show both edits and the resolution in **Audit trail**.
10. **2.10:** Open the workers’ history from **SM-01** to show the visit/attendance and three new skilling needs. In **SM-20 Sites & skilling groups**, show the marked workers and issued KRS batches; use **Group marked needs for batch referral** if requested. The observation photograph and captured location are viewable under synchronised visit evidence.
11. **C2, final three minutes:** As Authority, publish **PPE – safety helmets available on site**, response **Yes/No**, in **Configuration → C2**. Synchronise the field device once more and show the new item and version. No app build or deployment occurs.

### S3 — convergence referral, clock and manual fallback — 00:35–00:50

Use **demo.op.krs**. Prepare **demo.nodal.cs**, **demo.nodal.sk** and **demo.dlo.krs** sessions.

1. **3.1:** Open **S3 → P-05 household timeline** for **SYN-W-000608**, Bandaru Nagaraju / **SYN-H-000532**. Show existing completed renewal **SYN-R-00152 / LB-01**. Preserve the registry’s experience value; do not replace it with the differing persona-card value.
2. **3.2:** Add **Bandaru Likhitha**, DOB **D−60**, as the daughter. In Documents, upload/classify `specimen_birth_certificate_P-05.png`; it links to the newborn member and worker household.
3. **3.3:** In **New referral**, choose P-05 and **SK-01**. Submit. Show the local APSSDC 201 acknowledgement and the **7-day** clock/due date.
4. **3.4:** Choose **CS-01** and the uploaded birth certificate. Submit. The local Civil Supplies mock returns **503**, and the same ILAC case ID continues as **Manual / assisted fallback**, reason **API unavailable**, clock **21 days**. Show the printable referral slip and departmental worklist link.
5. **3.5:** Select **One acknowledgement · both referrals**. Show IDs, due dates, responsible offices and next steps. Print/share via the browser’s print/save-PDF route if requested.
6. **3.6:** As **demo.nodal.cs → SM-22**, open the new Civil Supplies case. Select **Received – documents verified**, enter an evidence reference and save. Show the manual update/audit record. Controlled supporting-document links are available on the case.
7. **3.7:** As **demo.op.krs** or **demo.nodal.sk**, open the APSSDC case, select **Trigger Seat confirmed**, then **Poll mock status**. Show **Seat confirmed** and the request/response log.
8. **3.8:** As **demo.dlo.krs → S3**, open **SYN-R-00151**. It was created D−25; it is overdue. Show L1 at **D−11** to demo.dlo.krs and L2 at **D−4** to State PMU. These dates are explicitly derived from the issued offsets/rules because no separate escalation-history table was supplied.
9. **3.9:** Show the **Integration monitoring** card, **Inspect dependency**, API 503 record, retry-after 3,600 seconds and open D15 dependency.
10. **C3, final three minutes:** As Authority, publish **CS-01 clock 15 days; L1 10 days; new referrals only**. Show history. Re-open the existing new/manual case and SYN-R-00151: their original **21-day** clock remains. Create a further CS-01 referral as a probe to show **15 days**. L2 is not silently changed by this task.

Keep Civil Supplies unavailable throughout S3. Only if the Committee says “restore,” the Authority uses the recorded-instruction restore control in Environment. The operator can then reconcile an already-open manual case using the **same ILAC case ID**, not create a replacement case.

### S4 — job mela and placement — 00:50–01:05

Use **demo.op.gnt / demo.dlo.gnt**, and **demo.emp.001** for the employer action.

1. **4.1:** Open **S4 / SM-15**. Show **JM-2026-01**, ILAC-GNT-01, capacity **300**, employers **SYN-E-001…006**, and the **12** offered vacancies. Show the shared calendar.
2. **4.2:** Show the 20 as-loaded candidates. Check in **P-07 / JMR-004 / Anumolu Raju**, linked to **SYN-W-000302**.
3. **4.3:** Open P-06 quick worker registration. BOCW returns no match; save **Kandula Rajesh** with the issued values, C1 language and `specimen_photo_P-06.png`. Back in S4, tick eligibility/document checks and **Register walk-in and check in**. Show the local NCS registration log.
4. **4.4:** Allocate **P-06 → SYN-V-0001 / SYN-E-001**, and **P-07 → SYN-V-0006 / SYN-E-006**, using the interview form.
5. **4.5:** As **demo.emp.001 → S4**, show its candidate worklist. Record the P-06 spot offer: source vacancy wage **₹850/day**, source engagement type, joining **D+3**.
6. **4.6:** As the desk/organiser, select **P-07 · employer decision pending / D+2**. Show the follow-up date.
7. **4.7:** Show the SM-05 placement record linked to the offer and joining follow-up task. Show the mock worker notification. This is a recorded offer, not an automatic claim that the worker has joined.
8. **4.8:** Show the live event counts and **Live event closure report**, including interviews/offers by employer. With the scripted sequence, there are 21 registrations, 2 check-ins, 2 interviews and 1 spot offer.
9. **C4, final three minutes:** As Authority in Configuration, add **Solar panel installer**, publish a vacancy for **SYN-E-002** at **JM-2026-01**, and show it immediately in the trade/vacancy lists and event. The editable vacancy template uses supplied SYN-E-002 values; any values keyed at publication are logged as scripted configuration changes.

### S5 — counselling and live MIS — 01:05–01:20

Use **demo.cns.edu1**, then **demo.pmu.state**; keep Authority ready for C5.

1. **5.1:** Open **S5 / SM-08**. Show **P-08 / SYN-M-001909**, Bonthu Sravani, household **SYN-H-000533**, father **SYN-W-000609**, and the issued education stage.
2. **5.2:** Book **SYN-C-01 / Kolli Sujatha** in the shared calendar. Choose a supplied availability slot: Mon/Wed/Fri, 10:00–before 16:00. Show the reminder in the mock gateway log.
3. **5.3:** Record assessment, interests, **Polytechnic – Diploma in Civil Engineering** advice and agreed actions. Show private notes from the counsellor account. Other accounts do not receive these notes.
4. **5.4:** Upload the issued `specimen_class10_memo_P-08.png` under controlled access. Create **ED-02** admission referral, **manual / 15-day clock**, and **ED-01** scholarship referral, **mock API / 30-day clock**. Link both to the dependant and father’s worker record.
5. **5.5:** Show the counselling case, **D+14 follow-up**, member link and household timeline. The follow-up is recorded with the session.
6. **5.6:** As **demo.pmu.state → S5 / SM-13**, drill down **State → district → centre**.
7. **5.7:** Run **Q1–Q5** live. Explain the loaded-snapshot versus as-on-D definitions. Do not use a slide or hardcoded answer screen.
8. **5.8:** Select **Export CSV** for a report. Show its reporting timestamp and minimised aggregate columns; mobile, UID token and personal names are excluded.
9. **C5, final three minutes:** As Authority, use the **Report builder** to create/save **Women workers by trade and district**, filter Female and group by trade/district. Publish it to the PMU dashboard. Return to PMU, run the saved report and optionally export it. Its default covers all registration statuses, unlike Q1’s Active-only filter.

## 7. MIS rehearsal reference values

The Committee retains its own answer key. These reference figures were independently checked from the supplied CSVs and are useful for preparation; the application calculates its reports live.

| Query | Expected as-loaded/as-on-D total | Key detail |
| --- | ---: | --- |
| Q1 | **176** | Active registered women. Top five: Kakinada 15, Srikakulam 14, Kurnool 11, Palnadu 11, Krishna 10. Kurnool/Palnadu tie. |
| Q2 | **54** | Open overdue referrals, 16 departments; due-today rows are excluded. |
| Q3 | **20** | Before demo walk-ins: Helper 8, Mason 3, Bar bender 2, Painter 2; Carpenter, Concrete mixer operator, Plasterer, Stone cutter, Welder 1 each. |
| Q4 | **26** | Defined open grievances with created_offset_days strictly less than −30. |
| Q5 | **4** | KRS Active / skilling need Yes / empty batch, before S2: Tile layer, Plasterer, Electrician, Bar bender, one each. |

Q2 open statuses: **Submitted / Acknowledged by department / Query raised - awaiting worker**. Q4 open statuses: **Open - under action / Open - escalated / Reopened**. Q5 workers: **SYN-W-000400, 000433, 000594, 000608**. New S2 needs do not contaminate the Q5 loaded snapshot.

## 8. Committee probes and evidence locations

| Requested evidence | UI location |
| --- | --- |
| Registry, household members and service history | SM-01 → View worker; scenario household timeline |
| Original counts / hashes / D rebase | Authority → Environment |
| Mock request and response, including 503/timeout | Activity → Mock API log → View |
| Direct supplied OpenAPI operation probe | Authority → Mock API log → OpenAPI mock contract console |
| Telugu acknowledgement/reminder/offer | Activity → Messaging log → View |
| Encryption, queued packets, provisional ID | Field S2 → Encrypted device evidence / Sync queue |
| Sync status and permanent ID | Field → Synchronise now → receipt; supervisor conflict view |
| Both mobile edits and supervisor reason | Supervisor S2 and Audit trail |
| Manual slip / case lifecycle / frozen clock | S3 → View referral |
| DLO overdue escalation history | S3 → SYN-R-00151 |
| Configuration version / publisher / before-after values | Authority Configuration; Activity → Configuration history |
| Employer offers / joining follow-up | S4; SM-05 |
| Restricted counselling notes | Assigned counsellor SM-08 only |
| Q1–Q5 / saved report / minimised export | PMU SM-13 |
| Numbered preparation checklist | Authority → Evidence checklist |

Use the registry search, source record views, roster worker selectors, referral worker/service selections, mela candidate/vacancy selections and the counsellor’s dependant selector to repeat appropriate steps on another issued record. Do not fabricate additional seed records or credentials. An existing persona cannot be registered a second time merely to repeat a step; demonstrate duplicate prevention or use another permitted issued input card.

The Evidence checklist records activity locations/timestamps. It does not award marks or certify a step merely because an event was logged. The Committee observes the live outcome, usability and configuration.

## 9. Mock APIs

All endpoints are local under **`/mock`**, using the supplied YAML’s 13 paths. Static contract probe bearer token: **ILAC-MOCK-v1**. Application sessions can also invoke the local mocks with their issued session token. No Government hostname is contacted.

- BOCW search returns matches from the registry; Gorle Laxmi resolves to SYN-W-000607 with score ≥0.85.
- e-Shram verifies synthetic tokens; P-03 has no response within ten seconds and finishes as timeout/fallback. It is not an instant “timeout” label.
- UIDAI mock accepts SYN-UIDTOK tokens and OTP 123456; Aadhaar-like 12-digit inputs are rejected.
- DigiLocker returns issued specimen metadata only.
- BOCW renewal, NCS, GSWS, APSSDC and Education return synthetic acknowledgements.
- APSSDC status moves to SEAT_CONFIRMED only after the operator trigger; poll updates the displayed case.
- MeeSeva returns a fixed permitted status.
- Civil Supplies stays 503 for S3 unless the Authority records the Committee restore instruction.
- Messaging returns 202 and logs a payload with **dispatched:false**; no provider is connected.

Some M04 rows describe a mock integration but have no operation in the supplied YAML, for example LB-02, NP-01 and PG-01. They are not assigned invented endpoint contracts. Additional referrals can use a documented manual/dependency route. The required S1–S5 operations use the issued contracts.

## 10. Scoring and missing supplied artifacts

T-4 has **20 marks**, **4 per scenario**: **Completeness 2 / Usability 1 / Configuration without code 1**. Minimum T-4 is **12**. Bands: Excellent 100%, Good 75%, Adequate 50%, Weak 25%, Not addressed 0%. The Committee records reasons and determines the consolidated result. No production readiness or score is asserted by this application.

**Not present in the supplied folder:** `Annexure-B_T4_Demonstration_Scoring_Sheet_v1.0.xlsx`. The preparation checklist and [T4-COVERAGE.md](docs/tender/T4-COVERAGE.md) are derived from the Word pack and are **not** a fabricated official scoring workbook. Obtain the official Annexure-B from the Board before the slot.

The controlling RFP, corrigenda and referenced Annexures-D, 14/14A were not supplied with this dataset folder. The demonstration pack says they prevail if there is a conflict. Verify any bid-specific native-app/hosting commitment and declaration wording against the actual technical bid and Board instructions.

## 11. Verification

```sh
npm run check
npm test
npm run test:http
```

An optional browser check uses an existing installed Puppeteer-compatible module and Chrome; no dependency is required by the application itself:

```sh
ILAC_PUPPETEER_PATH="/absolute/path/to/puppeteer/module.js" npm run test:browser
```

The browser test exercises actual UI actions for S1–S5/C1–C5, real timeout timing, concurrent sessions, actual browser disconnection, encrypted records, offline reload, idempotent sync, conflict resolution, frozen clocks, source integrity, privacy and mobile layout. It uses issued specimen images and test geolocation for automation. Screenshots in `docs/screenshots/t4-*.png` are internal preparation/verification artifacts; **do not use them as scored evidence**.

See [VERIFICATION.md](docs/tender/VERIFICATION.md) for tested scope and the remaining physical-device checks.

## 12. Project files

```text
ILAC Prototype/
├── index.html / manifest.webmanifest / sw.js
├── css/                         # Government layout and tender interface
├── js/icons.js
├── js/tender/app.js              # Role UI, S1–S5, C1–C5, logs and reports
├── js/tender/offline.js          # Actual AES-GCM encrypted IndexedDB vault
├── server/index.mjs              # Local HTTP/HTTPS, authentication and API routes
├── server/model.mjs              # Shared state, script actions, scope and MIS
├── server/mocks.mjs              # Supplied 13-path mock behaviour implementation
├── data/issued-data.json         # Unchanged imported source cells + hashes
├── ILAC_Demo_Datasets_v1.0 2/     # Original issued folder; preserved
├── scripts/import-tender-data.py
├── scripts/setup-https.mjs
├── scripts/check-tender.mjs
├── tests/tender-engine.mjs
├── tests/tender-http.mjs          # All 13 hosted mocks and local HTTPS checks
├── tests/tender-browser.mjs
├── docs/tender/                  # Walkthrough evidence mapping and declaration
├── assets/                      # Local branding and PWA icons
└── .runtime/                    # Local rehearsal state / demonstration TLS keys
```

All timestamps are ISO 8601; the demonstration day is chosen in Asia/Kolkata. Keep `.runtime` and its private keys out of public source hosting. Use the configured local environment and mocks for this tender demonstration.

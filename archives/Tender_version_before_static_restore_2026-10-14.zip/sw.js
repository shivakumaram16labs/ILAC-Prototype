const CACHE='ilac-t4-shell-v1';
const SHELL=['/','/index.html','/css/base.css','/css/layout.css','/css/components.css','/css/tender.css','/js/icons.js','/js/tender/offline.js','/js/tender/app.js','/manifest.webmanifest','/assets/pwa-icon.svg','/assets/pwa-icon-192.png','/assets/pwa-icon-512.png','/assets/images/ap-emblem.png','/assets/images/chandrababu-naidu.jpg','/assets/images/pawan-kalyan.jpg','/assets/images/vasamsetti-subhash.png','/assets/images/workers.jpg'];
self.addEventListener('install',event=>event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(SHELL)).then(()=>self.skipWaiting())));
self.addEventListener('activate',event=>event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',event=>{
 const url=new URL(event.request.url);
 if(url.origin!==self.location.origin||url.pathname.startsWith('/api/')||url.pathname.startsWith('/mock/'))return;
 event.respondWith(fetch(event.request).then(response=>{if(response.ok&&event.request.method==='GET'){const copy=response.clone();caches.open(CACHE).then(cache=>cache.put(event.request,copy));}return response;}).catch(()=>caches.match(event.request).then(cached=>cached||caches.match('/index.html'))));
});

import fs from 'node:fs';
import https from 'node:https';
import assert from 'node:assert/strict';

const base=process.env.ILAC_TEST_URL||'http://localhost:8080';
const issued=JSON.parse(fs.readFileSync(new URL('../data/issued-data.json',import.meta.url),'utf8'));
const personas=issued.tables.S_Personas;
const p1=personas.find(p=>p.persona_id==='P-01'),p2=personas.find(p=>p.persona_id==='P-02');
async function probe(path,payload={},method='POST'){
 const response=await fetch(base+'/mock'+path+(method==='GET'?'?'+new URLSearchParams(payload):''),{method,headers:{Authorization:'Bearer ILAC-MOCK-v1','Content-Type':'application/json'},...(method==='POST'?{body:JSON.stringify(payload)}:{})});
 return {status:response.status,body:await response.json(),retry:response.headers.get('retry-after')};
}
assert.equal((await (await fetch(base+'/api/health')).json()).records,3684);
const match=await probe('/bocw/v1/workers/search',{full_name:'Gorle Laxmi',date_of_birth:p2.date_of_birth,mobile:p2.mobile});
assert.equal(match.status,200);assert(match.body.matches.some(m=>m.worker_id==='SYN-W-000607'&&m.match_score>=.85));
const worker=issued.tables.T01_Workers.find(w=>w.worker_id==='SYN-W-000608');
assert.equal((await probe(`/bocw/v1/registrations/${worker.bocw_registration_no}/renewal`)).status,201);
const verify=await probe('/eshram/v1/verify',{uid_token:p1.uid_token_mock,mobile:p1.mobile});
assert.equal(verify.status,200);assert.equal(verify.body.uan_token,'SYN-UAN-77810011');
assert.equal((await probe('/uidai/v1/auth',{uid_token:p1.uid_token_mock,otp:'123456'})).body.auth_status,'SUCCESS');
assert.equal((await probe('/uidai/v1/auth',{uid_token:'000000000000',otp:'123456'})).status,400);
const documents=await probe('/digilocker/v1/documents',{uid_token:p1.uid_token_mock,consent_id:'CONSENT-DEMO-v1'},'GET');
assert.equal(documents.status,200);assert.equal(documents.body.documents.length,7);assert(documents.body.documents.every(d=>d.uri.startsWith('syn://')));
assert.equal((await probe('/ncs/v1/jobseekers',{worker_id:worker.worker_id})).status,201);
const referral={ilac_case_id:'SYN-R-00151',worker_id:worker.worker_id,centre_id:worker.home_centre_id,consent_id:'CONSENT-DEMO-v1'};
assert.equal((await probe('/gsws/v1/service-requests',{...referral,service_code:'GS-01'})).status,201);
const enrolment=await probe('/apssdc/v1/enrolments',{...referral,service_code:'SK-01',trade:worker.primary_trade});
assert.equal(enrolment.status,201);assert(enrolment.body.external_ack_no.startsWith('SYN-'));
const status=await probe(`/apssdc/v1/enrolments/${enrolment.body.external_ack_no}/status`,{},'GET');
assert.equal(status.status,200);assert.equal(status.body.status,'RECEIVED');
assert.equal((await probe('/meeseva/v1/applications/'+enrolment.body.external_ack_no,{},'GET')).body.status,'UNDER_PROCESS');
const unavailable=await probe('/civilsupplies/v1/ricecard/member-additions',{...referral,service_code:'CS-01',member_name:'Bandaru Likhitha',relationship:'Daughter'});
assert.equal(unavailable.status,503);assert.equal(unavailable.retry,'3600');assert.equal(unavailable.body.ilac_case_id,referral.ilac_case_id);
assert.equal((await probe('/education/v1/scholarship-referrals',{...referral,worker_id:'SYN-W-000609',service_code:'ED-01',member_id:'SYN-M-001909',course_applied:'Diploma in Civil Engineering'})).status,201);
const message=await probe('/messaging/v1/messages',{channel:'SMS',to:p1.mobile,template_id:'ACK_REGISTRATION_TE',language:'te',params:{text:'సింథటిక్ పరీక్ష'}});
assert.equal(message.status,202);assert.equal(message.body.dispatched,false);
assert.equal((await fetch(base+'/mock/uidai/v1/auth',{method:'POST',headers:{Authorization:'Bearer invalid','Content-Type':'application/json'},body:'{}'})).status,401);
assert.equal((await fetch(base+'/data/issued-data.json')).status,404);
let trustedHttps=false;
const caFile=new URL('../.runtime/tls/ca.crt',import.meta.url);
if(fs.existsSync(caFile)){
 const health=await new Promise((resolve,reject)=>https.get('https://localhost:8443/api/health',{ca:fs.readFileSync(caFile),rejectUnauthorized:true},res=>{let data='';res.on('data',chunk=>data+=chunk);res.on('end',()=>resolve({status:res.statusCode,body:JSON.parse(data)}));}).on('error',reject));
 assert.equal(health.status,200);assert.equal(health.body.https,true);trustedHttps=true;
}
console.log(JSON.stringify({passed:true,hostedMockPaths:13,unauthorisedRejected:true,aadhaarLikeRejected:true,civilSupplies503:true,retryAfter:3600,noMessageDispatch:true,sourceFilesPrivate:true,trustedHttps},null,2));

window.FieldVault={};
FieldVault.open=()=>new Promise((resolve,reject)=>{
 const req=indexedDB.open('ILAC-T4-Encrypted-Field-v1',1);
 req.onupgradeneeded=()=>{req.result.createObjectStore('keys');req.result.createObjectStore('records',{keyPath:'id'});};
 req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);
});
FieldVault.transact=async(store,mode,fn)=>{
 const db=await FieldVault.open();return new Promise((resolve,reject)=>{const tx=db.transaction(store,mode),request=fn(tx.objectStore(store));let value;request.onsuccess=()=>value=request.result;tx.oncomplete=()=>{db.close();resolve(value);};tx.onerror=()=>{db.close();reject(tx.error);};});
};
FieldVault.key=async()=>{
 let key=await FieldVault.transact('keys','readonly',store=>store.get('device-key'));
 if(!key){key=await crypto.subtle.generateKey({name:'AES-GCM',length:256},false,['encrypt','decrypt']);await FieldVault.transact('keys','readwrite',store=>store.put(key,'device-key'));}return key;
};
FieldVault.put=async(id,value,type='snapshot')=>{
 const key=await FieldVault.key(),iv=crypto.getRandomValues(new Uint8Array(12));
 const ciphertext=await crypto.subtle.encrypt({name:'AES-GCM',iv},key,new TextEncoder().encode(JSON.stringify(value)));
 await FieldVault.transact('records','readwrite',store=>store.put({id,type,iv,ciphertext,algorithm:'AES-256-GCM',created_at:new Date().toISOString()}));
};
FieldVault.get=async id=>{
 const r=await FieldVault.transact('records','readonly',store=>store.get(id));if(!r)return null;
 const plaintext=await crypto.subtle.decrypt({name:'AES-GCM',iv:r.iv},await FieldVault.key(),r.ciphertext);return JSON.parse(new TextDecoder().decode(plaintext));
};
FieldVault.remove=id=>FieldVault.transact('records','readwrite',store=>store.delete(id));
FieldVault.records=()=>FieldVault.transact('records','readonly',store=>store.getAll());
FieldVault.queue=async()=>{
 const records=(await FieldVault.records()).filter(r=>r.type==='queue');return Promise.all(records.map(r=>FieldVault.get(r.id)));
};
FieldVault.evidence=async()=>{
 const key=await FieldVault.key();return {algorithm:key.algorithm.name+' / '+key.algorithm.length+'-bit',key_extractable:key.extractable,records:(await FieldVault.records()).map(r=>({id:r.id,type:r.type,created_at:r.created_at,encrypted_bytes:r.ciphertext.byteLength,iv_bytes:r.iv.byteLength,ciphertext_preview:Array.from(new Uint8Array(r.ciphertext).slice(0,24)).map(b=>b.toString(16).padStart(2,'0')).join('')}))};
};
FieldVault.clear=()=>FieldVault.transact('records','readwrite',store=>store.clear());

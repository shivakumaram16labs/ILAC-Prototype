"""Import issued CSV cells unchanged and record source integrity evidence."""
import csv, hashlib, json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'ILAC_Demo_Datasets_v1.0 2'
tables={};manifest=[]
for file in sorted((SOURCE/'csv').glob('*.csv')):
    with file.open(encoding='utf-8-sig',newline='') as stream:
        tables[file.stem]=list(csv.DictReader(stream))
for file in sorted(SOURCE.rglob('*')):
    if file.is_file() and file.name!='.DS_Store':
        manifest.append({'file':str(file.relative_to(SOURCE)), 'bytes':file.stat().st_size,'sha256':hashlib.sha256(file.read_bytes()).hexdigest()})
counts={name:len(rows) for name,rows in tables.items()}
assert len(tables)==22 and sum(counts.values())==3684
out={'version':'1.0','nominalDemoDay':'2026-11-02','sourceFolder':SOURCE.name,'counts':counts,'sourceManifest':manifest,'tables':tables}
(ROOT/'data'/'issued-data.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print('Imported 22 issued CSVs / 3,684 unchanged records. Original files were not modified.')

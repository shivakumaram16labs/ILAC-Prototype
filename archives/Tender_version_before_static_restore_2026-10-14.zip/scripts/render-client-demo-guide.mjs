import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
const root=fileURLToPath(new URL('../',import.meta.url));
const dir=path.join(root,'docs/presentation');
const driver=process.env.ILAC_PUPPETEER_PATH;
if(!driver)throw new Error('Set ILAC_PUPPETEER_PATH to an existing module exporting puppeteer.');
const {puppeteer}=await import(pathToFileURL(driver).href);
const browser=await puppeteer.launch({headless:true,executablePath:process.env.ILAC_CHROME_PATH||'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',args:['--no-first-run','--disable-background-networking']});
try {
 const page=await browser.newPage();
 await page.setViewport({width:1000,height:1200,deviceScaleFactor:1});
 await page.goto(pathToFileURL(path.join(dir,'Digital_ILAC_Client_Demo_Playbook.html')).href);
 await page.emulateMediaType('print');
 await page.evaluate(async()=>{await document.fonts.ready;await Promise.all([...document.images].map(img=>img.complete?Promise.resolve():new Promise(resolve=>{img.onload=resolve;img.onerror=resolve;})));});
 const layout=await page.evaluate(()=>{
  const sheets=[...document.querySelectorAll('.page')];
  const overflow=sheets.map((sheet,index)=>{
   const content=sheet.querySelector('.page-content').getBoundingClientRect();
   const footer=sheet.querySelector('.footer').getBoundingClientRect();
   const deepest=Math.max(content.bottom,...[...sheet.querySelectorAll('.page-content *')].map(el=>el.getBoundingClientRect().bottom));
   return {page:index+1,title:sheet.dataset.title,contentBottom:Math.round(deepest),footerTop:Math.round(footer.top),gap:Math.round(footer.top-deepest)};
  }).filter(x=>x.gap<10);
  const svgOverflow=[...document.querySelectorAll('svg text')].map(text=>{
   const svg=text.ownerSVGElement,bbox=text.getBBox();
   const matching=text.classList.contains('node-title')||text.classList.contains('node-text')?[...svg.querySelectorAll('rect')].filter(r=>{const b=r.getBBox();return bbox.x>=b.x&&bbox.x<=b.x+b.width&&bbox.y>=b.y&&bbox.y<=b.y+b.height;}).sort((a,b)=>a.getBBox().width-b.getBBox().width):[];
   const right=matching.length?matching[0].getBBox().x+matching[0].getBBox().width-6:svg.viewBox.baseVal.width;
   return {page:sheets.indexOf(text.closest('.page'))+1,text:text.textContent,excess:Math.round(bbox.x+bbox.width-right)};
  }).filter(x=>x.excess>1);
  const badImages=[...document.images].filter(i=>!i.naturalWidth).map(i=>i.src);
  return {pages:sheets.length,overflow,svgOverflow,badImages};
 });
 fs.writeFileSync(path.join(dir,'guide-layout-check.json'),JSON.stringify(layout,null,2)+'\n');
 console.log(JSON.stringify(layout,null,2));
 if(layout.overflow.length||layout.svgOverflow.length||layout.badImages.length)throw new Error('Fix the reported print layout before generating the PDF.');
 await page.pdf({path:path.join(dir,'Digital_ILAC_Client_Demo_Playbook.pdf'),format:'A4',preferCSSPageSize:true,printBackground:true,displayHeaderFooter:false,tagged:true,outline:true});
 const preview=path.join(dir,'review');fs.mkdirSync(preview,{recursive:true});
 for(const number of [1,8,12,15,20,25,30,31,32,33]){
  const sheet=await page.$('#page-'+number);
  await sheet.screenshot({path:path.join(preview,'page-'+String(number).padStart(2,'0')+'.png')});
 }
 console.log('Rendered the 33-page PDF and review images.');
} finally {await browser.close();}

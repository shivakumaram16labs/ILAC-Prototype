import fs from 'node:fs';import os from 'node:os';import path from 'node:path';import {execFileSync} from 'node:child_process';
process.umask(0o077);
const dir=path.resolve('.runtime/tls');fs.mkdirSync(dir,{recursive:true});
const ips=[...new Set(Object.values(os.networkInterfaces()).flat().filter(n=>n.family==='IPv4'&&!n.internal).map(n=>n.address))];
const run=args=>execFileSync('openssl',args,{stdio:'inherit'});
if(!fs.existsSync(path.join(dir,'ca.key'))){run(['genrsa','-out',path.join(dir,'ca.key'),'2048']);run(['req','-x509','-new','-nodes','-key',path.join(dir,'ca.key'),'-sha256','-days','30','-out',path.join(dir,'ca.crt'),'-subj','/CN=ILAC T4 Local Demonstration CA','-extensions','v3_ca']);}
run(['genrsa','-out',path.join(dir,'server.key'),'2048']);run(['req','-new','-key',path.join(dir,'server.key'),'-out',path.join(dir,'server.csr'),'-subj','/CN=localhost']);
const ext=path.join(dir,'extensions.cnf');fs.writeFileSync(ext,'subjectAltName=DNS:localhost,IP:127.0.0.1'+ips.map(ip=>',IP:'+ip).join('')+'\nkeyUsage=digitalSignature,keyEncipherment\nextendedKeyUsage=serverAuth\nbasicConstraints=CA:FALSE\n');
run(['x509','-req','-in',path.join(dir,'server.csr'),'-CA',path.join(dir,'ca.crt'),'-CAkey',path.join(dir,'ca.key'),'-CAcreateserial','-out',path.join(dir,'server.crt'),'-days','30','-sha256','-extfile',ext]);
console.log('Local demonstration TLS ready. Trust .runtime/tls/ca.crt on the actual device, restart npm start, and use https://'+(ips[0]||'localhost')+':8443. Run again if the LAN address changes. No production or Government keys are used.');

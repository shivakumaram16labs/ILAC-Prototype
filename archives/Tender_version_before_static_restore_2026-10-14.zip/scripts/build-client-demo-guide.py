"""Build a printable presenter handbook from the issued data, without changing app state."""
import html, json, re, subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'docs' / 'presentation'
OUT.mkdir(parents=True, exist_ok=True)
DATA = json.loads((ROOT / 'data/issued-data.json').read_text())
T = DATA['tables']
P = {p['persona_id']: p for p in T['S_Personas']}
W = {w['worker_id']: w for w in T['T01_Workers']}
node_query = "import fs from 'node:fs';import {initialStore,mis} from './server/model.mjs';const d=JSON.parse(fs.readFileSync('data/issued-data.json'));const s=initialStore(d);console.log(JSON.stringify(Object.fromEntries(d.tables.S_MIS_Queries.map(q=>[q.query_id,mis(s,d,q.query_id)]))));"
MIS = json.loads(subprocess.check_output(['node', '--input-type=module', '-e', node_query], cwd=ROOT))
pages = []
e = lambda v: html.escape(str(v))

def page(title, body, chapter='', subtitle='', cls=''):
    pages.append({'title':title, 'chapter':chapter, 'subtitle':subtitle, 'body':body, 'cls':cls})

def table(headers, rows, cls=''):
    return '<table class="'+cls+'"><thead><tr>'+''.join('<th>'+e(h)+'</th>' for h in headers)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+str(c)+'</td>' for c in row)+'</tr>' for row in rows)+'</tbody></table>'

def texttable(headers, rows, cls=''):
    return table(headers, [[e(c) for c in row] for row in rows], cls)

def box(title, body, kind='green'):
    return f'<aside class="box {kind}"><h3>{e(title)}</h3>{body}</aside>'

def say(text):
    return box('What to say', '<p class="quote">“'+e(text)+'”</p>')

def cols(left, right):
    return '<div class="cols"><div>'+left+'</div><div>'+right+'</div></div>'

def bullets(items):
    return '<ul>'+''.join('<li>'+item+'</li>' for item in items)+'</ul>'

def kv(items, cls=''):
    return '<dl class="kv '+cls+'">'+''.join('<div><dt>'+e(k)+'</dt><dd>'+e(v)+'</dd></div>' for k,v in items)+'</dl>'

def stats(items):
    return '<div class="stats">'+''.join('<div><strong>'+e(value)+'</strong><span>'+e(label)+'</span></div>' for value,label in items)+'</div>'

def node(x, y, width, title, lines=(), fill='green', height=72):
    colors={'green':('#edf4ef','#16624b'),'gold':('#fff4dc','#a8781c'),'blue':('#edf2f8','#36587c'),'white':('#ffffff','#64756e')}
    bg,stroke=colors[fill]
    result=f'<rect x="{x}" y="{y}" width="{width}" height="{height}" rx="9" fill="{bg}" stroke="{stroke}" stroke-width="1.2"/><text x="{x+13}" y="{y+23}" class="node-title">{e(title)}</text>'
    for i,line in enumerate(lines): result+=f'<text x="{x+13}" y="{y+42+i*15}" class="node-text">{e(line)}</text>'
    return result

def edge(points, label='', at=None):
    d='M '+' L '.join(f'{x} {y}' for x,y in points)
    result=f'<path d="{d}" class="connector" marker-end="url(#arrow)"/>'
    if label and at: result+=f'<text x="{at[0]}" y="{at[1]}" class="edge-text">{e(label)}</text>'
    return result

def diagram(body, height, caption):
    return f'<figure><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 670 {height}" role="img" aria-label="{e(caption)}"><defs><marker id="arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto"><path d="M 0 0 L 10 5 L 0 10 z" fill="#6f867b"/></marker></defs>{body}</svg><figcaption>{e(caption)}</figcaption></figure>'

def chain(items):
    positions=[(5,8),(238,8),(471,8),(471,132),(238,132),(5,132)]
    edges=''.join(edge(p) for p in [[(203,44),(236,44)],[(436,44),(469,44)],[(570,80),(570,130)],[(471,168),(438,168)],[(238,168),(205,168)]])
    nodes=''.join(node(x,y,198,title,lines,fill) for (x,y),(title,lines,fill) in zip(positions,items))
    return diagram(edges+nodes,214,'Follow the numbered path. The presenter performs each change live in the application.')

def source_line(names):
    return '<p class="source">Dataset source: '+e(' · '.join(names))+'</p>'

def persona_card(pid, compact=False, include_household=True):
    p=P[pid]
    fields=[('English name',p['full_name_en']),('Telugu name',p['full_name_te']),('Gender / DOB',p['gender']+' / '+p['date_of_birth']),('Mobile',p['mobile']),('Trade / experience',p['trade']+' / '+p['years_experience']+' years'),('District / centre',p['district / centre']),('Masked Aadhaar',p['aadhaar_masked']),('UID token',p['uid_token_mock']),('Bank account / smartphone',p['bank_account_held']+' / '+p['smartphone'])]
    return '<section class="persona '+('compact' if compact else '')+'"><div class="persona-title"><b>'+e(pid)+'</b><h3>'+e(p['full_name_en'])+'</h3></div>'+kv(fields)+(('<p><b>Household:</b> '+e(p['household'])+'</p>' if include_household else '')+'<p><b>Baseline:</b> '+e(p['household_baseline'])+'</p>' if not compact else '')+'<p class="small"><b>Issued documents:</b> '+e(p['documents_to_upload'])+'</p></section>'

CSS = '''
@page { size: A4; margin: 0; }
* { box-sizing: border-box; }
body { margin:0; background:#e8ece8; color:#223c32; font-family:Arial,Helvetica,sans-serif; font-size:10pt; line-height:1.34; }
.page { width:210mm; height:297mm; margin:10mm auto; padding:17mm 16mm 16mm; position:relative; background:white; break-after:page; }
.page:last-child { break-after:auto; }
.page-header { display:flex; align-items:center; justify-content:space-between; gap:8mm; border-bottom:1px solid #d6e3d9; padding-bottom:3mm; margin-bottom:5mm; font-size:8pt; color:#537466; }
.page-header img { width:9mm; height:9mm; object-fit:contain; }
.page-header .brand { display:flex; align-items:center; gap:3mm; font-weight:bold; letter-spacing:.6px; }
.chapter { font-size:8pt; text-transform:uppercase; letter-spacing:1.4px; color:#a67619; font-weight:bold; margin:0 0 2mm; }
h1 { font-size:22pt; line-height:1.12; letter-spacing:-.7px; margin:0 0 3mm; color:#145b45; }
h2 { font-size:14pt; line-height:1.25; margin:5mm 0 2mm; color:#145b45; }
h3 { font-size:10.3pt; line-height:1.25; margin:0 0 2mm; }
p { margin:0 0 2.4mm; }
.subtitle { color:#62786c; font-size:10.5pt; margin-bottom:5mm; }
.footer { position:absolute; bottom:9mm; left:16mm; right:16mm; border-top:1px solid #d6e3d9; padding-top:3mm; display:flex; justify-content:space-between; font-size:7.2pt; color:#657b6e; }
.small { font-size:8.5pt; }
.micro { font-size:7.4pt; }
.source { font-size:7.7pt; color:#657b6e; padding-top:2mm; }
.cols { display:grid; grid-template-columns:1fr 1fr; gap:5mm; align-items:start; }
.box { border:1px solid #dae7de; border-left:3px solid #1c7657; background:#f2f7f3; border-radius:6px; padding:3mm; margin:2.6mm 0; break-inside:avoid; }
.box.gold { background:#fff8e8; border-color:#efddb5; border-left-color:#bc8b2e; }
.box.blue { background:#f1f5fb; border-color:#d4dfed; border-left-color:#5277a1; }
.box p:last-child,.box ul:last-child { margin-bottom:0; }
.quote { font-size:10.3pt; color:#264b3d; line-height:1.46; }
ul,ol { margin:1mm 0 3mm; padding-left:5mm; }
li { margin-bottom:1.6mm; }
code { font-family:Menlo,Consolas,monospace; font-size:8.1pt; overflow-wrap:anywhere; }
pre { font:8.8pt/1.55 Menlo,Consolas,monospace; white-space:pre-wrap; background:#edf3ed; border:1px solid #d3e3d6; padding:3.6mm; margin:3mm 0; border-radius:5px; }
table { width:100%; border-collapse:collapse; font-size:8.7pt; margin:3mm 0; table-layout:auto; }
th { background:#edf3ee; color:#185a44; font-weight:bold; text-align:left; border-top:1px solid #cadccd; border-bottom:1px solid #cadccd; padding:2.2mm; }
td { vertical-align:top; border-bottom:1px solid #e4ece5; padding:1.7mm; overflow-wrap:anywhere; }
tr { break-inside:avoid; }
.dense table,table.dense { font-size:8pt; }
.dense td,.dense th,table.dense td,table.dense th { padding:1.25mm 1.7mm; }
table.steps { font-size:8.6pt; }
table.steps th:first-child,table.steps td:first-child { width:10%; color:#146348; font-weight:bold; }
table.steps th:nth-child(2),table.steps td:nth-child(2) { width:49%; }
table.steps th:nth-child(3),table.steps td:nth-child(3) { width:41%; }
table.roles td:first-child { white-space:nowrap; font-family:Menlo,Consolas,monospace; font-size:7.7pt; }
.stats { display:grid; grid-template-columns:repeat(4,1fr); gap:3mm; margin:4mm 0; }
.stats>div { border:1px solid #d8e4da; padding:3mm; border-radius:6px; background:#f8faf7; }
.stats strong { display:block; color:#145b45; font-size:24pt; line-height:1.05; margin-bottom:2mm; }
.stats span { font-size:8pt; color:#65786d; }
.kv { display:grid; grid-template-columns:1fr 1fr; gap:2.2mm 4mm; margin:3mm 0; }
.kv div { min-width:0; border-bottom:1px solid #e4ece5; padding-bottom:1.5mm; }
dt { font-size:7.6pt; color:#73877b; margin-bottom:.7mm; }
dd { margin:0; font-size:9.1pt; color:#223c32; overflow-wrap:anywhere; }
.persona { padding:4mm; border:1px solid #d8e3da; border-radius:7px; margin:3mm 0; }
.persona-title { display:flex; align-items:center; gap:3mm; margin-bottom:2mm; }
.persona-title>b { padding:1.4mm 2mm; border-radius:4px; background:#176047; color:white; font-size:8pt; }
.persona-title h3 { margin:0; font-size:12pt; }
.persona p { font-size:9pt; }
.compact { padding:3mm; }
.compact .kv { grid-template-columns:repeat(3,1fr); gap:1.6mm 3mm; }
.compact dd { font-size:8.4pt; }
.compact dt { font-size:7.3pt; }
.compact p { font-size:8pt; }
figure { margin:4mm 0; border:1px solid #dce7df; padding:3mm; border-radius:8px; background:#fcfdfb; }
svg { display:block; width:100%; height:auto; }
.node-title { font:600 14px Arial,sans-serif; fill:#1f4b39; }
.node-text { font:12px Arial,sans-serif; fill:#486555; }
.edge-text { font:10px Arial,sans-serif; fill:#747851; }
.connector { fill:none; stroke:#6f867b; stroke-width:1.6; }
.lane-label { font:600 11px Arial,sans-serif; fill:#607364; letter-spacing:1px; }
figcaption { font-size:7.6pt; color:#6a7f71; margin-top:2mm; line-height:1.35; }
.label { display:inline-block; font-size:7.5pt; padding:1mm 2mm; background:#e8f1ea; border-radius:4px; margin-right:1mm; color:#1c624b; }
.cover { background:#f6f8f3; padding-top:18mm; }
.cover .mark { width:22mm; height:22mm; object-fit:contain; }
.cover h1 { font-size:38pt; margin-top:12mm; line-height:1.06; }
.cover .subhead { font-size:17pt; color:#536f5d; max-width:150mm; line-height:1.35; }
.cover .cover-band { height:4px; background:#c59c46; width:31mm; margin:8mm 0; }
.cover .cover-meta { display:grid; grid-template-columns:1fr 1fr; gap:4mm; margin-top:8mm; }
.cover .cover-meta div { border-top:1px solid #cfdfd0; padding-top:2.5mm; font-size:9pt; }
.cover .quote { font-size:13pt; }
.toc td:last-child { text-align:right; white-space:nowrap; width:15%; }
a { color:#155e47; text-decoration:none; }
.chip-row { margin:3mm 0; }
.rule { height:1px; background:#dce6de; margin:4mm 0; }
.actions li { margin-bottom:2.3mm; }
#page-10 .persona .kv{grid-template-columns:repeat(3,1fr);} #page-25 table{margin:2mm 0;} #page-25 .box{padding:2.5mm;} #page-25 h2{margin:3.5mm 0 2mm;}\n#page-12 figure svg{height:112mm;} #page-15 figure svg,#page-21 figure svg{height:97mm;} #page-18 figure svg{height:93mm;}
@media print { body{background:white;} .page{margin:0;box-shadow:none;} }
'''

# 01 — cover
page('Digital ILAC', '''
<img class="mark" src="../../assets/images/ap-emblem.png" alt="Andhra Pradesh emblem">
<p class="chapter" style="margin-top:7mm">APBOCWWB · Government of Andhra Pradesh</p>
<h1>Digital ILAC<br>Client Demonstration<br>Playbook</h1>
<div class="cover-band"></div>
<p class="subhead">A presenter’s guide to explain the prototype, perform the live flows and show the evidence.</p>
<div class="box"><p class="quote">One centre connects worker registration, field outreach, departmental services, employment and education counselling.</p></div>
'''+stats([('5','Scripted scenarios'),('5','UI configuration tasks'),('3,684','Issued source records'),('90 min','Official demonstration')])+'''
<div class="cover-meta"><div><b>Tender ID</b><br>985903 · Digital ILAC Part 1 · T-4</div><div><b>Data and contract</b><br>Issued dataset v1.0 · local Government mocks</div><div><b>Audience</b><br>Presenter, operator, field functionary and Authority</div><div><b>Prepared</b><br>14 October 2026 · project presenter handbook</div></div>
<p class="source" style="margin-top:9mm">Based on the supplied demonstration pack, the project implementation and the original dataset folder. Use this PDF for preparation; perform scored steps live in the application.</p>
''', cls='cover')

# 02 — quick map
page('Start here: the route through your demo', '''
<p>Begin with a short service-delivery story, prove that the issued data is loaded, and then follow S1 to S5. After each scenario, publish its C-task through the Authority account and show the change in the relevant user screen.</p>
'''+say('We will show how an ILAC centre can register a worker, reach a worksite without connectivity, follow a departmental service, record an employment offer and support a dependant’s education. Every example uses the issued synthetic dataset.')+'''
<h2>Your first three actions</h2>
<ol class="actions"><li>Start the local server and open <b>http://localhost:8080</b>.</li><li>Use <b>demo.admin.state → Environment</b> to reset the rehearsal, set D and verify the original counts and hashes.</li><li>Prepare independent role sessions and the installed Android field app. Start the 90-minute clock only when the Committee instructs you.</li></ol>
'''+texttable(['Clock','Show','Guide pages'],[
('00:00–00:05','Opening: purpose, issued data, environment and readiness','3–7'),
('00:05–00:20','S1 / C1: registration, household baseline and exceptions','8–11'),
('00:20–00:35','S2 / C2: actual offline capture, sync and conflict resolution','12–14'),
('00:35–00:50','S3 / C3: service clocks and manual fallback','15–17'),
('00:50–01:05','S4 / C4: job mela, spot offer and placement follow-up','18–20'),
('01:05–01:20','S5 / C5: counselling, MIS and a saved report','21–26'),
('01:20–01:30','Committee probes: repeat appropriate steps and inspect logs','27–33')
])+box('The presentation pattern','<p><b>Explain the need → perform the action → point to the saved result → open its evidence → explain the department’s benefit.</b></p><p>Keep the application visible. State the outcome before opening detailed logs. Close modals after each evidence check so the next action remains clear.</p>')+box('Preparation document','<p>The tender’s scored steps must be performed live. This handbook and its diagrams are rehearsal aids; they do not replace the live application or the official Annexure-B scoring sheet.</p>','gold'), '01 · Presenter route')

# 03 — environment
page('Prepare the environment before the client arrives', '''
<h2>Start the local application</h2>
<pre>cd "/Users/shivakumarat/Desktop/ILAC Prototype"\nnpm start</pre>
<p>Keep the terminal running. Open <b>http://localhost:8080</b> on the laptop. No npm runtime packages need to be installed. The local server holds the shared rehearsal state and the mocked Government API endpoints.</p>
'''+cols('''<h2>Authority preparation</h2><ol><li>Sign in as <b>demo.admin.state</b>.</li><li>Open <b>Environment → Reset rehearsal to issued dataset</b>.</li><li>Set <b>Actual demonstration date</b> to the Board’s slot date and rebase offsets.</li><li>Select <b>Verify issued source hashes</b>. Confirm 22 tables / 3,684 records.</li><li>Confirm Civil Supplies remains unavailable for S3.</li><li>Leave C1–C5 unpublished until their live task.</li></ol>''','''<h2>Android preparation</h2><ol><li>Use the same bidder-controlled Wi-Fi/hotspot as the laptop.</li><li>Run <b>npm run cert</b>; restart the server.</li><li>Trust only the public <b>.runtime/tls/ca.crt</b> on the phone.</li><li>Open the printed <b>https://&lt;LAN-IP&gt;:8443</b> URL and install Digital ILAC.</li><li>Allow camera/location; verify screen mirroring.</li><li>Sign in as <b>demo.ff.krs</b>, clear old device rehearsal data after server reset, then download SYN-VIS-001 online.</li></ol>''')+box('45-minute setup checklist',bullets(['Prepare operator, field, supervisor, departmental, employer, counsellor, PMU and Authority sessions in separate browser profiles/devices.','Verify the phone camera, GPS, trusted HTTPS, offline reload and reconnection before the slot; reset and download again after practice.','Check display/HDMI, power, phone mirroring, bidder primary connectivity and a standby device.','Keep the seven issued PNG specimens ready in a file picker. Share credentials with the Committee.','Use a separate hotspot/router so the field phone’s airplane mode does not disconnect the online operator.']))+box('Reset once before the run','<p>A server reset changes the rehearsal ID. On every field device select <b>Clear device rehearsal data</b> and download the visit again. Restarting the server alone keeps previous changes; signing out does not reset records.</p>','gold')+source_line(['README.md, sections 1–5','issued pack, sections 2, 5 and 9']), '02 · Setup')

# 04 — credentials
page('Role accounts: show the right screen to the right user', '''
<p>Use the exact accounts issued in <b>M05_Users_Roles</b>. Every account uses the bidder-set password <b>admin@123</b> and mock OTP <b>123456</b>. The OTP appears in the local console; no real OTP message is sent.</p>
'''+texttable(['Login ID','Issued role / jurisdiction','Enabled modules'],[[u['login_id'],u['role']+' · '+u['jurisdiction'],u['modules_enabled']] for u in T['M05_Users_Roles']], 'roles dense')+say('Each role receives its assigned modules and records. The centre operator captures services, the field functionary works offline, the supervisor resolves conflicts, the department updates its worklist, and the PMU reads reports. Authority publishing is a separate responsibility.')+box('Permissions to demonstrate','<p>The supervisor’s limited SM-19 permits conflict resolution, not configuration publishing. The employer sees its own candidates/offers. Private counselling notes remain with the assigned counsellor. The PMU is an analyst. Module and action/jurisdiction checks also run on the server.</p>')+box('Keep sessions independent','<p>In S2, keep <b>demo.ff.krs</b> offline and <b>demo.op.krs</b> online at the same time; use <b>demo.sup.krs</b> for resolution. Prepare separate departmental sessions in S3. Do not change one tab’s account to simulate concurrency.</p>','gold'), '03 · Accounts', cls='dense')

# 05 — all counts
count_descriptions={
'M01_Districts':'District master / synthetic LGD codes','M02_ILAC_Centres':'Centre master','M03_Trades':'Construction trade master','M04_Services':'Department, channel, documents and clocks','M05_Users_Roles':'Role/module/jurisdiction accounts','T01_Workers':'Legacy registry, anchors and deliberate duplicates','T02_Households':'Household baselines','T03_Members':'Members, relationships and education stages','T04_Employers':'Employer catalogue','T05_Sites':'Construction sites and approximate coordinates','T06_Vacancies':'Vacancy catalogue / 12 event vacancies','T07_JobMela_Event':'JM-2026-01 configuration','T08_JobMela_Candidates':'20 event preregistrations','T09_Worksite_Visit_S2':'12-row scripted field roster','T10_Referrals':'Existing referrals with date offsets','T11_Grievances':'Grievance records with date offsets','T12_Training_Batches':'Skilling / RPL batches','T13_Counsellors':'Counsellors and availability','T14_Counselling_Cases':'Existing education counselling cases','S_Personas':'Exact P-01 to P-08 input cards','S_MIS_Queries':'Q1–Q5 definitions','S_Mock_API_Behaviour':'14 required mock behaviour entries'}
page('Explain the dataset before changing any record', '''
<p>All operational seed records come from <b>ILAC_Demo_Datasets_v1.0 2</b>. The application imports the 22 UTF-8 CSV tables without changing their cell strings. The workbook, YAML, CSVs and seven specimens are preserved.</p>
'''+texttable(['Issued table','Count','What it supplies'],[[name,DATA['counts'][name],count_descriptions[name]] for name in T], 'dense')+'<p><b>Total: 3,684 issued records.</b> Counts are shown before any scripted changes.</p>'+box('What is allowed to change','<p>New records and updates occur during the scripted flows: P-01/P-03/P-04/P-06 registration, the newborn, referrals, interviews, offers, counselling and C1–C5 configuration. These are rehearsal changes; the original source files stay unchanged.</p>')+source_line(['ILAC_Demo_Datasets_v1.0.xlsx','csv/*.csv','data/issued-data.json','31 original source-file SHA-256 checks']), '04 · Data provenance', cls='dense')

# 06 — architecture and end-to-end overview
arch=edge([(205,52),(246,52)])+edge([(205,153),(225,153),(225,77),(246,77)])+edge([(443,54),(473,54)])+edge([(443,79),(458,79),(458,158),(473,158)])
arch+=node(5,16,200,'Role web interfaces',('Desk / department / employer','Counsellor / PMU / Authority'))+node(5,117,200,'Android field PWA',('Encrypted local queue','Works offline after download'),'gold')+node(247,26,197,'Local application server',('Shared state + permissions','Audit + clocks + reports'),height=111)+node(474,16,190,'Issued working tables',('22 tables / original snapshot','Scripted rehearsal changes'))+node(474,122,190,'Local Government mocks',('13 supplied path families','Request/response + messages'),'blue')
page('What is inside this working prototype', '''
<p>The prototype links five service workflows through role-based screens, household/member relationships, shared rehearsal state and evidence logs. Different supplied personas are used for different scenarios; do not suggest that every story uses the same person.</p>
'''+diagram(arch,216,'Local demonstration architecture. Government counterparts and messaging are mocked within the bidder environment.')+texttable(['Capability shown','Worker or record used','Client benefit to explain'],[
('Assisted registration / consent / queue','P-01; P-02 duplicate; P-03 timeout','Record a worker accurately and keep a documented next step.'),
('Offline field outreach / sync / conflict','P-04; SYN-VIS-001; worker 120','Continue capture without connectivity and preserve competing edits.'),
('Departmental convergence / service clocks','P-05; SK-01 / CS-01; SYN-R-00151','Track office responsibility, due dates and a manual route when a dependency fails.'),
('Job mela / employer offer / follow-up','P-06 / P-07; JM-2026-01','Move from attendance to an offer and a dated joining follow-up.'),
('Dependant counselling / education','P-08; SYN-M-001909; SYN-C-01','Link educational support to a member and the worker household.'),
('MIS / report builder / Authority changes','Q1–Q5; C1–C5; State → district → centre','Give the department live oversight and inspectable rule changes.')
])+box('Scope to explain accurately','<p>This is a configured local demonstration using HTML/CSS/JavaScript and a Node.js server, with an installable field PWA. It includes real rehearsal actions, not production Government integrations. No AI model is connected. The 23-service catalogue is issued reference data; only the scripted workflows and supplied mock contracts are demonstrated end to end.</p>','gold'), '05 · Prototype overview')

# 07 — opening speaker notes
page('The opening: make the purpose clear in five minutes', '''
<p class="chip-row"><span class="label">00:00–00:05</span><span class="label">Authority / environment evidence</span></p>
'''+texttable(['Time','What to do','What to say'],[
('0:00–0:45','Briefly show the landing page; state the five journeys.','“Digital ILAC brings registration, field outreach, departmental referrals, employment and education counselling into a connected service flow.”'),
('0:45–1:45','Open Authority Environment; show 22 counts and source verification.','“This environment starts with the Board-issued v1.0 dataset: 3,684 synthetic records. The source files are unchanged and the six seeded duplicate pairs are retained.”'),
('1:45–2:30','Show actual D and rebased offsets.','“We have set D to today’s allotted slot. Offset-driven due dates move with D; fixed source DOBs and age fields stay as issued.”'),
('2:30–3:30','Show mock log/contract readiness and messaging destination.','“The supplied Government API contracts run locally. Messages are written only to the mock log. We will show the required timeout and Civil Supplies outage as part of the live flows.”'),
('3:30–4:15','Show field device online, installed app, downloaded visit and independent operator session.','“The field device is prepared for actual airplane-mode capture, encrypted storage and automatic sync. The online centre session will edit the same worker in parallel.”'),
('4:15–5:00','Hand over to demo.op.ntr and prepare S1.','“We will follow S1 to S5 in the issued order. Each scenario ends with its Authority configuration task, published through the UI.”')
])+say('Please observe the saved record, its role-specific view and its evidence after each action. We will show not only the normal path, but also duplicates, unavailable verification, offline changes and a departmental fallback.')+box('Smooth handover to S1','<p><b>Transition:</b> “Let us begin at the NTR assisted desk with Kona Venkata Ramana, a new walk-in worker.”</p><p>Log in as <b>demo.op.ntr</b>, show the permitted menu and switch Telugu/English. Avoid a long public-page tour; the scored evidence is in the working role screens.</p>')+box('Opening discipline','<p>The 90-minute clock starts on Committee instruction after setup. A brief architecture explanation is allowed in the opening. Keep commercial bid/price information out of the session. The official task order and fixed stop times control the run.</p>','gold'), '06 · Opening script')

# 08 — S1 diagram
page('S1: register accurately, then handle exceptions', chain([
('1 · Walk-in token',('P-01 / NTR assisted desk','Issue and call the token'),'green'),
('2 · Search and verify',('BOCW: no match','e-Shram: verified UAN'),'green'),
('3 · Worker registration',('Exact issued P-01 values','Missing-DOB validation'),'green'),
('4 · Consent + household',('Version / purpose / time','Four linked dependants'),'green'),
('5 · Controlled documents',('Photo + work certificate','Classified and role-scoped'),'green'),
('6 · Acknowledge',('On-screen receipt','Telugu SMS / WhatsApp log'),'blue')
])+cols(box('P-02: a separate returning worker','<p>Type <b>Gorle Laxmi</b>. The registry flags <b>SYN-W-000607 / Gorle Lakshmi</b>. Link the existing master and inspect the audit entry. Do not create a second worker.</p>','gold'),box('P-03: a separate new worker','<p><b>Pydi Simhachalam</b> encounters a real verification timeout. Registration still completes with a pending status, queued retry and a documented next step.</p>','gold'))+say('This desk process captures the worker once, links the household and records consent before issuing an acknowledgement. We also show how the operator handles a likely duplicate and an unavailable verification service without losing the worker’s request.')+texttable(['Presenting role','Source records','Outcome to point at'],[
('demo.op.ntr','P-01, P-02, P-03; existing worker 607','New registration / existing-record link / pending verification'),
('demo.admin.state','C1: household form configuration','Mandatory primary-language field on the next form')
])+box('Proof that strengthens this story','<p>Show the saved consent, four member relationships, controlled document links, Telugu message payloads and duplicate-link audit entry. The 10-second failure is intentionally part of the issued script; explain the next action rather than apologising for an expected mock behaviour.</p>')+source_line(['S_Personas','T01_Workers','T02_Households','T03_Members','S_Mock_API_Behaviour']), 'S1 · Flow', '00:05–00:20 · Assisted worker registration and household baseline capture')

# 09 — S1 live actions
s1_steps=[
('1.1','Sign in as demo.op.ntr; show only its enabled modules; switch Telugu ↔ English.','“This assisted desk works within its centre role and offers Telugu/English controls.”'),
('1.2','S1 / SM-18 → Issue token → Call token for P-01.','“The worker now has a tracked place in the centre queue.”'),
('1.3','Register worker → P-01 → Search registry → Verify e-Shram. Show no BOCW match and SYN-UAN-77810011.','“We search before creating a new master and record the external verification result.”'),
('1.4','Clear DOB and attempt Save once. Show the error; restore 1984-06-12 and review the exact source values.','“Mandatory-field validation prevents an incomplete worker record.”'),
('1.5','Enter consent purpose, choose channel and tick consent. Save the notice version, timestamp and operator.','“The record explains what was consented to, how and when.”'),
('1.6','Review the household baseline and four dependant rows; save registration and show linked IDs.','“A linked household allows the centre to assist dependants as well as the worker.”'),
('1.7','Documents → new P-01 worker → upload Photo and Work certificate from the issued PNGs.','“Documents are classified and accessed through the authorised record.”'),
('1.8','Return to S1 → View acknowledgement; show the receipt and Telugu SMS + WhatsApp mock logs.','“The worker receives a clear acknowledgement after the required documents are captured.”'),
('1.9','Type Gorle Laxmi → Search P-02 → Link existing SYN-W-000607; open Audit trail.','“We preserve the existing registry master and log the operator’s linking decision.”'),
('1.10','Choose P-03 → Verify e-Shram; wait 10 seconds. Upload P-03 photo, record consent and save. Show pending, retry and next step.','“An unavailable verification service creates a pending task; the worker can still register.”')
]
page('S1: the exact live sequence and speaking cues', texttable(['Step','Perform in the application','Explain the result'],s1_steps,'steps')+box('C1 · final three minutes','<p>Switch to <b>demo.admin.state → Configuration → C1</b>. Publish mandatory dropdown <b>Primary language of worker</b> with <b>Telugu / Urdu / Odia / Hindi / Other</b>. Show the configuration version, publisher and change log. Return to the operator’s next registration form and point to the required dropdown.</p><p><b>Say:</b> “The Authority changed the form through the UI. The next registration receives the new field without a code change or redeployment.”</p>','gold')+box('Transition to S2','<p>“We have seen the centre desk. Next, we take the same service approach to a worksite where the field device has no connectivity.”</p>')+source_line(['issued pack: steps 1.1–1.10 and C1','S_Personas P-01/P-02/P-03']), 'S1 · Live script', cls='dense')

# 10 — P1 input card
p1=P['P-01']
members=[]
for segment in p1['household'].split('; '):
    m=re.match(r'^(Spouse|Son|Daughter|Mother): (.*?) \(([MF]), (\d{4}-\d{2}-\d{2}), (.*)\)$',segment)
    members.append((m[1],m[2],m[3],m[4],m[5]))
page('P-01 input card: capture the issued values',persona_card('P-01', include_household=False)+
texttable(['Relationship','Member name','Gender','DOB','Education / occupation'],members,'dense')+
box('Household capture explanation','<p>These are the <b>four dependant members</b> in the source card. The worker is the household head separately. Show each member’s household link after saving.</p>')+
cols(box('Consent and acknowledgement','<p><b>Notice:</b> CONSENT-DEMO-v1<br><b>Purpose:</b> worker registration and household baseline<br><b>Channel:</b> choose the actual assisted-desk channel<br><b>Result:</b> timestamp, operator and a documented next step.</p>'),box('Document capture','<p>Use <b>specimen_photo_P-01.png</b> as Photo and <b>specimen_work_certificate_P-01.png</b> as Work certificate. Upload the original supplied files before issuing the acknowledgement.</p>'))+
source_line(['S_Personas: P-01','specimen_documents/','CONSENT-DEMO-v1']), 'S1 · Data card', 'Input card values are synthetic and must be kept as issued.', cls='dense')

# 11 — P2 + P3 exact values
p2_registry=W['SYN-W-000607']
page('P-02 and P-03: make the two exception paths clear',
persona_card('P-02',True)+
box('P-02: preserve the registry','<p><b>Type:</b> Gorle Laxmi. <b>Link:</b> SYN-W-000607, Gorle Lakshmi / SYN-H-000531. The source card and registry differ in masked Aadhaar, experience and bank/smartphone fields. Those differences are not a request to overwrite the registry.</p><p class=\"small\">Registry experience: '+e(p2_registry['years_experience'])+' years; bank account: '+e(p2_registry['bank_account_held'])+'; smartphone: '+e(p2_registry['smartphone'])+'. Show the match score ≥0.85, the retained master and the audit link.</p>','gold')+
persona_card('P-03',True)+
box('P-03: finish with a pending action','<p><b>Baseline:</b> '+e(P['P-03']['household_baseline'])+'</p><p>The mock for <b>SYN-UIDTOK-41100031</b> gives no response within 10 seconds. Show <b>Pending - external system unavailable</b>, a queued retry and the acknowledgement’s owner, action, target date, documents and route.</p>')+
source_line(['S_Personas: P-02/P-03','T01_Workers: SYN-W-000607','e-Shram mock behaviour']), 'S1 · Exception data', cls='dense')

# 12 — S2 swimlane
s2svg='<rect x=\"0\" y=\"0\" width=\"327\" height=\"426\" rx=\"10\" fill=\"#f8f5eb\"/><rect x=\"343\" y=\"0\" width=\"327\" height=\"426\" rx=\"10\" fill=\"#f2f7f4\"/><text x=\"16\" y=\"20\" class=\"lane-label\">ANDROID FIELD FUNCTIONARY</text><text x=\"359\" y=\"20\" class=\"lane-label\">ONLINE CENTRE / SUPERVISOR</text>'
s2svg+=edge([(161,110),(161,136)])+edge([(161,208),(161,232)])+edge([(161,304),(161,330)])+edge([(508,208),(508,330)])+edge([(311,366),(357,366)],'sync',(320,356))+edge([(508,402),(508,464),(485,464)])+edge([(161,402),(161,464),(183,464)])
s2svg+=node(12,38,300,'1 · Online visit download',('SYN-VIS-001 / 12 roster workers','Receive assigned data and current form'))+node(12,136,300,'2 · Actual airplane-mode capture',('Attendance / photo / GPS / skilling','P-04 registration + worker 120 edit'),'gold')+node(12,232,300,'3 · Encrypted local queue',('AES-256-GCM ciphertext','P-04 provisional ID; retained on reload'),'gold')+node(12,330,300,'4 · Reconnect: automatic sync',('Duplicate check + permanent worker ID','Saved visits, needs and sync receipts'))+node(358,136,300,'Parallel centre edit',('demo.op.krs edits worker 120','Mobile = 9000099102'),'blue')+node(358,330,300,'5 · Preserved mobile conflict',('Field 9000099101 / centre 9000099102','Base value and both versions visible'),'gold')+node(184,438,300,'6 · Supervisor resolution',('demo.sup.krs chooses with a reason','Audit trail + worker histories'),height=77)
page('S2: continue field work when the device is offline',diagram(s2svg,530,'The field phone is truly offline while the separate centre session remains online. Reconnection processes queued actions and surfaces the competing mobile edits.')+
say('We download the assignment before leaving connectivity. On the worksite, the device captures the visit and a new worker into an encrypted queue. After reconnection, the server checks duplicates and synchronises the record. If two users changed the same field, the supervisor sees both versions and records a reason for the final choice.')+
texttable(['Role','What the client should watch'],[('demo.ff.krs','Android airplane mode, camera/GPS, provisional ID, ciphertext and sync queue'),('demo.op.krs','Independent online edit on SYN-W-000120 while phone is offline'),('demo.sup.krs','Preserved versions, selected value, resolution reason and audit')])+
source_line(['T09_Worksite_Visit_S2','T05_Sites: SYN-S-0006','T01_Workers: SYN-W-000120','S_Personas: P-04']), 'S2 · Flow', '00:20–00:35 · Offline worksite transaction and synchronisation')

# 13 — S2 actions
s2_steps=[
('2.1','On the installed Android app, demo.ff.krs → S2 → Download assigned visit while online. Show all 12.','“This is the issued site assignment, including workers from both assigned Krishna centres.”'),
('2.2','Turn on actual airplane mode and disable remaining Wi-Fi. Ask the Committee to verify offline status.','“The device is now offline. The following actions stay on this device until reconnection.”'),
('2.3','Record attendance for all 12; set 182 and 225 Absent; the other ten Present.','“Attendance follows the issued T09 outcomes and retains worker IDs.”'),
('2.4','Enter the safety observation; use device camera; Capture location; save the visit.','“This visit includes device-captured evidence and location.”'),
('2.5','Capture the three marked skilling needs for workers 030, 097 and 183.','“The visit identifies the workers who need a batch/group referral.”'),
('2.6','Register P-04 offline with consent, C1 language and device photo. Show provisional ID and encrypted evidence.','“The new record is encrypted locally and can survive an offline app reload.”'),
('2.7','Save field mobile 9000099101 for worker 120. In parallel, demo.op.krs saves 9000099102 online.','“These are two genuine sessions changing the same field independently.”'),
('2.8','Reconnect the phone. Show automatic sync, queue receipts, duplicate-search log and P-04 permanent ID.','“Queued work is processed by the shared server; the local provisional ID is reconciled.”'),
('2.9','demo.sup.krs → conflict → show both versions/base; select a value, enter a reason and resolve.','“The decision is explicit and the losing value remains in the audit history.”'),
('2.10','Open visit histories; SM-20 → three marked needs and issued KRS batch/grouping.','“The field capture becomes available for centre follow-up.”')
]
page('S2: the exact live sequence and speaking cues',texttable(['Step','Perform in the application','Explain the result'],s2_steps,'steps')+
box('C2 · final three minutes','<p>Authority publishes <b>PPE – safety helmets available on site</b>, response <b>Yes/No</b>, through Configuration → C2. Run the next field sync and show the new checklist item and version.</p><p><b>Say:</b> “The field form received an Authority change at synchronisation. The installed app was not rebuilt.”</p>','gold')+
box('Transition to S3','<p>“The field information is now available to the centre. We will next follow a worker’s requests across departments, including the route used when an integration is unavailable.”</p>')+
source_line(['issued pack: steps 2.1–2.10 and C2','actual Android capture remains a device preflight/witnessing requirement']), 'S2 · Live script', cls='dense')

# 14 — source roster + P4
page('P-04 and the exact 12-worker field roster',persona_card('P-04',True)+
box('P-04 field registration','<p>The issued card calls for <b>minimum fields on site</b>, with family details to be completed at the centre. No API is called while offline. Photograph the supplied specimen on the device, record consent and select the C1 language. Preserve the encrypted provisional record until sync.</p>')+
texttable(['Worker ID','Issued name','Attendance','Skilling need'],[[r['worker_id'],r['full_name'],r['attendance_to_record'],r['skilling_need_to_record'] or '—'] for r in T['T09_Worksite_Visit_S2']],'dense')+
box('The deliberate conflict','<p><b>SYN-W-000120 / Pallapu Gopi</b> starts with source mobile <b>9000002170</b>. Field: <b>9000099101</b>. Centre: <b>9000099102</b>. Retain all three values in the evidence and select the final value with a supervisor reason.</p>','gold')+
source_line(['S_Personas: P-04','T09_Worksite_Visit_S2: all 12 rows','T01_Workers: SYN-W-000120']), 'S2 · Data card', cls='dense')

# 15 — S3 branching flow
s3svg=edge([(337,81),(337,106),(158,106),(158,137)])+edge([(337,106),(513,106),(513,137)])+edge([(158,209),(158,241)])+edge([(513,209),(513,241)])+edge([(158,313),(158,337),(337,337),(337,359)])+edge([(513,313),(513,337),(337,337)])
s3svg+=node(177,8,320,'P-05 · worker and household',('SYN-W-000608 / SYN-H-000532','Add Bandaru Likhitha + birth certificate'))+node(8,137,300,'Referral A · SK-01 / APSSDC',('Local API returns 201 acknowledgement','7-day service clock'),'green')+node(363,137,300,'Referral B · CS-01 / Civil Supplies',('Local API returns 503 / API unavailable','Automatic manual / assisted fallback'),'gold')+node(8,241,300,'APSSDC departmental status',('Operator triggers seat confirmation','Status poll → Seat confirmed'),'blue')+node(363,241,300,'Same CS-01 case continues',('21-day clock / slip / department worklist','Received – documents verified'),'gold')+node(177,359,320,'One worker acknowledgement',('Both referral IDs / responsible offices','Due dates / documents / next steps'),height=76)
page('S3: two services, one worker-facing follow-up',diagram(s3svg,450,'SK-01 and CS-01 have separate referral IDs. The CS-01 ID is retained when its API attempt continues through the manual fallback; it is not replaced by a new case.')+
say('Bandaru Nagaraju needs two services. Training receives an API acknowledgement and a seven-day clock. Rice-card member addition encounters the required outage and automatically continues through a manual departmental route. The worker receives one acknowledgement describing both requests, responsible offices and next steps.')+
cols(box('Show continuity','<p>Point to the CS-01 ID in the failed request, saved referral, printable slip and departmental worklist. It is the <b>same case lifecycle</b> across the API attempt and manual route.</p>'),box('Show accountability','<p>Open pre-existing <b>SYN-R-00151</b>: created D−25, due D−4. Its overdue view shows derived escalation dates <b>L1 D−11</b> and <b>L2 D−4</b>.</p>','gold'))+
source_line(['S_Personas: P-05','T10_Referrals: SYN-R-00151 / SYN-R-00152','M04_Services: SK-01 / CS-01']), 'S3 · Flow', '00:35–00:50 · Convergence referral, service clock and manual fallback')

# 16 — S3 steps
s3_steps=[
('3.1','demo.op.krs → S3 → P-05 household timeline; show completed LB-01 / SYN-R-00152.','“This is an existing worker; earlier services are retained on the timeline.”'),
('3.2','Add daughter Bandaru Likhitha with DOB D−60; upload the issued birth-certificate PNG.','“The newborn is linked to the household and her supporting document.”'),
('3.3','New referral → SK-01 → submit. Show APSSDC 201 acknowledgement and 7-day due date.','“The case has a counterpart acknowledgement and an accountable service clock.”'),
('3.4','New referral → CS-01 + birth certificate → submit. Show 503, same case ID, manual route, 21-day clock and printable slip.','“The unavailable API changes the route, while the ILAC case remains traceable.”'),
('3.5','Open One acknowledgement · both referrals; show IDs, offices, due dates and next steps.','“The worker can follow both requests from one clear acknowledgement.”'),
('3.6','demo.nodal.cs → SM-22 → new CS-01 case → Received – documents verified; save evidence.','“The department confirms receipt through its own worklist.”'),
('3.7','demo.nodal.sk or demo.op.krs → SK-01 → Trigger Seat confirmed → Poll mock status.','“The external status is reflected in the same referral record.”'),
('3.8','demo.dlo.krs → SYN-R-00151; show overdue, L1/L2 dates and pendency.','“An overdue case has a visible escalation path and officer responsibility.”'),
('3.9','Open integration dependency; show Civil Supplies down, request/response error, retry 3600 and open dependency.','“The integration failure is observable and has a documented next action.”')
]
page('S3: the exact live sequence and speaking cues',texttable(['Step','Perform in the application','Explain the result'],s3_steps,'steps')+
box('C3 · final three minutes','<p>Authority → Configuration → C3: publish <b>CS-01 clock 21 → 15 days</b> and <b>L1 14 → 10 days</b>, for new referrals only. Show history. Reopen existing cases: their 21-day clock stays unchanged. Create a further CS-01 referral to show the new 15-day clock.</p><p><b>Say:</b> “The new rule applies prospectively. Existing commitments retain the version under which the case was created.”</p>','gold')+
box('Keep the required outage in place','<p>Do not restore Civil Supplies during S3. Only if the Committee asks to see reconciliation should Authority record its restore instruction, after which an existing manual case can reconcile using the same case ID.</p>','blue')+
box('Transition to S4','<p>“The centre also supports employment. We will now move from job-mela registration to interview allocation, an employer offer and a joining follow-up.”</p>')+
source_line(['issued pack: steps 3.1–3.9 and C3']), 'S3 · Live script', cls='dense')

# 17 — P5 and dates
p5w=W['SYN-W-000608']
page('P-05 input and the pre-existing referral anchors',persona_card('P-05',True)+
box('Add the daughter using D','<p><b>Name:</b> Bandaru Likhitha · <b>Relationship:</b> Daughter · <b>DOB:</b> actual demonstration day minus 60 days. Attach <b>specimen_birth_certificate_P-05.png</b>. The birth-certificate specimen itself describes its date as D−60.</p>')+
texttable(['Existing record','Issued values / live interpretation'],[
('Worker / household','SYN-W-000608 / SYN-H-000532; Bandaru Nagaraju. Registry experience is '+p5w['years_experience']+' years; persona card says 12. Preserve the registry.'),
('SYN-R-00152 / LB-01','Completed - service delivered. Created D−40, due D−33, closed D−36. Show this earlier renewal on the household timeline.'),
('SYN-R-00151 / CS-01','Submitted; manual / assisted fallback. Created D−25; original clock 21; due D−4. Responsible officer demo.nodal.cs.'),
('Derived L1 history','Created D−25 + 14 days = D−11; escalated to demo.dlo.krs.'),
('Derived L2 history','Created D−25 + 21 days = D−4; escalated to State PMU.'),
('New SK-01 referral','Created during demonstration: due D+7; local APSSDC acknowledgement.'),
('New CS-01 before C3','Due D+21; manual fallback after local 503; print slip and departmental receipt.'),
('New CS-01 after C3','Due D+15; L1 D+10; older cases retain original rule snapshot.')
], 'dense')+
box('How to explain date rebasing','<p>“D is our actual demonstration day. Offset fields move the timeline with D. We leave fixed source DOBs, registration dates and age_on_2026_10_01 unchanged.”</p><p class=\"small\">The workbook’s nominal D is 2026-11-02. The escalation history is derived from the issued offset/rule fields and labelled accordingly; it was not supplied as a separate history table.</p>','gold')+
source_line(['S_Personas: P-05','T01_Workers','T10_Referrals','M04_Services']), 'S3 · Data card', cls='dense')

# 18 — S4 diagram / event facts
s4svg=edge([(156,81),(156,118)])+edge([(512,81),(512,118)])+edge([(156,190),(156,225)])+edge([(512,190),(512,225)])+edge([(156,297),(156,329)])+edge([(512,297),(512,329)])
s4svg+=node(7,9,299,'P-06 · Kandula Rajesh',('New walk-in worker / Mason','BOCW no match + source photograph'))+node(362,9,300,'P-07 · Anumolu Raju',('Existing worker SYN-W-000302','Preregistered JMR-004 / Bar bender'))+node(7,118,299,'Register and check in',('Worker + NCS + event eligibility','JM-2026-01 walk-in candidate'))+node(362,118,300,'Check in existing candidate',('Retain JMR-004 and worker master','Use event candidate scope'))+node(7,225,299,'Interview: SYN-E-001 / V-0001',('Mason vacancy','Employer records a spot offer'),'blue')+node(362,225,300,'Interview: SYN-E-006 / V-0006',('Bar bender vacancy','Employer decision pending'),'gold')+node(7,329,299,'Placement / joining follow-up',('Source wage ₹850 per day','Expected joining D+3 / mock message'))+node(362,329,300,'Dated pending follow-up',('Follow up on D+2','No offer claimed for P-07'),'gold')
event=T['T07_JobMela_Event'][0]
page('S4: show the journey beyond event attendance',diagram(s4svg,416,'A recorded spot offer is an employment outcome to follow up. Expected joining is tracked separately; the prototype does not claim that the worker has already joined.')+
say('This event has preregistered and walk-in candidates. We match each to a vacancy, allocate interviews and capture the employer’s decision. The spot offer creates a placement-linked follow-up, while a pending decision receives its own dated follow-up.')+
stats([('300','Event capacity'),('6','Participating employers'),('12','Event vacancies'),('20','Preregistered candidates')])+
texttable(['Issued event field','Value'],[('Event / venue',event['event_id']+' / '+event['venue_centre_id']),('Name',event['event_name']),('Calendar',event['event_date']+' · '+event['start_time']+'–'+event['end_time']),('Organiser / desk',event['organiser']+' / '+event['point_of_contact'])],'dense')+
source_line(['T07_JobMela_Event','T08_JobMela_Candidates','T04_Employers','T06_Vacancies','S_Personas: P-06/P-07']), 'S4 · Flow', '00:50–01:05 · Job-mela registration and spot-offer / placement record')

# 19 — S4 steps
s4_steps=[
('4.1','demo.dlo.gnt / demo.op.gnt → S4. Show event, six employers, 12 vacancies, venue, capacity and shared calendar.','“The event uses the issued employer and vacancy configuration.”'),
('4.2','Open the 20 preregistered candidates; check in JMR-004 / P-07.','“This candidate retains his existing worker and event-registration links.”'),
('4.3','Register P-06 with source values/photo and C1 language. Show BOCW no match. In S4 check eligibility/documents; register and check in.','“A walk-in is registered, checked and linked to the event; NCS returns a mock reference.”'),
('4.4','Allocate P-06 → SYN-V-0001 / SYN-E-001 and P-07 → SYN-V-0006 / SYN-E-006.','“Interview allocation records the candidate, vacancy and employer.”'),
('4.5','demo.emp.001 → own candidate → spot offer. Set ₹850/day, source engagement type, joining D+3.','“The employer records the offer through its own restricted portal.”'),
('4.6','Mela desk → P-07: Employer decision pending; follow-up D+2.','“A pending outcome remains visible with a next follow-up date.”'),
('4.7','Show SM-05 placement, expected joining task and mock worker notification.','“The offer moves into placement follow-up, rather than ending at the event desk.”'),
('4.8','Open the live event dashboard / closure report by employer. Show 21 registrations, 2 check-ins, 2 interviews and 1 offer after this sequence.','“The organiser can reconcile attendance, interviews and employer decisions.”')
]
page('S4: the exact live sequence and speaking cues',texttable(['Step','Perform in the application','Explain the result'],s4_steps,'steps')+
box('C4 · final three minutes','<p>Authority → Configuration → C4: add <b>Solar panel installer</b> and publish a vacancy for <b>SYN-E-002</b> at <b>JM-2026-01</b>. Review the supplied employer’s template fields, publish and show the new trade/vacancy in matching options and the event.</p><p><b>Say:</b> “An Authority-published trade and vacancy becomes available immediately in the event and matching list.”</p>','gold')+
box('Show the employer boundary','<p>demo.emp.001 sees SYN-E-001’s candidates and offers. P-07’s preferred vacancy is with SYN-E-006 and remains a desk/organiser follow-up. Do not record P-07’s outcome from the wrong employer account.</p>')+
box('Transition to S5','<p>“The centre’s support extends to worker dependants. We will show education counselling, then use the PMU reports to review delivery across districts and centres.”</p>')+
source_line(['issued pack: steps 4.1–4.8 and C4']), 'S4 · Live script', cls='dense')

# 20 — P6/P7 and offer values
p7w=W['SYN-W-000302']; v1=next(v for v in T['T06_Vacancies'] if v['vacancy_id']=='SYN-V-0001')
page('P-06, P-07 and the exact offer values',persona_card('P-06',True)+
box('P-06 source-card interpretation','<p>The persona’s role wording says “Registered worker”, while step 4.3 and its mock expectation require quick registration with BOCW no match. Follow the live script: register Kandula Rajesh as a new walk-in; do not change the original card.</p>','gold')+
'<section class=\"persona compact\"><div class=\"persona-title\"><b>P-07</b><h3>Anumolu Raju · existing preregistration</h3></div>'+
kv([('Worker / event registration','SYN-W-000302 / JMR-004'),('Home centre / event venue',p7w['home_centre_id']+' / ILAC-GNT-01'),('DOB / mobile',p7w['date_of_birth']+' / '+p7w['mobile']),('Trade / experience',p7w['primary_trade']+' / '+p7w['years_experience']+' years'),('Gender / household',p7w['gender']+' / '+p7w['household_id']),('UID token',p7w['uid_token_mock']),('Preferred interview','SYN-V-0006 / SYN-E-006'),('Outcome / follow-up','Employer decision pending / D+2')])+
'<p class=\"small\">P-07’s source card says “as in registry” for several fields; the values above are resolved from T01_Workers, not invented inputs. No new P-07 worker master is created.</p></section>'+
texttable(['P-06 source offer field','Use in the demonstration'],[
('Employer / vacancy','SYN-E-001 / SYN-V-0001 / Mason'),('Wage','₹'+v1['daily_wage_offered_inr']+' per day'),('Engagement',v1['engagement_type']),('Source duration_days',v1['duration_days']+' (retain source value; do not rewrite it to fit the engagement label)'),('Expected joining / next action','D+3 / joining follow-up task in SM-05')
], 'dense')+
source_line(['S_Personas: P-06/P-07','T01_Workers: SYN-W-000302','T08_JobMela_Candidates: JMR-004','T06_Vacancies: SYN-V-0001 / SYN-V-0006']), 'S4 · Data card', cls='dense')

# 21 — S5 diagram
s5svg=edge([(335,80),(335,106),(156,106),(156,130)])+edge([(335,106),(513,106),(513,130)])+edge([(156,202),(156,237)])+edge([(513,202),(513,237)])+edge([(156,309),(156,334),(335,334),(335,357)])+edge([(513,309),(513,334),(335,334)])
s5svg+=node(175,8,320,'P-08 · linked student dependant',('SYN-M-001909 / Bonthu Sravani','Father SYN-W-000609 / household 533'))+node(7,130,300,'Appointment + private session',('SYN-C-01 / shared calendar','Assessment / advice / agreed actions'),'gold')+node(363,130,300,'Education service referrals',('ED-02 admission: manual / 15 days','ED-01 scholarship: API / 30 days'))+node(7,237,300,'D+14 follow-up',('Member record + household timeline','Private notes stay with counsellor'),'gold')+node(363,237,300,'Worker-facing service progress',('Referral IDs / due dates / next steps','Mock reminder and acknowledgement'),'blue')+node(175,357,320,'PMU oversight and reports',('State → district → centre','Live Q1–Q5 + saved Authority report'),height=77)
page('S5: support the dependant, then show State oversight',diagram(s5svg,450,'Education support is linked to the dependant and worker household. PMU reporting uses its analyst role; it does not receive the private counselling notes.')+
say('Bonthu Sravani is a worker’s dependant who has completed Class 10 and is not enrolled. The counsellor books an appointment, records a private session, recommends the stated education route and creates two referrals with different channels and clocks. A dated follow-up appears on the linked record. We then switch to the PMU to review the issued live queries.')+
cols(box('What the counsellor records','<p>Assessment, interests, <b>Polytechnic – Diploma in Civil Engineering</b> advice and agreed actions. Show a reminder in the mock gateway and a <b>D+14</b> follow-up.</p>'),box('What the PMU sees','<p>Role-based State/district/centre drill-down, Q1–Q5 results, timestamped aggregate exports and the saved <b>Women workers by trade and district</b> report.</p>','blue'))+
source_line(['S_Personas: P-08','T03_Members','T13_Counsellors','T14_Counselling_Cases','S_MIS_Queries']), 'S5 · Flow', '01:05–01:20 · Counselling workflow and MIS report / query')

# 22 — S5 steps
s5_steps=[
('5.1','demo.cns.edu1 → S5 / SM-08 → open P-08. Show member 1909, father 609, household 533 and education stage.','“The student’s support is linked to the worker household.”'),
('5.2','Book SYN-C-01 through the shared calendar in Mon/Wed/Fri 10:00–before 16:00 availability. Show mock reminder.','“The appointment has an assigned counsellor, a time and a reminder record.”'),
('5.3','Record assessment, interests, prescribed advice and agreed actions; save and open the private session.','“The counselling decision and actions are documented with restricted notes.”'),
('5.4','Upload the P-08 Class 10 memo; create ED-02 manual (15 days) and ED-01 API (30 days).','“Admission and scholarship requests each have their own route and service clock.”'),
('5.5','Show D+14 follow-up, the dependant record and father/household timeline.','“The case has a dated next contact and remains linked to the family record.”'),
('5.6','demo.pmu.state → SM-13 → State → district → centre drill-down.','“The analyst can move from State totals to the responsible location.”'),
('5.7','Select and run Q1, Q2, Q3, Q4 and Q5 live. Explain each query’s time basis before its total.','“These figures come from the issued rows and the defined filters, not a slide.”'),
('5.8','Export one report as CSV. Open the export; show reporting timestamp and aggregate columns.','“The department can export a timestamped view with personal identifiers minimised.”')
]
page('S5: the exact live sequence and speaking cues',texttable(['Step','Perform in the application','Explain the result'],s5_steps,'steps')+
box('C5 · final three minutes','<p>Authority → Configuration → Report builder: create <b>Women workers by trade and district</b>, filter <b>Female</b>, group by district and trade, save and add it to the PMU dashboard. Return to PMU and run/export the saved report.</p><p><b>Say:</b> “The department can publish this grouped report through the UI. It appears in the PMU dashboard without a code change.”</p>','gold')+
box('Avoid a misleading comparison','<p>Q1 is <b>Active-only / loaded snapshot</b>. The C5 report defaults to <b>Female / all registration statuses / current working records</b>. Explain the difference in filters before comparing counts.</p>')+
box('Transition to probes','<p>“We have completed the five workflows and their Authority changes. We can now repeat an appropriate step with another issued record or inspect the audit, sync, configuration and mock request/response evidence.”</p>')+
source_line(['issued pack: steps 5.1–5.8 and C5']), 'S5 · Live script', cls='dense')

# 23 — P8 source
c1=next(c for c in T['T13_Counsellors'] if c['counsellor_id']=='SYN-C-01')
p8m=next(m for m in T['T03_Members'] if m['member_id']=='SYN-M-001909')
father=W['SYN-W-000609']
page('P-08: source member, family and counsellor details',persona_card('P-08',True)+
texttable(['Linked source record','Exact value'],[
('Member / household',p8m['member_id']+' / '+p8m['household_id']),('Relationship / education',p8m['relationship_to_head']+' / '+p8m['education_stage']),('Father worker',father['worker_id']+' / '+father['full_name']+' / '+father['primary_trade']),('Contact',father['mobile']+' (father’s issued mobile)'),('Counsellor / account',c1['counsellor_id']+' / '+c1['name']+' / '+c1['login']),('Availability / languages',c1['availability']+' / '+c1['languages']),('ED-02','Admission facilitation / manual route / 15-day service clock'),('ED-01','Scholarship facilitation / local mock API / 30-day service clock'),('Follow-up','D+14; linked to dependant and worker household')
], 'dense')+
box('Suggested session narration','<p>“We have reviewed the issued Class 10 marks memo and education stage. The session records assessment, the student’s interests, the prescribed Polytechnic – Diploma in Civil Engineering advice and agreed actions. These notes are accessible only through the assigned counsellor role.”</p><p class=\"small\">Assessment, interests and agreed actions are keyed as live session notes; they are not invented seed records or a claim that an actual student was counselled.</p>')+
box('Appointment date versus follow-up','<p>Choose the next valid <b>Mon/Wed/Fri</b> appointment within the supplied availability. The scripted counselling follow-up remains <b>D+14</b>. Do not change the counsellor’s source availability simply to fit D.</p>','gold')+
source_line(['S_Personas: P-08','T03_Members: SYN-M-001909','T01_Workers: SYN-W-000609','T13_Counsellors: SYN-C-01']), 'S5 · Data card', cls='dense')

# 24 — MIS definitions and narration
query_notes={
'Q1':'Loaded snapshot: Active + Female; raw records; seeded duplicates retained.',
'Q2':'As on D: Submitted / Acknowledged by department / Query raised - awaiting worker; due_offset_days < 0.',
'Q3':'Loaded snapshot: JM-2026-01 preregistrations; exclude the walk-in made during S4.',
'Q4':'As on D: Open - under action / Open - escalated / Reopened; created_offset_days < -30.',
'Q5':'Loaded snapshot before S2: KRS + Active + skilling need Yes + empty enrolled_batch_id.'
}
page('MIS: explain the question before the number',
say('Before I run each report, I will state its population and time basis. Some queries ask for the original loaded data; others ask for overdue or old open work as on D. That distinction prevents demonstration updates from changing a baseline question.')+
table(['Query / source','What is being counted','Reference total'],[
['<b>'+e(q['query_id'])+'</b><br><span class=\"small\">'+e(q['source_sheets'])+'</span>',e(q['question'])+'<br><span class=\"small\">'+e(query_notes[q['query_id']])+'</span>','<b>'+str(MIS[q['query_id']]['total'])+'</b>']
for q in T['S_MIS_Queries']])+
box('How to show a report','<ol><li>Sign in as <b>demo.pmu.state</b>; open <b>SM-13</b>.</li><li>State the question and source/filter; choose the query.</li><li>Select <b>Run query live</b>; point to the total and grouped rows.</li><li>Use the role dashboard’s district/centre selectors for the separate drill-down demonstration.</li><li>Export a query, open the CSV and show the reporting timestamp and minimised columns.</li></ol>')+
box('Rehearsal totals, not an official answer key','<p>The totals in this guide are independently computed from the supplied rows and query definitions. The Committee’s answer key was not supplied. Show results from the live application during the slot; do not present this PDF as query evidence.</p>','gold')+
source_line(['S_MIS_Queries: Q1–Q5','server/model.mjs: current report computation','immutable loaded snapshots for Q1/Q3/Q5']), 'S5 · Report delivery')

# 25 — loaded query groups
page('Rehearsal result detail: the loaded-snapshot queries',
cols('<h2>Q1 · active women / top five</h2>'+texttable(['District','Count'],[[r['district_name'],r['count']] for r in MIS['Q1']['top5']],'dense')+
'<p><b>Statewide total: 176.</b> Kurnool and Palnadu tie at 11. The total covers all districts, not only the top five.</p>'+box('Explain Q1','<p>“This is the original loaded population of active registered women, counted as raw records. We retain the deliberately seeded near-duplicates as instructed.”</p>'),
'<h2>Q3 · preregistered candidates</h2>'+texttable(['Primary trade','Count'],[[r['primary_trade'],r['count']] for r in MIS['Q3']['results']],'dense')+'<p><b>Total: 20.</b> P-06’s later walk-in is excluded by this query’s definition.</p>')+
'<h2>Q5 · Krishna skilling need, not enrolled</h2>'+
texttable(['Primary trade','Count'],[[r['primary_trade'],r['count']] for r in MIS['Q5']['results']],'dense')+
texttable(['Source worker ID','Name','Primary trade'],[[wid,W[wid]['full_name'],W[wid]['primary_trade']] for wid in ['SYN-W-000400','SYN-W-000433','SYN-W-000594','SYN-W-000608']],'dense')+
box('Loaded data versus current activity','<p><b>Q1, Q3 and Q5 stay tied to the original loaded snapshot.</b> New registrations and the three S2 skilling-need updates do not change these baseline results. Current working dashboards and the C5 saved report can reflect current records.</p>','gold')+
source_line(['T01_Workers as loaded','T08_JobMela_Candidates as loaded','S_MIS_Queries']), 'S5 · Rehearsal figures', cls='dense')

# 26 — open queries
page('Rehearsal result detail: open work as on D',
cols('<h2>Q2 · open overdue referrals</h2>'+texttable(['Department','Count'],[[r['department'],r['count']] for r in MIS['Q2']['results']],'dense')+
'<p><b>Total: 54 across 16 departments.</b></p>',
'<h2>Q4 · open grievances older than 30 days</h2>'+texttable(['Category','Count'],[[r['category'],r['count']] for r in MIS['Q4']['results']],'dense')+
'<p><b>Total: 26.</b></p>'+box('Q2 boundary','<p>Include the defined open statuses only. A referral due today has offset 0 and is <b>not past its clock</b>. A new referral created on D is not overdue.</p>')+
box('Q4 boundary','<p>“Older than 30 days” means <b>created_offset_days &lt; −30</b>, not ≤−30. Completed/closed grievance statuses are not in the open set.</p>'))+
say('These views identify open work that needs attention, using the issued definitions. A count is useful because it is paired with a department or category, a clear time boundary and a role that can inspect the underlying work.')+
box('Use offsets correctly','<p>Before the run, rebase the demonstration date through Authority Environment. Do not change source created/due offsets to manufacture a pendency result. Fixed nominal source dates remain visible as source values; the application derives the live D-based dates.</p>','gold')+
source_line(['T10_Referrals / M04_Services','T11_Grievances','S_MIS_Queries: Q2/Q4']), 'S5 · Rehearsal figures', cls='dense')

# 27 — configuration overview
pubsvg=edge([(200,49),(237,49)])+edge([(436,49),(472,49)])+edge([(335,84),(335,120),(152,120),(152,148)])+edge([(335,120),(522,120),(522,148)])
pubsvg+=node(4,12,196,'Authority user',('demo.admin.state','Edit configured fields/rules'))+node(239,12,196,'Publish a new version',('UI action only','Publisher + before/after audit'))+node(474,12,192,'Version history',('Previous values retained','No code change / redeploy'),'blue')+node(5,148,295,'Desk / portal receives current config',('Next form / matching / PMU dashboard','Prospective clocks for new referrals'))+node(375,148,289,'Field receives config at next sync',('C2 checklist / same installed app','Existing queued data keeps its version'),'gold')
page('C1–C5: make every change visible at the user screen',
diagram(pubsvg,240,'Configuration evidence is the changed behaviour in a role screen plus its published version and change history.')+
texttable(['Task','Authority UI change','Proof to show immediately'],[
('C1','Mandatory Primary language of worker dropdown; Telugu / Urdu / Odia / Hindi / Other.','Next registration form; required option; version/history.'),
('C2','PPE – safety helmets available on site; Yes/No.','Field next synchronisation; new checklist and form version.'),
('C3','CS-01 clock 21 → 15; L1 14 → 10; new cases only.','Old case remains 21; next case 15; snapshot/version history.'),
('C4','Solar panel installer + SYN-E-002 vacancy at JM-2026-01.','Trade/matching list and event vacancy available after publication.'),
('C5','Women workers by trade and district; Female; group by district/trade.','Saved report appears in PMU dashboard; run and export.')
])+
say('For every C-task, I will switch to the Authority account, publish the change, show its version history and then return to the affected user. That demonstrates the effect of configuration, not just the existence of a settings screen.')+
box('Timing and permissions','<p>Reserve the final <b>three minutes of each scenario</b> for its C-task. The supervisor’s limited SM-19 is not Authority access. Do not publish the tasks in advance, use a script/database edit, or redeploy during the scored configuration step.</p>','gold')+
source_line(['issued pack: C1–C5','M05_Users_Roles: demo.admin.state','Configuration and Activity → Configuration history']), '07 · Authority changes')

# 28 — Q&A and evidence
page('Answer client questions with a screen and evidence',
texttable(['Client question','Clear answer / screen to open'],[
('How do you prevent duplicates?','Search before registration; show Gorle Laxmi → SYN-W-000607, the retained master and the link audit. Six issued legacy duplicate pairs are not cleaned.'),
('What happens without connectivity?','Show the actual Android airplane-mode capture, encrypted queue, offline reload, provisional ID and sync receipt. Do not claim physical device validation from desktop tests.'),
('What if the centre and field both edit a worker?','Open the supervisor conflict: base/field/centre values, selected result, reason and audit.'),
('What if a Government service is down?','Show Civil Supplies 503, same CS-01 ID through manual fallback, departmental receipt, service clock and retry/dependency evidence.'),
('Are these live Government integrations?','No. The issued 13-path contract is hosted locally, with synthetic tokens and viewable request/response logs. Actual Government interfaces are outside this demonstration.'),
('Are any real messages sent?','No. Open Messaging log: SMS/WhatsApp/reminder/offer payloads are accepted by the local mock gateway; dispatched:false.'),
('Who can change the rules?','Authority publishes C1–C5 through the UI; show publisher, timestamp, before/after values and role limits.'),
('Can the PMU read counselling notes?','No. The assigned counsellor sees private session notes. PMU receives role reports without those notes; show the role boundary.'),
('How are reports checked?','Run Q1–Q5 from issued source rows; explain filters/snapshots; export a timestamped, aggregate CSV. The Committee retains its own answer key.'),
('Is AI included?','No AI model or AI business logic is connected in this prototype. Keep the discussion on the issued five workflows.'),
('Is it production-ready?','This is the configured working demonstration requested for T-4. Production Government integration and hardening are not claimed. The local flows have been checked; actual Android/venue preflight remains required.')
], 'dense')+
box('Where the evidence is','<p><b>Activity:</b> Audit trail, Mock API log, Messaging log, Configuration history.<br><b>Field S2:</b> Encrypted device evidence, Sync queue, receipts and visit photograph/location.<br><b>Authority:</b> Environment counts/hashes/date and preparation checklist.<br><b>SM-13:</b> live reports, saved report and CSV export.</p>')+
say('I will show the related record and its evidence so you can see what happened, which role performed it and what action remains next.'), '08 · Questions and probes', cls='dense')

# 29 / 30 — exact service catalogue, not additional invented services
def service_rows(rows):
    return [[
        '<b>'+e(s['service_code'])+'</b><br>'+e(s['service_name']),
        e(s['department'])+'<br><span class=\"micro\">'+e(s['annexure_d_ref'])+' · '+e(s['owning_module'])+'</span>',
        e(s['demo_integration_mode']),
        e(s['service_clock_days']+' / '+s['escalation_L1_after_days']+' / '+s['escalation_L2_after_days']),
        e(s['documents_required'])
    ] for s in rows]
service_headers=['Code / issued service','Department / module','Issued mode','Clock / L1 / L2 days','Required documents']
page('Issued service catalogue: entries 1–12',
'<p>These are exact M04_Services reference entries. Explain the service, responsible department, channel, documents and clock. The required scripted operations use the local mocked paths; a catalogue row is not a claim of a live Government integration.</p>'+
table(service_headers,service_rows(T['M04_Services'][:12]),'dense')+
box('How to present a service','<p>“This catalogue tells the operator which department is responsible, which documents are needed and the time target. We will demonstrate the specified services through the issued mock contract or manual route.”</p>')+
source_line(['M04_Services: original catalogue','23 service rows in total','original clocks before C3']), '09 · Service reference', cls='dense')

employers=[r for r in T['T04_Employers'] if r['employer_id'] in ['SYN-E-001','SYN-E-002','SYN-E-003','SYN-E-004','SYN-E-005','SYN-E-006']]
page('Issued service catalogue: entries 13–23',
table(service_headers,service_rows(T['M04_Services'][12:]),'dense')+
box('Respect the supplied API contract','<p>Some catalogue rows say Mock API but have no operation in the supplied YAML, including <b>LB-02, NP-01 and PG-01</b>. The prototype does not invent counterpart endpoint contracts; additional routes use a documented manual/dependency approach.</p>','gold')+
source_line(['M04_Services: original reference catalogue','original clocks before C3']), '09 · Service reference', cls='dense')

# 31 — full event reference, kept separate for readable tables
event_ids=event['vacancies_offered'].split(', ')
event_vacancies=[v for v in T['T06_Vacancies'] if v['vacancy_id'] in event_ids]
page('JM-2026-01: the complete issued event data',
texttable(['Employer ID','Issued employer name','District'],[[r['employer_id'],r['employer_name'],r['district_code']] for r in employers],'dense')+
'<h2>The 12 offered vacancies</h2>'+
texttable(['Vacancy','Employer','Trade','Positions','Wage / day','Min. experience'],[[v['vacancy_id'],v['employer_id'],v['trade_required'],v['positions'],'₹'+v['daily_wage_offered_inr'],v['min_experience_years']+' years'] for v in event_vacancies],'dense')+
box('Show the two required interview links','<p><b>P-06 / Kandula Rajesh → SYN-E-001 / SYN-V-0001 / Mason.</b><br><b>P-07 / JMR-004 → SYN-E-006 / SYN-V-0006 / Bar bender.</b></p><p>Then show the source event capacity 300 and initial 20 preregistrations. After the live sequence, the working event has 21 registrations, 2 check-ins, 2 interviews and 1 offer.</p>')+
box('C4 adds to the working event','<p>Solar panel installer and the newly published SYN-E-002 vacancy are live Authority changes, not original seed entries. The original event’s 12 vacancies and six employers remain unchanged in the issued files.</p>','gold')+
source_line(['T07_JobMela_Event','T04_Employers: SYN-E-001 to SYN-E-006','T06_Vacancies: SYN-V-0001 to SYN-V-0012']),
'09 · Event reference', cls='dense')

# 31 — contract and specimen map
yaml=(ROOT / DATA['sourceFolder'] / 'ILAC_Demo_Mock_API_v1.0.yaml').read_text()
paths=re.findall(r'^  (/[^\n]+):$',yaml,re.M)
assert len(paths)==13
def method(path):
    return 'GET' if path=='/digilocker/v1/documents' or path.startswith('/meeseva/') or path.endswith('/status') else 'POST'
specimen_map=[
('specimen_photo_P-01.png','S1 / P-01: Photo classification'),
('specimen_work_certificate_P-01.png','S1 / P-01: Work certificate classification'),
('specimen_photo_P-03.png','S1 / P-03: pending-verification registration'),
('specimen_photo_P-04.png','S2 / P-04: capture specimen with device camera'),
('specimen_birth_certificate_P-05.png','S3 / newborn: Birth certificate classification'),
('specimen_photo_P-06.png','S4 / P-06: quick registration'),
('specimen_class10_memo_P-08.png','S5 / P-08: Class 10 marks memo classification')]
page('Know the local mock paths and the seven specimen files',
'<p class=\"small\">All paths below are hosted under the same local <b>/mock</b> base. The static probe bearer token is <b>ILAC-MOCK-v1</b>; authenticated app sessions also use their local bearer token. Inspect requests and responses through Activity / the Authority contract console.</p>'+
table(['Method','Supplied path'],[[method(path),'<code>'+e(path)+'</code>'] for path in paths],'dense')+
'<h2>Specimen upload map</h2>'+
table(['Issued filename','Where it is used'],[['<code>'+e(name)+'</code>',e(use)] for name,use in specimen_map],'dense')+
box('What these contracts and documents mean','<p>These are illustrative tender mocks and synthetic specimens, not real counterpart API descriptions or valid identity documents. P-03 waits more than 10 seconds; Civil Supplies returns 503 throughout S3. Messaging records the payload only. Use synthetic tokens and never send a real 12-digit Aadhaar value.</p>','gold')+
source_line(['ILAC_Demo_Mock_API_v1.0.yaml','S_Mock_API_Behaviour','specimen_documents/']), '10 · Integration and file reference', cls='dense')

# 32 — closing and final cue card
page('Your final cue card: keep the story and evidence clear',
texttable(['Scenario','Remember the record','Finish by showing'],[
('S1 / C1','P-01; Gorle Laxmi → worker 607; P-03','Acknowledgement/messages; duplicate audit; retry/next step; new language field'),
('S2 / C2','Visit 001; P-04; worker 120; absent 182/225','Encrypted queue; permanent ID; both mobile edits and supervisor reason; PPE item'),
('S3 / C3','P-05 / worker 608; SK-01 + CS-01; R-00151','Same CS case route; two-referral acknowledgement; receipt/status; old/new clocks'),
('S4 / C4','JM-2026-01; P-06 + JMR-004','Offer/SM-05 follow-up; pending D+2; employer dashboard; new trade/vacancy'),
('S5 / C5','P-08 / member 1909; C-01; Q1–Q5','Private notes; ED referrals; D+14; live totals/export; saved PMU report')
], 'dense')+
say('We have shown a connected service journey with a saved record, a responsible role, a dated next action and viewable evidence. The five Authority changes were made through the interface. We can now inspect the records, repeat an appropriate issued-data step or review the logs you would like to see.')+
texttable(['If something goes wrong','Use this response'],[
('A persona is already registered','Open the existing record or reset before a new rehearsal. Do not create a second master to repeat the story.'),
('The field queue belongs to an old rehearsal','After the server reset, clear the device rehearsal data while online and download the new assignment.'),
('The phone cannot use encryption/GPS/PWA','Check trusted LAN HTTPS, installed CA, browser/device permissions and same-network reachability.'),
('P-03 times out / Civil Supplies is unavailable','These are required failure behaviours. Show the pending/next step or manual fallback; do not bypass the failure.'),
('A role cannot see a screen','Check the issued account and scope; use the proper operator/Authority/department/employer role.'),
('Connectivity fails during the slot','Show truthful queue/dependency state and use the prepared bidder connection. The issued slot is not automatically extended.')
], 'dense')+
box('Before attending','<p>Obtain the official <b>Annexure-B_T4_Demonstration_Scoring_Sheet_v1.0.xlsx</b>, which was absent from the supplied folder. Confirm the Board’s actual date/time, review the submitted bid’s app/hosting commitments, test the actual Android device and complete the pre-demonstration declaration at least one working day before the slot. Bring at most four representatives, including the named Solution Architect/Technical Lead.</p>','gold')+
'<p class=\"source\">References: README.md · docs/tender/T4-COVERAGE.md · docs/tender/VERIFICATION.md · docs/tender/issued-demonstration-pack.docx. This handbook supports presentation; the Committee determines live completeness, usability and configuration scores.</p>',
'11 · Closing and preflight', cls='dense')

assert len(pages)==33, len(pages)
# Render a fixed-page HTML original alongside the final PDF.
rendered=[]
for i,item in enumerate(pages,1):
    cover='cover' in item['cls']
    head='' if cover else '<header class=\"page-header\"><div class=\"brand\"><img src=\"../../assets/images/ap-emblem.png\" alt=\"Andhra Pradesh emblem\"><span>DIGITAL ILAC · PART 1</span></div><span>Client demonstration playbook · Tender 985903</span></header>'
    title='' if cover else '<p class=\"chapter\">'+e(item['chapter'])+'</p><h1>'+e(item['title'])+'</h1>'+('<p class=\"subtitle\">'+e(item['subtitle'])+'</p>' if item['subtitle'] else '')
    rendered.append('<section class=\"page '+item['cls']+'\" id=\"page-'+str(i)+'\" data-title=\"'+e(item['title'])+'\">'+head+'<div class=\"page-content\">'+title+item['body']+'</div><footer class=\"footer\"><span>Presenter preparation · Issued dataset v1.0 · Local Government mocks</span><span>'+str(i).zfill(2)+' / '+str(len(pages))+'</span></footer></section>')
result='<!doctype html><html lang=\"en\"><head><meta charset=\"utf-8\"><title>Digital ILAC — Client Demonstration Playbook</title><meta name=\"author\" content=\"Digital ILAC project team\"><style>'+CSS+'</style></head><body>'+''.join(rendered)+'</body></html>'
(OUT/'Digital_ILAC_Client_Demo_Playbook.html').write_text(result)
(OUT/'guide-build-manifest.json').write_text(json.dumps({'title':'Digital ILAC — Client Demonstration Playbook','pages':len(pages),'sourceDataset':DATA['sourceFolder'],'issuedRecords':sum(DATA['counts'].values()),'sourceFileHashes':len(DATA['sourceManifest']),'personaCards':list(P),'numberedSteps':45,'configurationTasks':5,'diagrams':result.count('<svg '),'pageTitles':[p['title'] for p in pages]},indent=2)+'\n')
print('Built 33-page HTML guide: eight source persona cards, 45 steps, C1–C5, seven vector flow diagrams and five computed query references.')
